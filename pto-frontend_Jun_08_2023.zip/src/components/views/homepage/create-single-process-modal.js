import React, { useState, useCallback } from 'react'
import { Alert, Modal, Box, Typography, IconButton, Slide } from '@mui/material';
import axios from 'axios';
import { motion } from 'framer-motion'
// *** shared ***
import SharedTextfieldAndSubmit from 'shared/forms/textfield-and-submit'
// *** icons ***
import CloseIcon from '@mui/icons-material/Close';
// *** styles ***
import { CreateSingleProcessModalStyles } from 'assets/styles/views/homepage.styles'
import { createUseStyles } from 'react-jss';
const useStyles = createUseStyles(CreateSingleProcessModalStyles)



const alertInitialState = { open: false, severity: "success", message: "" }
function CreateSingleProcessModal({ open, onClose }) {
  const classes = useStyles();
  const [loading, setLoading] = useState(false)
  const [alert, setAlert] = useState(alertInitialState)
  const [userCreateOneSingleProcessSuccessfully, setUserCreateOneSingleProcessSuccessfully] = useState(false)

  const handleClickCloseModal = () => {
    setLoading(false)
    setAlert(alertInitialState)
    onClose(userCreateOneSingleProcessSuccessfully)
    setUserCreateOneSingleProcessSuccessfully(false)
  }


  const onSubmit = useCallback(({ ProcessUUID }, { setSubmitting }) => {
    setLoading(true)
    if (!process.env.NODE_ENV || process.env.NODE_ENV === 'development') {
      //?=================[ DEV ]========================
      setTimeout(() => {
        setLoading(false)
        setSubmitting(false)
        setAlert({ open: true, severity: "success", message: "A new job for a single process was created." })
        setUserCreateOneSingleProcessSuccessfully(true)
        // setAlert({ open: true, severity: "error", message: "Could not create a new single process." })
      }, 2000)
    }
    else {
      //?=================[ PROD ]========================
      const headers = { "Content-type": "application/json" }
      const body = {
        "processUUID": ProcessUUID,
        "singleProcess": true
      }

      axios
        .post("/api/singleInstance", body, { headers }) //! REQUIRE INTEGRATION WITH BACKEND
        .then(response => {
          setLoading(false)
          setSubmitting(false)
          if (String(response?.data?.statusCode) === "404") { // Only check if ProcessUUID is not found
            setAlert({ open: true, severity: "error", message: Boolean(response?.data?.message) ? response?.data?.message : "ProcessUUID is not found." })
          }
          else {
            setAlert({ open: true, severity: "success", message: "A new job for a single process was created." })
            setUserCreateOneSingleProcessSuccessfully(true)
          }
        })
        .catch(error => {
          setLoading(false)
          setSubmitting(false)
          setAlert({ open: true, severity: "error", message: "Could not create a job for a single process." })
        })
    }
  }, [])

  return (
    <Modal open={open} className={classes.createSingleProcessModal}>
      <Slide
        in={open}
        timeout={200}
        direction='up'
        unmountOnExit
      >
        <Box sx={{ boxShadow: 24 }} className={classes.modalBox}>
          {alert.open && (
            <motion.div
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
            >
              <Alert
                variant="outlined"
                severity={alert.severity}
                className="alert-section"
              >
                {alert.message}
              </Alert>
            </motion.div>
          )}


          <div className="top-section">
            <Typography variant='h3' component='h3' className="modal-title">
              Create Job For a Single Process
            </Typography>

            <IconButton onClick={handleClickCloseModal}>
              <CloseIcon />
            </IconButton>
          </div>

          <SharedTextfieldAndSubmit
            ref={null}
            name="ProcessUUID"
            labelText="Process UUID"
            buttonTxt="Create"
            startIcon={null}
            required
            disabled={loading || userCreateOneSingleProcessSuccessfully}
            isSubmitting={loading}
            onSubmit={onSubmit}
          />

        </Box>
      </Slide>
    </Modal>
  )
}

export default CreateSingleProcessModal
