import { memo, useState, useEffect } from 'react'
import { Tooltip, Zoom } from '@mui/material';
import { motion } from 'framer-motion';
// *** styles ***
import { createUseStyles } from 'react-jss';
import { LogsInfoStyles } from 'assets/styles/views/logs.styles';
const useStyles = createUseStyles(LogsInfoStyles)



function Info({ jobID, totalNumberOfProcessInstance, numberOfSuccessMigrationProcess, numberOfFailureMigrationProcess }) {
    const classes = useStyles();
    const [playAnimation, setPlayAnimation] = useState(false)

    useEffect(() => {
        const onPageLoad = () => setPlayAnimation(true)
        // Check if the page has already loaded
        if (document.readyState === 'complete') {
            onPageLoad();
        } else {
            window.addEventListener('load', onPageLoad);
            return () => window.removeEventListener('load', onPageLoad);
        }
    }, []);



    const __jobID = Boolean(jobID) ? jobID : "##";
    const __totalNumberOfProcessInstance = Boolean(totalNumberOfProcessInstance) ? totalNumberOfProcessInstance : "##"
    const __numberOfSuccessMigrationProcess = Boolean(numberOfSuccessMigrationProcess) ? numberOfSuccessMigrationProcess : "##"
    const __numberOfFailureMigrationProcess = Boolean(numberOfFailureMigrationProcess) ? numberOfFailureMigrationProcess : "##"

    return (
        <div className={classes.infoCardsRoot}>
            <motion.div
                className="info-card theme-purple"
                initial={{ opacity: 0 }}
                animate={{ opacity: playAnimation ? 1 : 0 }}
                transition={{ type: "tween", duration: 1, ease: "easeInOut" }}
            >
                <Tooltip
                    title={__jobID}
                    TransitionComponent={Zoom}
                    followCursor
                >
                    <span>{__jobID}</span>
                </Tooltip>
                <p>Job ID</p>
            </motion.div>

            <motion.div
                className="info-card theme-info"
                initial={{ transform: "translateX(-100%)" }}
                animate={{ transform: playAnimation ? "translateX(0px)" : "translateX(-100%)" }}
                transition={{ type: "tween", duration: 1, ease: "easeInOut" }}
            >
                <Tooltip
                    title={__totalNumberOfProcessInstance}
                    TransitionComponent={Zoom}
                    followCursor
                >
                    <span>{__totalNumberOfProcessInstance}</span>
                </Tooltip>
                <p>Total Number of Processes</p>
            </motion.div>


            <motion.div
                className="info-card theme-success"
                initial={{ transform: "translateX(-200%)" }}
                animate={{ transform: playAnimation ? "translateX(0px)" : "translateX(-200%)" }}
                transition={{ type: "tween", duration: 1, ease: "easeInOut" }}
            >
                <Tooltip
                    title={__numberOfSuccessMigrationProcess}
                    TransitionComponent={Zoom}
                    followCursor
                >
                    <span>{__numberOfSuccessMigrationProcess}</span>
                </Tooltip>
                <p>Successfully Migrated</p>
            </motion.div>


            <motion.div
                className="info-card theme-danger"
                initial={{ transform: "translateX(-300%)" }}
                animate={{ transform: playAnimation ? "translateX(0px)" : "translateX(-300%)" }}
                transition={{ type: "tween", duration: 1, ease: "easeInOut" }}
            >
                <Tooltip
                    title={__numberOfFailureMigrationProcess}
                    TransitionComponent={Zoom}
                    followCursor
                >
                    <span>{__numberOfFailureMigrationProcess}</span>
                </Tooltip>
                <p>Failed to Migrate</p>
            </motion.div>
        </div >
    )
}

export default memo(Info)