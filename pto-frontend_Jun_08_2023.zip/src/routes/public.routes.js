// *** Views ***
import Login from 'views/login';
import ErrorPage from 'views/errorPage';

const publicRoutes = [
    {
        id: "login",
        title: "Login",
        index: true,
        path: "/",
        element: <Login />
    },
    {
        protectedRoute: false,
        id: "error-page",
        path: "*",
        element: <ErrorPage errorNumber={404} errorMessage="This page could not be found" />
    }
]



export default publicRoutes