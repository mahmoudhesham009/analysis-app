//TODO: styles for extra common datatable components

import { lighten, transparentize } from 'polished';

const ExtraCommonDTStyles = (theme, color) => ({
    regularButton: {
        backgroundColor: theme.colors.primary[0],
        color: theme.colors.white,
        "&:hover": {
            backgroundColor: lighten(0.1, theme.colors.primary[0]),
        }
    },
    roseButton: {
        backgroundColor: transparentize(0.7, theme.colors.rose[0]),
        color: theme.colors.rose,
        boxShadow: theme.shadows.rose,
        "&:hover": {
            backgroundColor: lighten(0.1, theme.colors.rose[0]),
        }
    },
    warnButton: {
        backgroundColor: transparentize(0.7, theme.colors.warning[0]),
        color: theme.colors.warning,
        boxShadow: theme.shadows.warning,
        "&:hover": {
            backgroundColor: lighten(0.1, theme.colors.warning[0]),
        }
    },
    interactiveButton: color => {        
        return {
            // button with spinner and promise status
            // backgroundColor: transparentize(0.7, theme.colors.primary[0]),
            // color: theme.colors.primary[0],
            backgroundColor: transparentize(0.7, color),
            color: color,
            width: 40,
            height: 40,
            "&:hover": {
                backgroundColor: color,
                color: theme.colors.white,
            },
            "&.success": {
                "& , &:hover": {
                    backgroundColor: color,
                    color: theme.colors.white,
                }
            },
            "&.loading": {
                backgroundColor: transparentize(0.7, color) + "!important",
                color: color + "!important",
                "&:hover": {
                    background: color + "!important",
                    color: theme.colors.white + "!important"
                },
            },
            "& ~ .interactive-spinner": {
                top: -4,
                left: -4,
                color: color
            }
        }

        // "&:hover": {
        //     backgroundColor: theme.colors.primary[0],
        //     color: theme.colors.white,
        // },
        // "&.success": {
        //     "& , &:hover": {
        //         backgroundColor: theme.colors.success[0],
        //         color: theme.colors.white,
        //     }
        // },
        // "&.loading": {
        //     backgroundColor: transparentize(0.7, theme.colors.primary[0]) + "!important",
        //     color: theme.colors.primary[0] + "!important",
        //     "&:hover": {
        //         background: theme.colors.primary[0] + "!important",
        //         color: theme.colors.white + "!important"
        //     },
        // },
        // "& ~ .interactive-spinner": {
        //     top: -4,
        //     left: -4,
        //     color: theme.colors.primary[0]
        // }
    }
})

export default ExtraCommonDTStyles