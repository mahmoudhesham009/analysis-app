const SuccessFailureModalStyles = theme => ({
    modal: {
        display: "flex",
        justifyContent: "center",
        alignItems: "center"
    },
    modalBox: {
        maxWidth: 500,
        width: "100%",
        padding: "25px 0px",
        borderRadius: 6,
        backgroundColor: theme.colors.white,
        "& .modal-check-icon": {
            display: "flex",
            justifyContent: "center",
            marginBottom: 20,
            "& svg": {
                fontSize: 75,
                color: theme.colors.primary[0],
            }
        },
        "& .modal-title": {
            fontSize: 24,
            textAlign: "center",
            fontWeight: 600,
            marginBottom: 20
        },
        "& .modal-description": {
            fontSize: 16,
            textAlign: "center",
        },
        "& .modal-close-button-wrapper": {
            display: "flex",
            justifyContent: "center",
            marginTop: 25,
            "& button": {
                background: theme.colors.primary[0],
                color: theme.colors.white + "!important",
                fontWeight: 500,
                padding: "10px 25px"
            }
        },
        "@media(max-width: 570px)": {
            maxWidth: "100%",
            width: "calc(100% - 30px)",
            margin: "0 auto"
        },
    }
})


export default SuccessFailureModalStyles