package gov.uspto.pe2e.cpc.wms.migration.analysis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
public class Analysis_EngineApplication {

	public static void main(String[] args) {
		SpringApplication.run(Analysis_EngineApplication.class, args);
	}

}
