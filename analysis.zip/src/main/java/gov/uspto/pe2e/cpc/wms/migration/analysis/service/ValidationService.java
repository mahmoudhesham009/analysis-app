package gov.uspto.pe2e.cpc.wms.migration.analysis.service;

import org.springframework.stereotype.Service;

@Service
public class ValidationService {

}
