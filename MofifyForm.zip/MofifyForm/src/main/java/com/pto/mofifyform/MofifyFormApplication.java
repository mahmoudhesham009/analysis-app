package com.pto.mofifyform;

import com.pto.mofifyform.service.ModificationService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class MofifyFormApplication {


    public static void main(String[] args) {
        ConfigurableApplicationContext context= SpringApplication.run(MofifyFormApplication.class, args);
        ModificationService sc = (ModificationService)context.getBean(ModificationService.class);
        sc.startModification();

    }

}
