package com.pto.mofifyform.repository;

import com.pto.mofifyform.entity.SubmittedForm;
import jakarta.persistence.Tuple;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface SubmittedFormRepository extends JpaRepository<SubmittedForm,Long> {

    @Query(value = "select t.id_, t.task_def_key_ from act_hi_taskinst t inner join submitted_form sf on " +
            "t.id_=sf.task_id_ where sf.FIELDS_VALUE_DEFINITION not like '%_ACTION\":\"%' ",nativeQuery = true)
    List<Tuple> getAllTasksWithForm();

    @Query(value = "select name_, text_ from act_hi_varinst where tast_id_= :taskId",nativeQuery = true)
    List<Tuple> getAllVarsByTask(long taskId);
}
