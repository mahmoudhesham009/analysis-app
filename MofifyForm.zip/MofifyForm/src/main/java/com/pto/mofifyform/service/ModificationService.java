package com.pto.mofifyform.service;

import com.pto.mofifyform.entity.SubmittedForm;
import com.pto.mofifyform.repository.SubmittedFormRepository;
import jakarta.persistence.Tuple;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.w3c.dom.ls.LSInput;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

@Service
public class ModificationService {

    private static final Logger log = LoggerFactory.getLogger(ModificationService.class);


    @Autowired
    SubmittedFormRepository submittedFormRepo;
    public void startModification(){
        //get all from hisTask
        List<Tuple> tasks= submittedFormRepo.getAllTasksWithForm();
        log.info("number Of Tasks: ", tasks.size());

        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("logs");

        Row row = sheet.createRow(0);

        // Create cells in the row
        Cell cell1 = row.createCell(0);
        cell1.setCellValue("taskId");

        Cell cell2 = row.createCell(1);
        cell2.setCellValue("action");

        Cell cell3 = row.createCell(2);
        cell3.setCellValue("comment");

        int cellCounter=0;
        //for
        for (Tuple t: tasks){
            log.info("Task: ", t.get(0));

            cellCounter++;
            row = sheet.createRow(cellCounter);
            cell1 = row.createCell(0);
            cell1.setCellValue((long)t.get(0));

            //get sub form and convert it to JSONObject
            SubmittedForm sf=submittedFormRepo.findById((long)t.get(0)).get();
            JSONObject json=new JSONObject(sf.getFieldsValueDefinition());
            JSONObject form=json.getJSONObject("values");
            //if Action Exisits (StartWith, Include, EndWith)
            boolean actionFound=false;
            for(String f:form.toMap().keySet()){
                if(f.contains(t.get(1).toString())&&f.startsWith("wfForm")&&f.endsWith("_ACTION")){
                    actionFound=true;
                    cell3 = row.createCell(2);
                    cell3.setCellValue("There is an action already in this form");
                    log.info("There is an action already in this form");
                    break;
                }
            }
            if (actionFound) continue;


            //get var from var inst
            List<Tuple> vars=submittedFormRepo.getAllVarsByTask((long)t.get(0));

            String name="", value="";
            boolean found=false, duplicated=false;

            for(Tuple v: vars){
                String na=v.get(0).toString();
                String va=v.get(1).toString();
                if(na.contains(t.get(1).toString())&&na.startsWith("wfForm")&&na.endsWith("_ACTION")){
                    if(found){
                        duplicated=true;
                        break;
                    }
                    found=true;
                    name=na;
                    value=va;
                }
            }
            if(!found){
                //log not found
                cell3 = row.createCell(2);
                cell3.setCellValue("No action variable found");
                log.info("No action variable found");
                continue;
            }

            if(duplicated){
                //log not duplicated
                cell3 = row.createCell(2);
                cell3.setCellValue("there is more than action variable for this task");
                log.info("there is more than action variable for this task");
                continue;
            }

            form.put(name,value);
            json.put("values",form);
            sf.setFieldsValueDefinition(form.toString());

            submittedFormRepo.save(sf);

            cell2 = row.createCell(1);
            cell2.setCellValue(name+":"+value);
            log.info(name+":"+value);

        }

        try (FileOutputStream fileOut = new FileOutputStream("example.xlsx")) {
            workbook.write(fileOut);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Closing the workbook
        try {
            workbook.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
