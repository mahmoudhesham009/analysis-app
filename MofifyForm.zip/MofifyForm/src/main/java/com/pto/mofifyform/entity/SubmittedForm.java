package com.pto.mofifyform.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.sql.Timestamp;

@Entity
@Data
@Table(name = "Submitted_form")
public class SubmittedForm {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID", nullable = false)
    private Long id;

    @Column(name = "FORM_ID", nullable = false)
    private Long formId;

    @Column(name = "TASK_ID", nullable = false, length = 255)
    private String taskId;

    @Column(name = "PROCESS_ID", nullable = false, length = 255)
    private String processId;

    @Column(name = "SUBMITTED", nullable = false)
    private Timestamp submitted;

    @Column(name = "SUBMITTED_BY", nullable = false)
    private Long submittedBy;

    @Lob
    @Column(name = "FIELDS_VALUE_DEFINITION", nullable = true)
    private String fieldsValueDefinition;

    @Column(name = "TENANT_ID", nullable = false)
    private Long tenantId;
}