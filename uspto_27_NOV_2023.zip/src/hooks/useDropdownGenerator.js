// TODO : generate dropdown items from array of primitives with or without alias for custom dropdown.
import PropTypes from 'prop-types'

function useDropdownGenerator(arrayOfPrimitives, alias, aliasPlacement) {

    let selectDropdownItemList = [];

    arrayOfPrimitives.map(value => {
        selectDropdownItemList.push({
            id: aliasPlacement === 'end' ? `${value}${alias}` : `${alias}${value}`,
            value: `${value}`,
            text: aliasPlacement === 'end' ? `${value} ${alias}` : `${alias} ${value}`
        })
    })


    return selectDropdownItemList
}


useDropdownGenerator.propTypes = {
    arrayOfPrimitives: PropTypes.oneOf([
        PropTypes.arrayOf(PropTypes.number),
        PropTypes.arrayOf(PropTypes.bool),
        PropTypes.arrayOf(PropTypes.string),
    ]).isRequired,

    alias: PropTypes.string,
    aliasPlacement: PropTypes.oneOf(['start', 'end'])
}


export default useDropdownGenerator