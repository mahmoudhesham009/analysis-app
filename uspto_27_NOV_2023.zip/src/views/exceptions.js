import makeData from 'data/makeData.exceptions'
import { memo, createContext, useState, useEffect, useReducer, useRef, useMemo, useCallback } from 'react'
import axios from 'axios';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import queryString from 'query-string';
import classNames from 'classnames';
import { Button, IconButton, Tooltip, Container, Stack } from '@mui/material'
import HtmlReactParser from 'html-react-parser';
// *** views ***
import ErrorPage from 'views/errorPage';
//*** components ***
import Card from "components/Card"
import CardIcon from 'components/Card/CardIcon';
import CardBody from "components/Card/CardBody"
import CardFooter from 'components/Card/CardFooter';
import ReactTable from 'components/DataTable'
import DeploymentList from 'components/views/analysis/deployment-list';
import TransitionUpDown from 'components/transition-up-down-views';
import InteractiveButton from 'components/FormFields/CustomButton/InteractiveButton';
//*** modals ***
import DeleteExceptionSuccessFailureModal from 'shared/modals/success-failure.modal';
import DeleteExceptionDialog from 'shared/modals/accept-reject.dialog';
// *** hooks ***
import { DT_FILTER_LBL_NUMBER_OF_RECORDS } from 'hooks/useFilterText'
import useNavigatingAway from "hooks/useNavigatingAway";
import useEventListener from 'hooks/useEventListener';
// *** redux ***
import { useDispatch } from 'react-redux'
import { ChangeExpandedParentAccordion, ChangeExpandedChildAccordion } from '@redux'
// *** config ***
import PtoResponse from 'config/exception-dynamic-form.json'; // for demo only
import ProcessApi from 'config/process-api'
// *** Icons ***
import CheckIcon from '@mui/icons-material/Check';
import AddExceptionIcon from '@mui/icons-material/BugReport';
import DeleteExceptionIcon from '@mui/icons-material/DeleteSweepRounded';
import AssignmentIcon from '@mui/icons-material/Assignment';
import DynamicFormIcon from '@mui/icons-material/DynamicForm';
import CloseIcon from '@mui/icons-material/Close';
// *** styles ***
import { createUseStyles } from 'react-jss'
import { DataTableActionStyles } from 'assets/styles/components/datatable.styles'
import styles from 'assets/styles/views/exceptions.styles';
const useDTActionStyles = createUseStyles(DataTableActionStyles)
const useStyles = createUseStyles(styles)


const deleteExceptionStatusModalInitialState = {
  open: false,
  status: "",
  title: "",
  description: ""
}
const deleteExceptionInitialState = {
  open: false,
  loading: false,
  selectedID: null,
  selectedJobID: null,
  selectedProcessInstanceId: null,
  btnIsSuccess: null,
  statusModal: deleteExceptionStatusModalInitialState
}
const deleteExceptionReducer = (state = deleteExceptionInitialState, action) => {
  switch (action.type) {
    case "changeOpenState":
      return { ...state, open: action.payload }
    case "deleteException":
      return {
        ...state,
        open: true,
        selectedID: action.payload?.id,
        selectedJobID: action.payload?.jobId,
        selectedProcessInstanceId: action.payload?.processInstanceId
      }
    case "onAcceptDeleteException":
      return { ...state, loading: true, open: false }
    case "onRejectDeleteException":
      return {
        ...state,
        open: false,
        selectedID: null,
        selectedJobID: null,
        selectedProcessInstanceId: null,
      }
    case "onSuccessDeleteException":
      return {
        ...state,
        loading: false,
        btnIsSuccess: true,
        statusModal: {
          open: true,
          status: "success",
          title: "Operation Complete",
          description: HtmlReactParser(`
              Exception for               
                ID: <strong>${action.payload?.id}</strong>
              and              
                jobID: <strong>${action.payload?.jobId}</strong>
              was deleted successfully
          `)
        }
      }
    case "onFailureDeleteException":
      return {
        ...state,
        loading: false,
        btnIsSuccess: false,
        statusModal: {
          open: true,
          status: "fail",
          title: "Operation Fail",
          description: HtmlReactParser(
            `Fail to delete exception for
                ID: <strong>${action.payload?.id}</strong>
              and 
                jobID: <strong>${action.payload?.jobId}</strong>
            `)
        }
      }
    case "onCloseDeleteExceptionSuccessFailureModal":
      return {
        ...state,
        btnIsSuccess: null,
        selectedID: null,
        selectedJobID: null,
        selectedProcessInstanceId: null,
        statusModal: deleteExceptionStatusModalInitialState
      }
    default: return state
  }
}

export const ExceptionsNavigatingAwayContext = createContext()
function Exceptions() {
  const navigate = useNavigate()
  const dispatch = useDispatch()
  const location = useLocation();
  const parsed = queryString.parse(location.search);
  const fetchIdRef = useRef(0)
  /**
   * Classes
   */
  const dtActionClasses = useDTActionStyles()
  const classes = useStyles()
  /**
   * Reducers
   */
  const [delException, dispatchDelException] = useReducer(deleteExceptionReducer, deleteExceptionInitialState)
  /**
   * States
   */
  const [data, setData] = useState([])
  const [analysisSectionRevertInProgress, setAnalysisSectionRevertInProgress] = useState(false)
  const [loading, setLoading] = useState(true)
  const [pageCount, setPageCount] = useState(0)
  const [deployments, setDeployments] = useState([])
  const [processInfo, setProcessInfo] = useState({})
  const [processInstanceId, setProcessInstanceId] = useState("")
  const [analysisExceptionIsLoading, setAnalysisExceptionIsLoading] = useState(false)
  const [analysisExceptionIsOpen, setAnalysisExceptionIsOpen] = useState(false)
  const [canShowDialogLeavingPage, setCanShowDialogLeavingPage] = useState(false); //TODO: (true) if dynamic form has one change at least.
  const [hardReload, setHardReload] = useState(false)
  /**
   * Hooks
   */
  const [showDialogLeavingPage, confirmNavigation, cancelNavigation] = useNavigatingAway(analysisExceptionIsOpen && !hardReload);



  const isLocatedToAnalysisSectionDirectly = useMemo(() => {
    return (parsed?.jobID && parsed?.processInstanceId && location.hash === "#deployments") ? true : false
  }, [])


  useEffect(() => {
    if (isLocatedToAnalysisSectionDirectly) {
      setAnalysisSectionRevertInProgress(true)
      openAnalyticsPage(parsed?.processInstanceId)
    }
  }, [isLocatedToAnalysisSectionDirectly])

  useEffect(() => {
    if (!analysisExceptionIsOpen)
      setCanShowDialogLeavingPage(false)
  }, [analysisExceptionIsOpen])


  const handleClickDeleteException = useCallback((id, jobId, processInstanceId) => {
    dispatchDelException({ type: "deleteException", payload: { id, jobId, processInstanceId } })
  }, [])

  const onAcceptDeleteException = useCallback((id, jobId, processInstanceId) => {

    dispatchDelException({ type: "onAcceptDeleteException" })
    if (!process.env.NODE_ENV || process.env.NODE_ENV === 'development') {
      //?=================[ DEV ]========================
      setTimeout(() => {
        // dispatchDelException({ type: "onFailureDeleteException", payload: { id, jobId } })
        dispatchDelException({ type: "onSuccessDeleteException", payload: { id, jobId } })
      }, 2000)
    }
    else {
      //?=================[ PROD ]========================
      const headers = { "Content-type": "application/json" }
      const body = {
        jobId: jobId,
        processInstanceId: processInstanceId
      }
      axios
        .post(`/api/deleteExceptionProcess`, body, { headers })
        .then(response => {
          dispatchDelException({ type: "onSuccessDeleteException", payload: { id, jobId } })
        })
        .catch(error => {
          console.log("error: ", error);
          dispatchDelException({ type: "onFailureDeleteException", payload: { id, jobId } })
        })
    }
  }, [])

  const onRejectDeleteException = useCallback(() => {
    dispatchDelException({ type: "onRejectDeleteException" })
  }, [])

  const onCloseDeleteExceptionSuccessFailureModal = useCallback(() => {
    dispatchDelException({ type: "onCloseDeleteExceptionSuccessFailureModal" })
    if (delException?.btnIsSuccess)
      fetchData({ pageSize: 10, pageIndex: 1, filters: [] })
  }, [delException?.btnIsSuccess])


  const openAnalyticsPage = id => {
    if (!process.env.NODE_ENV || process.env.NODE_ENV === 'development') {
      //?=================[ DEV ]========================
      setProcessInstanceId(id)
      setAnalysisExceptionIsOpen(true)
      setAnalysisExceptionIsLoading(true)

      setTimeout(() => {
        const processedApi = ProcessApi({ backendResponse: PtoResponse, type: "exception" })
        setAnalysisExceptionIsLoading(false)
        setDeployments(processedApi.result)
        setProcessInfo(processedApi.processInfo)
      }, 2000)
    }
    else {
      //?=================[ PROD ]========================
      setProcessInstanceId(id)
      setAnalysisExceptionIsOpen(true)
      setAnalysisExceptionIsLoading(true)

      const headers = { "Content-type": "application/json" }
      const body = {
        processInstanceId: id,
        jobId: parsed?.jobID
      }

      axios
        .post(`/api/getExceptionProcessByInstanceIdAndJobId`, body, { headers })
        .then(response => {
          const processedApi = ProcessApi({ backendResponse: response?.data, type: "exception" })
          setAnalysisExceptionIsLoading(false)
          //! DEPRECATED: setDeployments(ProcessApi(response?.data))
          setDeployments(processedApi.result)
          setProcessInfo(processedApi.processInfo)
        })
        .catch(error => {
          setAnalysisExceptionIsLoading(false)
        })
    }
  }

  const columns = useMemo(() => {
    return ([
      {
        Header: 'ID',
        id: "id",
        sortable: true,
        accessor: 'id',
        filterTextVariant: DT_FILTER_LBL_NUMBER_OF_RECORDS,
        filter: 'fuzzyText',
      },
      {
        Header: 'Job ID',
        id: "jobId",
        sortable: true,
        accessor: 'jobId',
        filterTextVariant: DT_FILTER_LBL_NUMBER_OF_RECORDS,
        filter: 'fuzzyText',
      },
      {
        Header: 'Process Instance ID',
        id: "processInstanceId",
        sortable: true,
        accessor: 'processInstanceId',
        filterTextVariant: DT_FILTER_LBL_NUMBER_OF_RECORDS,
        filter: 'fuzzyText',
      },
      {
        Header: 'Project Number',
        id: "projectNum",
        sortable: true,
        accessor: 'projectNum',
        filterTextVariant: DT_FILTER_LBL_NUMBER_OF_RECORDS,
        filter: 'fuzzyText',
      },
      {
        Header: '',
        id: 'actions',
        sortable: false,
        isRowActions: true,
        extraStyles: { zIndex: 1051, width: 150 },
        extraHeaderStyles: { width: "100%", textAlign: "center", pointerEvents: "none" },
        Filter: () => <div className={dtActionClasses.hiddenFilter}></div>,
        accessor: ({ id, jobId, processInstanceId }) => {

          const delExceptionBtnIsSuccess = Boolean(delException.selectedID === id && delException.btnIsSuccess)
          const delExceptionBtnIsLoading = Boolean(delException.selectedID === id && delException.loading)

          return (
            <Stack direction="row" spacing={1} >
              <div>
                <Tooltip
                  placement="left"
                  title={HtmlReactParser(`
                    <div style="text-align: center; padding: 10px 5px">
                      <span style="margin-bottom: 10px; display: inline-block">
                        View Exception Analysis
                      </span>
                      <br /> 
                      <span>
                        For ID: <span style="background: #003660; padding: 2px 5px; border-radius: 50px">${id}</span>
                      </span>
                      and
                      <div style="margin-top: 10px">
                        JobID: <span style="background: #003660; padding: 2px 5px; border-radius: 50px">${jobId}</span>
                      </div>
                    </div>
                  `)}
                >
                  <IconButton
                    className={classes.analysisExceptionBtn}
                    onClick={() => {
                      navigate(`/exceptions?jobID=${parsed?.jobID}&processInstanceId=${processInstanceId}&#deployments`, { replace: true });
                      openAnalyticsPage(processInstanceId)
                    }}
                  >
                    <DynamicFormIcon />
                  </IconButton>
                </Tooltip>
              </div>


              <div>
                <InteractiveButton
                  className={classNames(classes.deleteExceptionBtn, {
                    "success": delExceptionBtnIsSuccess,
                    "loading": delExceptionBtnIsLoading
                  })}
                  variant="round"
                  text="Delete Exception"
                  toolTipTitle={HtmlReactParser(`
                        <div style="text-align: center; padding: 10px 5px">
                          <span style="margin-bottom: 10px; display: inline-block">
                            Delete Exception
                          </span>
                          <br /> 
                          <span>
                            For ID: <span style="background: #f44336; padding: 2px 5px; border-radius: 50px">${id}</span>                                                        
                          </span>
                          and
                          <div style="margin-top: 10px">
                            JobID: <span style="background: #f44336; padding: 2px 5px; border-radius: 50px">${jobId}</span>
                          </div>
                        </div>
                    `)}
                  toolTipPlacement="left"
                  initialIcon={<DeleteExceptionIcon />}
                  successIcon={<CheckIcon />}
                  failureIcon={<CloseIcon />}
                  loading={delExceptionBtnIsLoading}
                  success={delExceptionBtnIsSuccess}
                  failure={Boolean(delException.btnIsSuccess !== null && delException.selectedID === id && !delException.btnIsSuccess)}
                  buttonSuccessClass=""
                  circularProps={{ size: 47, classes: { root: "interactive-spinner" } }}
                  onClick={() => handleClickDeleteException(id, jobId, processInstanceId)}
                  disabled={delException.loading}
                  // disabled={Boolean(migrationBtnSelectedID === id && migrationBtnIsLoading)}
                  containedClasses=""
                />
              </div>
            </Stack>
          )
        }
      }
    ])
  }, [delException.selectedID, delException.open, delException.loading, delException.btnIsSuccess])


  const fetchData = useCallback(({ pageSize, pageIndex, filters }) => {
    setLoading(true)

    if (!process.env.NODE_ENV || process.env.NODE_ENV === 'development') {
      //?=================[ DEV ]========================
      const serverData = makeData(50)
      const fetchId = ++fetchIdRef.current
      setTimeout(() => {
        if (fetchId === fetchIdRef.current) {
          const startRow = pageSize * pageIndex
          const endRow = startRow + pageSize
          setData(serverData.slice(startRow, endRow))
          setPageCount(Math.ceil(serverData.length / pageSize))
          setLoading(false)
        }
      }, 2000)
    }
    else {
      //?=================[ PROD ]========================
      // const body = {
      //   pageIndex: pageIndex,
      //   pageSize: pageSize,
      //   sortBy: [],
      //   filters: filters,
      //   columnOrder: [],
      //   hiddenColumns: []
      // }

      const headers = { "Content-type": "application/json" }
      axios
        .get(`/api/getAllExceptionProcessByJobId/${parsed?.jobID}`, { headers })
        .then(response => {
          setLoading(false)
          setData(response.data)
          // setPageCount(response.data.pagination.pageCount)
        })
        .catch(error => {
          console.log(error)
          setLoading(false)
        })
    }
  }, [])


  const onConfirmNavigation = useCallback(() => {
    //TODO: Go Back to Datatable
    cancelNavigation()
    setDeployments([])
    setAnalysisExceptionIsOpen(false)
    setTimeout(() => {
      setCanShowDialogLeavingPage(false)
      setAnalysisSectionRevertInProgress(false)
    }, 500);
  }, [])

  const onPopState = () => {

    if (!analysisExceptionIsOpen) {
      navigate(`/exceptions?jobID=${parsed?.jobID}`, { replace: true })
      dispatch(ChangeExpandedParentAccordion(null))
      dispatch(ChangeExpandedChildAccordion(null))
    }


    if (!canShowDialogLeavingPage && analysisExceptionIsOpen) {
      // TODO: No changes on Dynamic Form and analysis page is open            
      cancelNavigation()
      setDeployments([])
      setAnalysisExceptionIsOpen(false)
      setTimeout(() => {
        setCanShowDialogLeavingPage(false)
        setAnalysisSectionRevertInProgress(false)
      }, 500);
    }
  }

  useEventListener("popstate", onPopState)


  if (!Boolean(parsed?.jobID)) return (
    <ErrorPage
      errorMessage="Oops!&nbsp;&nbsp;<strong>[ Job ID ]</strong>&nbsp;&nbsp;is not present."
      extraJSX={
        <Link to="/">
          Back to Homepage
        </Link>
      }
    />
  )
  else return (
    <TransitionUpDown
      open={analysisExceptionIsOpen}
      inProgress={analysisSectionRevertInProgress}
    >
      <section id="exceptions-data-table" className={classes.exceptionsRoot} style={{ paddingTop: analysisExceptionIsOpen ? 0 : 50 }}>
        <Container maxWidth="xl">

          <DeleteExceptionDialog
            title="Confirm Delete Exception"
            description={HtmlReactParser(`
              Would you like to delete exception for 
                ID: <strong>${delException.selectedID}</strong>
              and
                JobID: <strong>${delException.selectedJobID}</strong>
              ?
            `)}
            confirmButtonTitle="Yes"
            cancelButtonTitle="No"
            open={delException.open}
            onClose={() => dispatchDelException({ type: "changeOpenState", payload: false })}
            onAccept={() => onAcceptDeleteException(delException.selectedID, delException.selectedJobID, delException.selectedProcessInstanceId)}
            onReject={onRejectDeleteException}
            fullWidth
          />

          <DeleteExceptionSuccessFailureModal
            {...delException.statusModal}
            onCloseModal={onCloseDeleteExceptionSuccessFailureModal}
          />


          <Button
            variant="contained"
            className="add-exception-button"
            onClick={() => navigate({
              pathname: '/add-exception',
              search: new URLSearchParams({ jobID: parsed?.jobID }).toString()
            })}
          >
            <span>
              <AddExceptionIcon />
              Add Exception
            </span>
          </Button>

          <Card style={{ marginTop: 100 }}>
            <div className="card-icon-wrapper">
              <CardIcon color="primary">
                <AssignmentIcon sx={{ color: "#fff" }} />
              </CardIcon>
            </div>
            <CardBody>
              <ReactTable
                columns={columns}
                data={data}
                fetchData={fetchData}
                loading={loading}
                pageCount={pageCount}
                PageSizeList={[10, 20, 25, 50, 75, 100]}
              />
            </CardBody>
            <CardFooter />
          </Card>

        </Container>
      </section>
      <section id="analysis-exceptions">
        <ExceptionsNavigatingAwayContext.Provider value={{
          canShowDialogLeavingPage,
          showDialogLeavingPage: showDialogLeavingPage && canShowDialogLeavingPage,
          confirmNavigation: onConfirmNavigation,
          cancelNavigation,
          setCanShowDialogLeavingPage,
          setHardReload
        }}>
          <DeploymentList
            loading={analysisExceptionIsLoading}
            deployments={deployments}
            processInfo={processInfo}
            jobID={parsed?.jobID}
            viewType="exception"
            processInstanceId={processInstanceId}
          />
        </ExceptionsNavigatingAwayContext.Provider>
      </section>
    </TransitionUpDown >
  )
}

export default memo(Exceptions)
