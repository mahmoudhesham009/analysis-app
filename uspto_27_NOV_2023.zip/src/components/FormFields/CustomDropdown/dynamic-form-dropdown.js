import { memo, useState, useMemo, useCallback } from 'react'
import PropTypes from 'prop-types'
import classNames from 'classnames'
import { FormControl, Select, InputLabel, MenuItem, FormHelperText } from '@mui/material'
// *** Icons ***
import ClearIcon from '@mui/icons-material/Clear'
//*** styles ***
import { createUseStyles } from 'react-jss';
import styles from 'assets/styles/components/FormFields/dynamicFormCustomDropdown.styles'
const useStyles = createUseStyles(styles)


function DynamicFormCustomDropdown({
    items,
    id,
    labelText,
    value,
    error,
    helperText,
    required,
    disabled,
    formControlProps,
    labelProps,
    onOpen,
    onClose,
    onChange,
}) {
    const classes = useStyles()

    const [selectIsOpen, setSelectIsOpen] = useState(false)

    // ************ Callbacks ************
    const handleOpen = useCallback((event) => {
        setSelectIsOpen(true)

        if (onOpen && typeof (onOpen) === "function")
            onOpen(event)
    }, [onOpen])

    const handleClose = useCallback((event) => {
        setSelectIsOpen(false)

        if (onClose && typeof (onClose) === "function")
            onClose(event)
    }, [onClose])


    // ************ Memos ************
    const clearIconClasses = useMemo(() => { return classNames(classes.feedback, { "feedback-error": error }) }, [classes.feedback, error])
    const formControlClasses = useMemo(() => {
        return classNames(classes.formControl, {
            [formControlProps?.className]: typeof (formControlProps) === "object" && formControlProps?.hasOwnProperty('className'),
            "with-error": error,
        })
    }, [classes.formControl, formControlProps, error])

    const menuItemClasses = useMemo(() => { return { selected: classes.menuItemSelected } }, [classes.menuItemSelected])
    const selectClasses = useMemo(() => {
        return {
            select: classes.select,
            error: classes.selectError
            // root: classNames(classes.selectRoot, { "error": error }),
            // select: classes.select,
            // error: classes.selectError,
        }
    }, [classes.select, classes.selectError])

    const labelClasses = useMemo(() => {
        return classNames(classes.labelRoot, {
            "label-error": error,
            "label-with-color": selectIsOpen,
            "label-on-select-open": (selectIsOpen || Boolean(value))
        })
    }, [classes.labelRoot, error, selectIsOpen, value])

    const helperTextClasses = useMemo(() => {
        return classNames(classes.helperText, {
            "helperText-error": error
        })
    }, [classes.helperText, error])



    return (
        <div className={classes.formControlWrapper}>
            <FormControl
                {...formControlProps}
                fullWidth
                className={formControlClasses}
                error={error}
                disabled={disabled}
            >
                {labelText && (
                    <InputLabel
                        {...labelProps}
                        className={labelClasses}
                        htmlFor={id}
                    >
                        {labelText}{required && " *"}
                    </InputLabel>
                )}
                <Select
                    labelId={id}
                    classes={selectClasses}
                    id={id}
                    variant="standard"
                    label={labelText && labelText}
                    value={value}
                    onOpen={handleOpen}
                    onClose={handleClose}
                    onChange={onChange}
                >
                    {items.map((item, Idx) => (
                        <MenuItem
                            key={`${item}-${Idx + 1}`}
                            id={`${item}-${Idx + 1}`}
                            className={classes.selectMenuItem}
                            value={item}
                            title={item}
                            classes={menuItemClasses}
                        >
                            {/* <div style={{ textOverflow: "ellipsis", overflow: "hidden" }}> */}
                            {item}
                            {/* </div> */}
                        </MenuItem>
                    ))}
                </Select>


                {error && (
                    <ClearIcon className={clearIconClasses} />
                )}

                {helperText && (
                    <FormHelperText className={helperTextClasses}>{helperText}</FormHelperText>
                )}
            </FormControl>
        </div>
    )
}


DynamicFormCustomDropdown.defaultProps = {
    variant: "standard",
    maxWidth: "100%"
}

DynamicFormCustomDropdown.propTypes = {
    // id: propTypes.oneOfType([propTypes.string, propTypes.number]),
    // variant: propTypes.oneOf(["filled", "outlined", "standard"]),
    // items: propTypes.arrayOf(propTypes.object).isRequired,
    // value: propTypes.string,
    // onChange: propTypes.func

    items: PropTypes.arrayOf(PropTypes.string).isRequired,
    id: PropTypes.string.isRequired,
    labelText: PropTypes.string,
    value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    error: PropTypes.oneOfType([PropTypes.bool, PropTypes.string]),
    helperText: PropTypes.string,
    fullWidth: PropTypes.bool,
    required: PropTypes.bool,
    formControlProps: PropTypes.object,
    labelProps: PropTypes.object,
    onOpen: PropTypes.func,
    onClose: PropTypes.func,
    onChange: PropTypes.func
}


export default memo(DynamicFormCustomDropdown)