import makeData from 'data/makeData.validationLogs';
import { memo, useState, useRef, useMemo, useReducer, useCallback } from 'react'
import axios from 'axios';
import { useLocation } from 'react-router-dom';
import queryString from 'query-string';
import classNames from 'classnames';
import { Stack } from '@mui/material'
import HtmlReactParser from 'html-react-parser';
//*** custom modals ***
import SuccessFailureModal from 'shared/modals/success-failure.modal';
import AcceptRejectDialog from 'shared/modals/accept-reject.dialog';
//*** components ***
import Card from "components/Card"
import CardIcon from 'components/Card/CardIcon';
import CardBody from "components/Card/CardBody"
import CardFooter from 'components/Card/CardFooter';
import ReactTable from 'components/DataTable'
import StatusCards from 'components/views/logs/statusCards';
import InteractiveButton from 'components/FormFields/CustomButton/InteractiveButton';
// *** hooks ***
import { DT_FILTER_LBL_NUMBER_OF_RECORDS } from 'hooks/useFilterText'
// *** Icons ***
import AssignmentIcon from '@mui/icons-material/Assignment';
import DeleteLogIcon from '@mui/icons-material/DeleteSweepRounded';
import CheckIcon from '@mui/icons-material/Check';
// *** styles ***
import { createUseStyles } from 'react-jss'
import { DataTableActionStyles } from 'assets/styles/components/datatable.styles'
import styles from 'assets/styles/views/logs.styles';
const useDTActionStyles = createUseStyles(DataTableActionStyles)
const useStyles = createUseStyles(styles)


const deleteLogsStatusModalInitialState = {
  open: false,
  status: "",
  title: "",
  description: ""
}

const deleteValidationLogsInitialState = {
  open: false,
  loading: false,
  id: null,
  jobID: null,
  processInstanceID: null,
  processName: null,
  btnIsSuccess: false,
  statusModal: deleteLogsStatusModalInitialState
}


const deleteValidationLogsReducer = (state = deleteValidationLogsInitialState, action) => {
  switch (action.type) {
    case "changeOpenState":
      return { ...state, open: action.payload }
    case "deleteLog":
      return {
        ...state,
        open: true,
        id: action.payload?.id,
        jobID: action.payload?.jobID,
        processInstanceID: action.payload?.processInstanceID,
        processName: action.payload?.processName
      }
    case "onAcceptDeleteLog":
      return { ...state, open: false, loading: true }
    case "onRejectDeleteLog":
      return {
        ...state,
        open: false,
        id: null,
        jobID: null,
        processInstanceID: null,
        processName: null,
      }
    case "onSuccessDeleteLog":
      return {
        ...state,
        loading: false,
        btnIsSuccess: true,
        statusModal: {
          open: true,
          status: "success",
          title: "Invalid tag deleted.",
          description: HtmlReactParser(`Invalid tag for Process <strong>${action.payload?.processInstanceID}</strong> was deleted successfully.`)
        }
      }
    case "onFailureDeleteLog":
      return {
        ...state,
        loading: false,
        btnIsSuccess: false,
        statusModal: {
          open: true,
          status: "fail",
          title: "Invalid tag was not deleted.",
          description: HtmlReactParser(`Could not delete invalid tag for process <strong>${action.payload?.processInstanceID}</strong>.`)
        }
      }
    case "onCloseDeleteLogSuccessFailureModal":
      return {
        ...state,
        btnIsSuccess: false,
        id: null,
        jobID: null,
        processInstanceID: null,
        processName: null,
        statusModal: deleteLogsStatusModalInitialState
      }
    default: return state
  }
}


function ValidationTab() {
  const location = useLocation();
  const parsed = queryString.parse(location.search);
  const fetchIdRef = useRef(0)
  const dtActionClasses = useDTActionStyles()
  const classes = useStyles()

  const [deleteLogs, dispatchDeleteLogs] = useReducer(deleteValidationLogsReducer, deleteValidationLogsInitialState)

  const [data, setData] = useState([])
  const [loading, setLoading] = useState(true)
  const [pageCount, setPageCount] = useState(0)

  const [statusCardVariables, setStatusCardVariables] = useState({
    jobID: parsed?.jobID,
    numOfInvalidProcess: null
  })

  // ***************** MEMOS ***************** 
  const columns = useMemo(() => {
    return ([
      {
        Header: 'Process Instance ID',
        id: "processId",
        sortable: true,
        accessor: 'processId',
        filterTextVariant: DT_FILTER_LBL_NUMBER_OF_RECORDS,
        filter: 'fuzzyText'
      },
      {
        Header: 'Process Name',
        id: "processName",
        sortable: true,
        accessor: 'processName',
        filterTextVariant: DT_FILTER_LBL_NUMBER_OF_RECORDS,
        filter: 'fuzzyText'
      },
      {
        Header: 'Project Number',
        id: "projectNum",
        sortable: true,
        accessor: 'projectNum',
        filterTextVariant: DT_FILTER_LBL_NUMBER_OF_RECORDS,
        filter: 'fuzzyText'
      },
      {
        Header: 'Error Message',
        id: "details",
        sortable: true,
        filterTextVariant: DT_FILTER_LBL_NUMBER_OF_RECORDS,
        filter: 'fuzzyText',
        accessor: ({ details }) => HtmlReactParser(details),
        extraStyles: { width: 600 },
        // accessor: ({ errorMessage }) => (
        //   <div className={classes.errorMessageCol}>{errorMessage}</div>
        // ),
      },
      {
        Header: '',
        id: 'actions',
        sortable: false,
        isRowActions: true,
        extraStyles: { zIndex: 1051 },
        extraHeaderStyles: { width: "100%", textAlign: "center", pointerEvents: "none" },
        Filter: () => <div className={dtActionClasses.hiddenFilter}></div>,
        accessor: ({ id, processId, processName, validate }) => {

          const delLogsBtnIsSuccess = Boolean(deleteLogs.processInstanceID === processId && deleteLogs.processName === processName && deleteLogs.btnIsSuccess)
          const delLogsBtnIsLoading = Boolean(deleteLogs.processInstanceID === processId && deleteLogs.processName === processName && deleteLogs.loading)

          return (
            <Stack direction="row" spacing={1}>
              <InteractiveButton
                className={classNames(classes.deleteLogsBtn, {
                  "success": delLogsBtnIsSuccess,
                  "loading": delLogsBtnIsLoading
                })}
                variant="round"
                text="Delete Log"
                toolTipTitle={HtmlReactParser(`
                    <div style="text-align: center; padding: 10px 5px">
                      <span style="margin-bottom: 10px; display: inline-block">
                        Delete Validation Log
                      </span>
                      <br /> 
                      <span>
                        For Process Instance ID: <span style="background: #f44336; padding: 2px 5px; border-radius: 50px">${processId}</span>                                                        
                      </span>
                      and
                      <div style="margin-top: 10px">
                        Process Name: <span style="background: #f44336; padding: 2px 5px; border-radius: 50px">${processName}</span>
                      </div>
                    </div>
                `)}
                toolTipPlacement="left"
                initialIcon={<DeleteLogIcon />}
                successIcon={<CheckIcon />}
                loading={delLogsBtnIsLoading}
                success={delLogsBtnIsSuccess}
                buttonSuccessClass=""
                circularProps={{ size: 47, classes: { root: "interactive-spinner" } }}
                onClick={() => handleClickDeleteLog(id, parsed?.jobID, processId, processName)}
                disabled={deleteLogs.loading}
                containedClasses=""
              />
            </Stack>
          )
        }
      }
    ])
  }, [deleteLogs.btnIsSuccess, deleteLogs.loading, deleteLogs.processInstanceID, deleteLogs.processName])

  const cardStyle = useMemo(() => { return { marginTop: 100 } }, [])
  const assignmentIconSX = useMemo(() => { return { color: "#fff" } }, [])


  const statusCards = useMemo(() => {
    return [
      {
        id: "jobID",
        themeColor: "theme-purple",
        innerText: statusCardVariables?.jobID,
        descrption: "Job ID",
      },
      {
        id: "invalidProcesses",
        themeColor: "theme-danger",
        innerText: statusCardVariables?.numOfInvalidProcess,
        descrption: "Invalid Processes"
      },
    ]
  }, [statusCardVariables?.jobID, statusCardVariables?.numOfInvalidProcess])

  // ***************** CALLBACKS ***************** 
  const fetchData = useCallback(({ pageSize, pageIndex, filters }) => {
    setLoading(true)

    if (!process.env.NODE_ENV || process.env.NODE_ENV === 'development') {
      //?=================[ DEV ]========================
      const serverData = makeData(50)
      const fetchId = ++fetchIdRef.current
      setTimeout(() => {
        if (fetchId === fetchIdRef.current) {
          const startRow = pageSize * pageIndex
          const endRow = startRow + pageSize
          setData(serverData.slice(startRow, endRow))
          setPageCount(Math.ceil(serverData.length / pageSize))
          setLoading(false)
          setStatusCardVariables({
            jobID: parsed?.jobID,
            numOfInvalidProcess: Math.floor(Math.random() * (1000 - 50 + 1) + 50),
          })
        }
      }, 2000)
    }
    else {
      //?=================[ PROD ]========================
      // // const body = {
      // //   pageIndex: pageIndex,
      // //   pageSize: pageSize,
      // //   sortBy: [],
      // //   filters: filters,
      // //   columnOrder: [],
      // //   hiddenColumns: []
      // // }

      const headers = { "Content-type": "application/json" }
      axios
        .get(`/api/ValidationReport/${parsed?.jobID}`, { headers })
        .then(response => {
          setLoading(false)
          setData(response?.data)

          setStatusCardVariables({
            jobID: parsed?.jobID,
            numOfInvalidProcess: Array.isArray(response?.data) ? response?.data?.length : null
          })

          // setPageCount(response.data.pagination.pageCount)
        })
        .catch(error => {
          console.log(error)
          setLoading(false)
        })
    }
  }, [parsed?.jobID])

  const handleClickDeleteLog = useCallback((id, jobID, processInstanceID, processName) => {
    dispatchDeleteLogs({ type: "deleteLog", payload: { id, jobID, processInstanceID, processName } })
  }, [])

  const onAcceptDeleteLog = useCallback((id, jobID, processInstanceID, processName) => {
    dispatchDeleteLogs({ type: "onAcceptDeleteLog" })
    if (!process.env.NODE_ENV || process.env.NODE_ENV === 'development') {
      //?=================[ DEV ]========================
      setTimeout(() => {
        dispatchDeleteLogs({ type: "onSuccessDeleteLog", payload: { processInstanceID } })
        // dispatchDeleteLogs({ type: "onFailureDeleteLog", payload: { processInstanceID } })
      }, 2000)
    }
    else {
      //?=================[ PROD ]========================
      const headers = { "Content-type": "application/json" }

      axios
        .delete(`/api/deleteValidation/${id}`, { headers })
        .then(response => {
          dispatchDeleteLogs({ type: "onSuccessDeleteLog", payload: { processInstanceID } })
        })
        .catch(error => {
          console.log("error: ", error);
          dispatchDeleteLogs({ type: "onFailureDeleteLog", payload: { processInstanceID } })
        })
    }
  }, [])

  const onRejectDeleteLog = useCallback(() => {
    dispatchDeleteLogs({ type: "onRejectDeleteLog" })
  }, [])

  const onCloseDeleteLogSuccessFailureModal = useCallback(() => {
    dispatchDeleteLogs({ type: "onCloseDeleteLogSuccessFailureModal" })

    if (deleteLogs.statusModal.status === "success")
      fetchData({ pageSize: 10, pageIndex: 1, filters: [] })
  }, [deleteLogs.statusModal.status])


  return (
    <div id="valiadtion-tab">
      <StatusCards
        cards={statusCards}
      />

      <AcceptRejectDialog
        title="Confirm deletion of invalid tag"
        description={HtmlReactParser(`Are you sure you want to remove the invalid tag for process <strong>${deleteLogs.processInstanceID}</strong>? If yes, this process will be included in the migration.`)}
        confirmButtonTitle="Yes"
        cancelButtonTitle="No"
        open={deleteLogs.open}
        onClose={() => dispatchDeleteLogs({ type: "changeOpenState", payload: false })}
        onAccept={() => onAcceptDeleteLog(deleteLogs?.id, deleteLogs.jobID, deleteLogs.processInstanceID, deleteLogs.processName)}
        onReject={onRejectDeleteLog}
        fullWidth
      />


      <SuccessFailureModal
        {...deleteLogs.statusModal}
        onCloseModal={onCloseDeleteLogSuccessFailureModal}
      />

      <Card style={cardStyle}>
        <div className="card-icon-wrapper">
          <CardIcon color="primary">
            <AssignmentIcon sx={assignmentIconSX} />
          </CardIcon>
        </div>
        <CardBody>
          <ReactTable
            columns={columns}
            data={data}
            fetchData={fetchData}
            loading={loading}
            pageCount={pageCount}
            PageSizeList={[10, 20, 25, 50, 75, 100]}
          />
        </CardBody>
        <CardFooter />
      </Card>
    </div>
  )
}

export default memo(ValidationTab)
