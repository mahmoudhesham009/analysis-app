/**
 * TODO: List of Forms inside each Deployment tab
*/
import { memo, useState, useRef, useCallback } from 'react'
import axios from 'axios';
import _ from 'lodash';
import { Accordion, AccordionDetails, AccordionSummary, Typography } from '@mui/material'
// *** redux ***
import { useSelector, useDispatch } from 'react-redux'
import { ChangeExpandedChildAccordion } from '@redux'
// *** components ***
import DynamicForm from './dynamic-form'
// *** modals ***
import SuccessFailureModal from 'shared/modals/success-failure.modal';
// *** Icons ***
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import moment from 'moment';


const saveModalInitialState = {
    formId: null,
    open: false,
    status: undefined,
    title: "",
    description: ""
}

function DeploymentFormList({ formData, deploymentId, jobID, viewType, processInstanceId, projectNum }) {

    const dispatch = useDispatch()
    const { expandedChild } = useSelector(state => state.analysis)


    const formikRef = useRef(null)
    const [saveModal, setSaveModal] = useState(saveModalInitialState)
    const [successfullySaved, setSuccessfullySaved] = useState(false)
    const [hardReload, setHardReload] = useState(false)


    const handleAccordionChange = (panel) => (event, isExpanded) => {
        dispatch(ChangeExpandedChildAccordion(isExpanded ? panel : false))
    };

    const handleCloseModal = () => {
        setSaveModal(saveModalInitialState)
        if (successfullySaved){
            setSuccessfullySaved(false)
            setHardReload(true)
        }
    }

    const onSubmit = useCallback((values, { formId, valueTypes }) => {

        const headers = { 'Content-Type': 'application/json' }
        const body = {
            "taskDef": formId,
            "deploymentID": deploymentId,
            "jobID": jobID,
            "viewType": viewType === "add-exception" ? "exception" : viewType,
            "processInstanceId": processInstanceId,
            "projectNum": projectNum,
            "formValues": _.map(values, (value, id) => { return { id, value: valueTypes[id] === "date" ? value === null ? "" : moment(value).format("YYYY-MM-DD") : value } })
        }


        axios
             .patch(`/api/update/${jobID}`, body, { headers })
             .then(response => {
                 formikRef.current.setSubmitting(false)
                 setSuccessfullySaved(true)
                 setSaveModal({
                     formId: formId,
                     open: true,
                     status: "success",
                     title: "Success",
                     description: "Data was saved successfully."
                 })
             })
             .catch(error => {
                 formikRef.current.setSubmitting(false)
                 setSaveModal({
                     formId: formId,
                     open: true,
                     status: "failure",
                     title: "Failure",
                     description: "Something went wrong while saving data."
                 })
             })
    })

    return formData.map(({ deltaType, formFields, formKey, valueTypes, initialValues, taskDef, taskName, validationSchema }) => (
        <div key={`dynamic-form-${formKey}`}>
            {saveModal.formId === formKey && (
                <SuccessFailureModal
                    {...saveModal}
                    onCloseModal={handleCloseModal}
                />
            )}
            <Accordion
                expanded={expandedChild === formKey}
                onChange={handleAccordionChange(formKey)}
                TransitionProps={{ unmountOnExit: true }}
            >
                <AccordionSummary id={`${formKey}-panel-header`} expandIcon={<ExpandMoreIcon />}>
                    <Typography sx={{ width: '33%', flexShrink: 0 }}>
                        <strong>{taskDef}</strong>
                    </Typography>

                    <Typography sx={{ color: 'text.secondary' }}>
                        {taskName}
                    </Typography>
                </AccordionSummary>
                <AccordionDetails>

                    <DynamicForm
                        ref={formikRef}
                        viewType={viewType}
                        formId={formKey}
                        valueTypes={valueTypes}
                        hardReload={hardReload}
                        initialValues={initialValues}
                        validationSchema={validationSchema}
                        formFields={formFields}
                        onSubmit={onSubmit}
                    />

                </AccordionDetails>
            </Accordion>
        </div>
    ))
}


DeploymentFormList.defaultProps = {
    processInstanceId: "",
    projectNum: ""
}

export default memo(DeploymentFormList)
