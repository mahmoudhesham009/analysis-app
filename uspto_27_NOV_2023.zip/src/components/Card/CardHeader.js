import { memo } from "react";
import classNames from "classnames";
import PropTypes from "prop-types";
// *** styles ***
import { createUseStyles } from 'react-jss';
import styles from "assets/styles/components/Card/cardHeader.styles";
const useStyles = createUseStyles(styles);



function CardHeader({ className, children, color, plain, stats, icon }) {

    // import { whiteColor, blackColor, hexToRgb } from 'assets/theme'
    //   const globalTheme = useGlobalTheme()
    //   const gThemeOverrides = useMemo(() => {
    //     return {
    //       systemTheme: {
    //         color: whiteColor,
    //         background: globalTheme.systemTheme.gradient + "!important",
    //         boxShadow: "0 4px 20px 0 rgba(" + hexToRgb(blackColor) + ",.14), 0 7px 10px -5px rgba(" + hexToRgb(globalTheme.systemTheme.color) + ",.4)"
    //         "&:not($cardHeaderIcon)": {
    //            background: globalTheme.systemTheme.gradient + "!important",
    //            boxShadow: "0 4px 20px 0 rgba(" + hexToRgb(blackColor) + ",.14), 0 7px 10px -5px rgba(" + hexToRgb(globalTheme.systemTheme.color) + ",.4)"
    //         }
    //       }
    //     }
    //   }, [globalTheme])
    //   const useGlobalStyles = makeStyles(gThemeOverrides)
    //   const globalThemeClasses = useGlobalStyles()



    const classes = useStyles();
    const cardHeaderClasses = classNames({
        [classes.cardHeader]: true,
        [classes[color + "CardHeader"]]: color,
        // [globalThemeClasses.systemTheme]: systemTheme,
        [classes.cardHeaderPlain]: plain,
        [classes.cardHeaderStats]: stats,
        [classes.cardHeaderIcon]: icon,
        [className]: className !== undefined
    });
    return (
        <div className={cardHeaderClasses}>
            {children}
        </div>
    );
}

CardHeader.propTypes = {
    className: PropTypes.string,
    color: PropTypes.oneOf([
        "warning",
        "success",
        "danger",
        "info",
        "primary",
        "rose",
    ]),
    systemTheme: PropTypes.bool,
    plain: PropTypes.bool,
    stats: PropTypes.bool,
    icon: PropTypes.bool,
    children: PropTypes.node
};

export default memo(CardHeader)