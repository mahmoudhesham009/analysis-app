import theme from 'assets/styles/theme'


const DynamicFormCustomDropdownStyles = {
    formControlWrapper: {
        marginTop: 15,
        marginBottom: 8
    },
    formControl: {
        paddingBottom: 0,
        "&.remove-bottom-padding": {
            paddingBottom: 0,
        },
        "& > div": {
            "&:before": {
                borderColor: theme.colors.gray[4] + " !important",
            },
            "&:hover:not($disabled):before, &:before": {
                borderColor: theme.colors.gray[4] + " !important",
                borderWidth: "1px !important"
            },
            "&:after": {
                borderBottomWidth: "2px !important",
                borderColor: theme.colors.primary[0] + "!important"
            },
            "&:hover": {
                "&:before": {
                    borderBottom: "1px solid rgba(0, 0, 0, 0.42) !important"
                }
            },
        },
        "&.with-error": {
            "& > div": {
                "&:hover:not($disabled):before, &:before": {
                    borderWidth: "2px !important",
                    borderColor: theme.colors.danger[0] + " !important",
                },
                "&:after": {
                    borderWidth: "2px !important",
                    borderColor: theme.colors.danger[0] + " !important",
                },
            }
        }
    },
    select: {
        "&:focus": {
            backgroundColor: "transparent !important"
        },
    },
    selectError: {
        "&:after, &:before, &:hover:not($disabled):before": {
            borderBottomWidth: "2px !important",
            borderColor: theme.colors.danger[0] + "!important"
        },
        "& svg": {
            color: theme.colors.danger[0] + "!important"
        }
    },
    menuItemSelected: {
        backgroundColor: theme.colors.primary[0] + "!important",
        color: theme.colors.white + "!important"
    },
    labelRoot: {
        "-webkit-transform": "translate(0px, 16px) scale(1)",
        "-moz-transform": "translate(0px, 16px) scale(1)",
        "-ms-transform": "translate(0px, 16px) scale(1)",
        "-o-transform": "translate(0px, 16px) scale(1)",
        transform: "translate(0px, 16px) scale(1)",
        // ...defaultFont,
        color: theme.colors.gray[3] + " !important",
        fontWeight: "400",
        fontSize: 16,
        lineHeight: "1.42857",
        letterSpacing: "unset",
        "&.label-on-select-open": {
            fontSize: 12,
            "-webkit-transform": "translate(0px, 2px) scale(.9)",
            "-moz-transform": "translate(0px, 2px) scale(.9)",
            "-ms-transform": "translate(0px, 2px) scale(.9)",
            "-o-transform": "translate(0px, 2px) scale(.9)",
            transform: "translate(0px, 2px) scale(.9)"
        },
        "&.label-with-color": {
            color: theme.colors.primary[0] + "!important",
        },
        "&.label-error": {
            color: theme.colors.danger[0] + "!important"
        },
    },
    helperText: {
        marginLeft: 0,
        color: theme.colors.gray[4],
        "&.helperText-error": {
            color: theme.colors.danger[0]
        }
    },
    feedback: {
        position: "absolute",
        top: 22,
        right: 22,
        zIndex: "2",
        display: "block",
        width: 24,
        height: 24,
        textAlign: "center",
        pointerEvents: "none",
        "&.feedback-error": {
            color: theme.colors.danger[0]
        }
    },
}


export default DynamicFormCustomDropdownStyles