import extraCommonDTStyles from 'assets/styles/shared/commonDatatableComponents.styles';


const ExceptionsStyles = theme => ({
    exceptionsRoot: {
        paddingTop: 50,
        overflowY: "auto",
        "& .add-exception-button": {
            backgroundColor: theme.colors.primary[0],
            paddingLeft: 6,
            paddingRight: 10,
            boxShadow: "unset",
            "& svg": {
                verticalAlign: "middle",
                marginTop: -3,
                paddingRight: 5
            },
        },
        "& .card-icon-wrapper": {
            display: "inline-block",
            marginRight: 20,
            "& > div": {
                float: "right"
            }
        }
    },
    deleteExceptionBtn: {
        ...extraCommonDTStyles(theme).interactiveButton(theme.colors.rose[0]),
    },
    analysisExceptionBtn: {
        ...extraCommonDTStyles(theme).regularButton,
    }
})



export default ExceptionsStyles