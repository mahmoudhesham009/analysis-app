import * as Yup from 'yup'
import _ from 'lodash';

/**
 * @author Na'oum Haddad <mailto:e.naoumhaddad@outlook.com>
 * @type {Predicate}
 * @param {array} deployments 
 * @param {object} processInfo 
 * @example =>=>=> You can find full api response example at "src/config/new-pto-Json.json"
 * @returns Processed api for (analysis page) received from "Backed" to "Frontend".
 */
function ProcessDynamicForm(apiResponse) {
    const result = []

    apiResponse.map(({ DeploymentId, processVersion, processName, data }) => { // map on each deployment

        if (Array.isArray(data)) {
            if (data.length > 0) {
                const formData = []

                Object.keys(data[0]).map(taskKey => { // map on data tasks
                    const valueTypes = {}
                    const formContent = {}
                    const initialValues = {}
                    const validationSchema = {}
                    const formFields = []
                    const { formFieldList, ...props } = data[0][taskKey]

                    formFieldList.map(({ id, name, required, type, value, ...props }) => {
                        formFields.push({
                            id,
                            name,
                            required,
                            type: type === "text" && Array.isArray(props?.choices) ? "dropdown" : type,
                            value: type === "boolean" ? String(value).toLocaleLowerCase() === "false" ? false : Boolean(value) : value,
                            ...props
                        })
                        _.assign(valueTypes, { [id]: type })

                        if (type === "boolean") {
                            _.assign(initialValues, { [id]: String(value).toLocaleLowerCase() === "false" ? false : Boolean(value) })
                            if (required) {
                                // _.assign(validationSchema, { [id]: Yup.boolean().required("Required Field.") })
                                _.assign(validationSchema, { [id]: Yup.boolean().oneOf([true], `You must check the \`${name}\` before continue.`) })
                            }
                        }
                        else if (type === "date") {
                            _.assign(initialValues, { [id]: String(new Date(value)) !== "Invalid Date" ? String(value) : null })
                            const defaultDateValidation = Yup.date()
                                .nullable()
                                .min("01-01-1900", "Date is too short.")
                                .max("12-31-2100", "Date is too intense.")
                                .typeError("Invalid Date.")

                            if (required)
                                _.assign(validationSchema, { [id]: defaultDateValidation.required("Required Field.") })
                            else
                                _.assign(validationSchema, { [id]: defaultDateValidation })
                        }
                        else {
                            _.assign(initialValues, { [id]: value })
                            if (required) {
                                _.assign(validationSchema, { [id]: Yup.string().required("Required Field.") })
                            }
                        }
                    })

                    _.assign(formContent, { valueTypes: valueTypes })
                    _.assign(formContent, { initialValues: initialValues })
                    _.assign(formContent, { validationSchema: Yup.object(validationSchema) })
                    _.assign(formContent, { formFields: formFields })
                    _.assign(formContent, { formKey: taskKey, ...props })

                    formData.push(formContent)
                })

                result.push({ DeploymentId, processVersion, processName, formData })
            }
        }
    })

    return result
}

export default function AnalysisPageApiProcessing({ backendResponse, type }) {
    if (type === "exception" || type === "add-exception") {
        const { deployments, processInfo } = backendResponse

        if (!Array.isArray(deployments))
            throw new Error("Could not receive analysis deployments as array, please contact administrator or try again later.")
        else return {
            result: ProcessDynamicForm(deployments),
            processInfo
        }
    }
    else {
        if (!Array.isArray(backendResponse))
            throw new Error("Could not receive response as array, please contact administrator or try again later.")
        else return ProcessDynamicForm(backendResponse)
    }
}