import { memo, useState, useEffect, useCallback, useContext } from 'react'
import PropTypes from 'prop-types'
import { FilterContext } from '../index'
import CustomInput from 'components/FormFields/CustomInput'
import useFilterText from 'hooks/useFilterText'
import { ThemeProvider, createTheme } from '@mui/material/styles';


const theme = createTheme({
    components: {
        MuiFormControl: {
            styleOverrides: {
                root: {
                    margin: 0,
                    padding: "3px 0px 0px 0px !important"
                }
            }
        }
    }
})

function DefaultColumnFilter({ column: { filterValue, preFilteredRows, setFilter, filterTextVariant, filterTextToDisplay } }) {

    const filterContextConsumer = useContext(FilterContext)

    const [labelText] = useFilterText(
        filterTextVariant ? filterTextVariant : "",
        filterTextToDisplay ? filterTextToDisplay : "",
        preFilteredRows.length ? preFilteredRows.length : 0
    )

    const [value, setValue] = useState(filterValue || '');

    useEffect(() => {
        if (Boolean(value)) {
            const timeoutId = setTimeout(() => setFilter(value), 1000);
            return () => clearTimeout(timeoutId);
        }
        else setFilter(null)

    }, [value])


    // TODO: reset filter value when data table is resetting all filters
    useEffect(() => { if (filterContextConsumer) setValue('') }, [filterContextConsumer])

    const handleChange = useCallback(e => setValue(e.target.value || undefined), [filterValue])

    return (
        <ThemeProvider theme={theme}>
            <CustomInput
                labelText={labelText}
                value={value}
                onChange={handleChange}
                fullWidth
            />
        </ThemeProvider>
    )
}

DefaultColumnFilter.propTypes = {
    column: PropTypes.object.isRequired
}

export default memo(DefaultColumnFilter)
