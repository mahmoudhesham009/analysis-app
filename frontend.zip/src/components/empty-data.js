import React from 'react'
// *** Icons ***
import { Typography, Button } from '@mui/material';
import ArchiveIcon from '@mui/icons-material/Archive';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
// *** styles ***
import { createUseStyles } from 'react-jss';
import styles from 'assets/styles/components/emptyData.styles';
const useStyles = createUseStyles(styles)

function EmptyData() {
    const classes = useStyles()

    return (
        <div className={classes.emptyDataRoot}>
            <ArchiveIcon />
            <Typography variant="h4" component="h4">
                No Data
            </Typography>
            <Button variant='outlined' onClick={() => { window.location.href = "/" }}>
                <ArrowBackIcon />
                Back to Homepage
            </Button>
        </div>
    )
}

export default EmptyData
