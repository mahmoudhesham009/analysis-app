import namor from 'namor'
import { randomDates, range } from './common';



const newRecord = (isSingleProcess) => {
    return {
        id: Math.floor(Math.random() * 1000),
        fromDate: isSingleProcess ? null : randomDates[Math.floor(Math.random() * (randomDates.length - 1))],
        toDate: isSingleProcess ? null : randomDates[Math.floor(Math.random() * (randomDates.length - 1))],
        processName: isSingleProcess ? namor.generate({ words: 0, saltLength: Math.floor((Math.random() * (60 - 4)) + 4) }) : null,
        createdDate: randomDates[Math.floor(Math.random() * (randomDates.length - 1))],
        modifyDate: randomDates[Math.floor(Math.random() * (randomDates.length - 1))],
        status: Math.floor(Math.random() * 1000) % 2 === 0 ? "In Progress" : "migrationFinished"
    }
}



export default function makeData(...lens) {

    const makeDataLevel = (depth = 0) => {
        const len = lens[depth]
        return range(len).map(d => {
            const isSingleProcess = Math.floor(Math.random() * 1000) % 2 === 0
            return {
                ...newRecord(isSingleProcess),
                subRows: lens[depth + 1] ? makeDataLevel(depth + 1) : undefined,
            }
        })
    }

    return makeDataLevel()
}
