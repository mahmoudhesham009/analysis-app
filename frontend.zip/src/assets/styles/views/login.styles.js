const LoginStyles = theme => ({
    loginRoot: {
        height: "100vh",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: theme.colors.gray[8],
        "& .website-logo-horiz": {
            marginBottom: 25,
            maxWidth: 350
        },
        "& .card-icon-wrapper": {
            display: "inline-block",
            marginRight: 5,
            "& > div": {
                float: "right"
            }
        },
        "& .login-card": {
            maxWidth: 500,
            margin: "0 auto",
            boxShadow: "0px 0px 10px #000",
            "& .login-btn-wrapper": {
                marginTop: 10
            }
        },
        "& .copyright": {
            fontSize: 12,
            textAlign: "center",
            flex: "0 0 100%"
        }
    }
})

export default LoginStyles