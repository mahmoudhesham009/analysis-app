import extraCommonDTStyles from 'assets/styles/shared/commonDatatableComponents.styles';

const LogsStyles = theme => ({
    logsRoot: {
        paddingTop: 50,
        "& .card-icon-wrapper": {
            display: "inline-block",
            marginRight: 20,
            "& > div": {
                float: "right"
            }
        }
    },
    deleteLogsBtn: {
        ...extraCommonDTStyles(theme).interactiveButton(theme.colors.rose[0]),   
    },
    disabledDeleteLogsBtn: {
        backgroundColor: "rgba(233,30,99,0.3) !important"
    }
    // errorMessageCol: {
    //     whiteSpace: "nowrap",
    //     textOverflow: "ellipsis",
    //     overflow: "hidden",
    //     maxWidth: 300
    // }
})



const LogsInfoStyles = theme => ({
    infoCardsRoot: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        "& .info-card": {
            padding: 15,
            flex: "0 0 25%",
            maxWidth: "25%",
            overflow: "hidden",
            textOverflow: "ellipsis",
            whiteSpace: "nowrap",
            "& span": {
                ...theme.fonts.comfortaa,
                fontSize: 40,
                fontWeight: "bold",
                color: "inherit"
            },
            "& p": {
                ...theme.fonts.comfortaa,
                color: "inherit",
                margin: "10px 0px 0px 0px",
                fontSize: 18,
                fontWeight: 900,
                // textTransform: "uppercase",
                "-webkit-text-stroke": ".5px"
            },
            "&:first-child": {
                borderRadius: "6px 0px 0px 6px"
            },
            "&:last-child": {
                borderRadius: "0px 6px 6px 0px"
            },
            "&.theme-purple": {
                backgroundColor: "#b39ddb",
                color: "#311b92"
            },
            "&.theme-info": {
                backgroundColor: "#33bfff",
                color: "#007bb2"
            },
            "&.theme-success": {
                backgroundColor: "#6fbf73",
                color: "#357a38"
            },
            "&.theme-danger": {
                backgroundColor: "#f44336",
                color: theme.colors.white,
            },
        }
    }
})

export { LogsInfoStyles }
export default LogsStyles