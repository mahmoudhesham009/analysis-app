import React, { useState } from 'react'
import { Formik, Form, Field } from 'formik';
import * as Yup from 'yup';
import { IconButton, InputAdornment, Alert, Collapse } from '@mui/material';
// *** Hooks ***
import useAuthentication from 'hooks/redux-hook/useAuthentication';
// *** Components ***
import RedditTextField from 'components/FormFields/CustomInput/RedditTextField';
import CustomButton from 'components/FormFields/CustomButton';
import Card from 'components/Card';
import CardBody from 'components/Card/CardBody';
import CardFooter from 'components/Card/CardFooter';
import CardIcon from 'components/Card/CardIcon';
// *** Icons ***
import Visibility from '@mui/icons-material/VisibilityRounded';
import VisibilityOff from '@mui/icons-material/VisibilityOffRounded';
import KeyIcon from '@mui/icons-material/VpnKeyRounded';
import LoginIcon from '@mui/icons-material/Login';
import Spinner from 'components/spinner'
import WebsiteLogoHoriz from 'assets/images/website-logo-horiz.png';
// *** Styles  ***
import { createUseStyles } from 'react-jss';
import styles from 'assets/styles/views/login.styles';
const useStyles = createUseStyles(styles)


const initialValues = { username: "", password: "" }
const validationSchema = Yup.object({
    username: Yup.string().required("Required Field!"),
    password: Yup.string().required("Required Field!")
})

function Login() {
    const classes = useStyles()
    const { LoginToSystem } = useAuthentication()
    const [showPassword, setShowPassword] = useState(false)
    const [alert, setAlert] = useState({
        open: false,
        severity: "error",
        message: ""
    })


    const onSubmit = ({ username, password }, { setSubmitting }) => {
        setTimeout(() => {
            setSubmitting(false)
            if (username === "uspto" && password === "uspto")
                LoginToSystem()                  
            else {
                setAlert({
                    open: true,
                    severity: "error",
                    message: "Invalid Username or Password."
                })
            }
        }, 2000);
    }


    return (
        <div className={classes.loginRoot}>
            <div>
                <img
                    className="website-logo-horiz"
                    src={WebsiteLogoHoriz}
                    alt="United States Patent and Trademark Office"
                />
                <Card className="login-card">
                    <div className="card-icon-wrapper">
                        <CardIcon className="card-icon" color="primary">
                            <KeyIcon sx={{ color: "#fff" }} />
                        </CardIcon>
                    </div>
                    <CardBody>
                        <Collapse in={alert.open}>
                            <Alert variant="outlined" severity={alert.severity}>
                                {alert.message}
                            </Alert>
                        </Collapse>
                        <Formik
                            initialValues={initialValues}
                            validationSchema={validationSchema}
                            onSubmit={onSubmit}
                        >
                            {formik => {
                                return (
                                    <Form>
                                        <Field name="username">
                                            {({ field, form, meta }) => (
                                                <RedditTextField
                                                    labelText="Username"
                                                    fullWidth
                                                    required
                                                    error={Boolean(formik.touched.username && formik.errors.username)}
                                                    disabled={formik.isSubmitting}
                                                    helperText={formik.touched.username && formik.errors.username ? formik.errors.username : ""}
                                                    {...formik.getFieldProps("username")}
                                                />
                                            )}
                                        </Field>

                                        <Field name="password">
                                            {({ field, form, meta }) => (
                                                <RedditTextField
                                                    type={showPassword ? "text" : "password"}
                                                    labelText="Password"
                                                    fullWidth
                                                    required
                                                    autoComplete="off"
                                                    error={Boolean(formik.touched.password && formik.errors.password)}
                                                    disabled={formik.isSubmitting}
                                                    helperText={formik.touched.password && formik.errors.password ? formik.errors.password : ""}
                                                    {...formik.getFieldProps("password")}
                                                    endAdornment={
                                                        <InputAdornment position="end" sx={{ mr: 1 }}>
                                                            <IconButton
                                                                aria-label="toggle password visibility"
                                                                onClick={() => setShowPassword(!showPassword)}
                                                                onMouseDown={event => event.preventDefault()}
                                                                disabled={formik.isSubmitting}
                                                                edge="end"
                                                            >
                                                                {showPassword ? <Visibility /> : <VisibilityOff />}
                                                            </IconButton>
                                                        </InputAdornment>
                                                    }
                                                />
                                            )}
                                        </Field>

                                        <div className="login-btn-wrapper">
                                            <CustomButton
                                                startIcon={formik.isSubmitting ? <Spinner type="special-icon" /> : <LoginIcon />}
                                                variant="contained"
                                                color="primary"
                                                type="submit"
                                                innerContent="Login"
                                                size="large"
                                                disabled={formik.isSubmitting}
                                            />
                                        </div>
                                    </Form>
                                )
                            }}
                        </Formik>
                    </CardBody>
                    <CardFooter />
                </Card>
            </div>
        </div>
    )
}

export default React.memo(Login)