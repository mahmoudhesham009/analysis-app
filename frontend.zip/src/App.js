import React, { useState } from 'react';
import { Detector } from 'react-detect-offline'
import { HashRouter, Routes as Switch, Route } from 'react-router-dom';
import { ThemeProvider } from "react-jss";
import publicRoutes from 'routes/public.routes';
import protectedRoutes from 'routes/protected.routes';
// *** layout ***
import Layout from 'layout';
// *** components ***
import SnackbarConnection from 'components/snackbar-connection'
// *** Hooks ***
import useWindowWidth from 'hooks/useWindowWidth'
import useAuthentication from 'hooks/redux-hook/useAuthentication';
// *** styles ***
import theme from 'assets/styles/theme'
import 'normalize.css'
import 'assets/styles/css/global.css'
// *** Contexts ***
const WindowContext = React.createContext()
const ConnectionContext = React.createContext()

function App() {  
  const windowWidth = useWindowWidth()
  const { authState: { isLoggedIn } } = useAuthentication()
  const [gotConnectionRefused, setGotConnectionRefused] = useState(false)


  return (
    <Detector
      onChange={() => setGotConnectionRefused(true)}
      render={({ online }) => {
        return (
          <ThemeProvider theme={theme}>
            <ConnectionContext.Provider value={{ isOnline: online }}>
              <WindowContext.Provider value={{ windowWidth }}>
                <HashRouter window={window}>
                  <Switch>
                    <Route path="/" element={<Layout isLoggedIn={isLoggedIn} />}>
                      {isLoggedIn ?
                        protectedRoutes.map(({ id, path, element }) => {
                          return <Route key={`route-page-${id}`} path={path} element={element} />
                        })
                        :
                        publicRoutes.map(({ id, path, element }) => {
                          return <Route key={`route-page-${id}`} path={path} element={element} />
                        })}
                    </Route>
                  </Switch>
                </HashRouter>

                <SnackbarConnection
                  isOnline={online}
                  gotConnectionRefused={gotConnectionRefused}
                />
              </WindowContext.Provider>
            </ConnectionContext.Provider>
          </ThemeProvider >
        )
      }}
    />
  )
}





export { WindowContext, ConnectionContext }
export default React.memo(App)
