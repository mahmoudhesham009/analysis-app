import { memo } from 'react'
import classNames from "classnames";
import PropTypes from "prop-types";
//*** styles ***
import { createUseStyles } from 'react-jss';
import styles from "assets/styles/components/Card/card.styles";
const useStyles = createUseStyles(styles);

function Card({ className, children, plain, profile, chart }) {
    const classes = useStyles();    
    const cardClasses = classNames({
        [classes.card]: true,
        [classes.cardPlain]: plain,
        [classes.cardProfile]: profile,
        [classes.cardChart]: chart,
        [className]: className !== undefined
    });

    return (
        <div className={cardClasses}>
            {children}
        </div>
    )
}


Card.propTypes = {
    className: PropTypes.string,
    plain: PropTypes.bool,
    profile: PropTypes.bool,
    chart: PropTypes.bool,
    children: PropTypes.node
};

export default memo(Card)