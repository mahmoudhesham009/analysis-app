import React from 'react'
import classNames from 'classnames'
import PropTypes from 'prop-types'
import { TextField, FormHelperText, Zoom } from '@mui/material';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers';
// *** styles ***
import commonStyles from 'assets/styles/components/FormFields/common.styles'
import { ThemeProvider, createTheme } from '@mui/material/styles'
import { MuiDatePickerStyles, defaultMaterialThemeStyles } from 'assets/styles/components/FormFields/datepicker.styles'
import { createUseStyles, useTheme } from 'react-jss';
const useStyles = createUseStyles(MuiDatePickerStyles)
const useCommonStyles = createUseStyles(commonStyles)


/**
 * TODO: Datepicker for formik component.
 * @author Na'oum Haddad <mailto:e.naoumhaddad@outlook.com> 
 * @type {Predicate}
 * @param {{ variant: "filled" | "outlined" | "standard"; }} props Props for the component 
 */
function FormikDatePicker(props) {
    const { id, labelText, value, variant, format, fullWidth, disabled, error, helperText, dynamicForm, onChange, onBlur, setFieldTouched, handleFormChange } = props

    const classes = useStyles()
    const commonClasses = useCommonStyles()
    const systemTheme = useTheme()
    const theme = createTheme({
        palette: {
            ...defaultMaterialThemeStyles(systemTheme).palette
        },
        components: {
            ...defaultMaterialThemeStyles(systemTheme).components,
        }
    });



    return (
        <ThemeProvider theme={theme}>
            <LocalizationProvider dateAdapter={AdapterDateFns}>
                <DatePicker
                    label={labelText}
                    value={value}
                    inputFormat={format}
                    disabled={disabled}
                    TransitionComponent={Zoom}
                    onChange={value => {
                        setFieldTouched(id, true)
                        onChange({ target: { name: id, id, value: value } })
                        if (dynamicForm)
                            handleFormChange(true, null)
                    }}
                    className={classNames(classes.root, {
                        [classes.labelError]: Boolean(error)
                    })}
                    InputProps={{
                        error: error,
                        disabled: disabled,
                        classes: {
                            root: classes.marginTop,
                            disabled: classes.disabled,
                            error: classes.error,
                            underline: classNames(classes.underline, {
                                [classes.underlineError]: Boolean(error)
                            })
                        }
                    }}
                    renderInput={props => (
                        <>
                            <TextField
                                name={id}
                                fullWidth={fullWidth}
                                variant={variant}
                                onBlur={onBlur}
                                {...props}
                            />
                            {helperText && (
                                <FormHelperText
                                    className={classNames({
                                        [commonClasses.themeColorError]: Boolean(error)
                                    })}
                                >
                                    {helperText}
                                </FormHelperText>
                            )}
                        </>
                    )}
                />
            </LocalizationProvider>
        </ThemeProvider>
    )
}




FormikDatePicker.defaultProps = {
    variant: "standard",
    format: "MM/dd/yyyy",
    dynamicForm: false
}

FormikDatePicker.propTypes = {
    id: PropTypes.string.isRequired,
    labelText: PropTypes.string.isRequired,
    value: PropTypes.string,
    variant: PropTypes.oneOf(["filled", "outlined", "standard"]),
    format: PropTypes.string,
    fullWidth: PropTypes.bool,
    disabled: PropTypes.bool,
    error: PropTypes.bool,
    dynamicForm: PropTypes.bool,
    helperText: PropTypes.string,
    onChange: PropTypes.func,
    onBlur: PropTypes.func,
    setFieldTouched: PropTypes.func,
    handleFormChange: PropTypes.func,
}

export default React.memo(FormikDatePicker)