const DataTableStyles = theme => ({
    topContainer: {
        paddingBottom: 10,
        alignItems: "center",
        overflow: "initial",
        // paddingBottom: 24,
    },
    resetBtnContainer: {
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        flexFlow: "column",
    },
    resetDTBtn: {
        transition: theme.transitions[0],
        width: 50,
        height: 50,
        color: `rgba(${theme.hexToRgb(theme.colors.black)},.3)`,
        boxShadow: "unset !important",
        // transform: "rotate(45deg)",
        "&:hover": {
            transition: theme.transitions[0],
            transform: "rotate(120deg)",
            color: theme.colors.primary[0],
            backgroundColor: `rgba(${theme.hexToRgb(theme.colors.primary[0])} , 0.3)`
        },
    },
    tableContainer: {
        // maxHeight: 500,
        height: 500,
        // scrollSnapType: "y mandatory",
        // "& *": {
        //     scrollSnapAlign: "center"
        // },
        "&::-webkit-scrollbar-track": {
            "webkitBoxShadow": "inset 0 0 6px rgba(0, 0, 0, 0.3)",
            "borderRadius": "60px",
            "backgroundColor": "#F5F5F5"
        },
        "&::-webkit-scrollbar": {
            "width": "6px",
            "maxHeight": "6px",
            "backgroundColor": "#F5F5F5"
        },
        "&::-webkit-scrollbar-thumb": {
            "borderRadius": "60px",
            "webkitBoxShadow": "inset 0 0 6px rgba(0, 0, 0, .1)",
            "backgroundColor": "rgba(0,0,0,.3)"
        }
    },
    headerTitleWrapper: {
        display: "flex",
        // justifyContent: "space-between",
        alignItems: "center",
        overflow: "hidden",
        fontSize: "1.063rem",
        fontWeight: 300,
        lineHeight: "2.5em!important",

        WebkitTouchCallout: "none",
        WebkitUserSelect: "none",
        KhtmlUserSelect: "none",
        MozUserSelect: "none",
        MsUserSelect: "none",
        userSelect: "none",
        color: "rgba(0, 0, 0, 0.6)",
        "& div": {
            whiteSpace: "nowrap",
            textOverflow: "ellipsis",
        },
        "& svg": {
            marginLeft: ".5em"
        }
    },
    footerDetails: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        padding: "8px 16px 8px 16px",
        color: "#151515de",
        marginTop: "25px",
        borderRadius: "0 0 15px 15px"
    },
    circularProgressHolder: {
        paddingTop: "2em",
        paddingBottom: "2em",
        textAlign: "center",
    },
    circularProgress: {
        transition: theme.transitions[0],
        color: theme.colors.primary[0]
    },
    rootNavigationButton: {
        "& , &:focus": {
            color: "rgba(0,0,0,.6)",
            backgroundColor: "rgba(0,0,0,.1)",
            boxShadow: "none",
            transition: "all .1s ease",
        },
        "&:hover": {
            color: "#fff",
            boxShadow: "none",
            transition: "all .1s ease",
            background: theme.colors.primary[0]
        },
        "&:focus": {
            boxShadow: "none",
        }
    },
    disabledRootNavigationButton: {
        "&:hover": {
            cursor: "not-allowed"
        }
    },
    noData: {
        paddingTop: "2em",
        textAlign: "center",
        "& svg": {
            fontSize: "7em"
        },
        "& h4": {
            fontSize: "1.5em",
            margin: 0,
            fontWeight: "300"
        }
    },
    emptyDataIcon: {
        color: theme.colors.primary[0]
    },
    emptyDataTypography: {
        color: theme.colors.primary[0]
    }
})

const TableCellStyles = theme => ({
    head: {
        backgroundColor: "#000",
        color: "#fff",
        position: "sticky",
        top: 0
    },
    body: {
        fontSize: 14,
        border: 'unset'
    },
})

const TableRowStyles = {
    root: {
        '&:nth-of-type(odd)': {
            backgroundColor: "rgba(0, 0, 0, .03)",
        }
    }
}

const SliderColumnFilterStyles = theme => ({
    '@keyframes spinAnimation': {
        from: { transform: "rotate(0deg)" },
        to: { transform: "rotate(-360deg)" },
    },
    root: {
        color: theme.colors.primary[0],
        marginRight: 10,
    },
    sliderContainer: {
        paddingTop: 10,
        marginTop: 16,
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center"
    },
    button: {
        backgroundColor: theme.colors.primary[0] + "!important",
        "&:hover": {
            animation: `$spinAnimation 2000ms linear infinite`,
        }
    }
})


const DataTableActionStyles = theme => ({
    actionButton: {
        padding: "3px 7px",
        backgroundColor: "transparent !important",
        transition: theme.transitions[0],
        "&:not(hover)": {
            transition: theme.transitions[0]
        }
    },
    hiddenFilter: {
        opacity: 0,
        zIndex: -10000,
        height: 48,        
        // paddingBottom: 70
    },
    editActionBtn: {
        color: theme.colors.warning[0],
    },
    infoActionBtn: {
        color: theme.colors.info[0],
    },
    viewActionBtn: {
        color: theme.colors.success[0],
    },
    deleteActionBtn: {
        color: theme.colors.danger[0],
    },
    actionButtonsContainer: {
        float: "right",
        display: "flex",
        flexWrap: "nowrap"
    }
})


export {
    DataTableStyles,
    TableCellStyles,
    TableRowStyles,
    SliderColumnFilterStyles,
    DataTableActionStyles
}