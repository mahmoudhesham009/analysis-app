
const LoadingProgressStyles = theme => ({
  // "@keyframes animateDots": {
  //   to: {
  //     clipPath: "inset(0 -1ch 0 0)"
  //   }
  // },
  loadingProgress: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "column",
    height: "calc(100vh - 64px)",
    "& .progress": {
      width: "220px!important",
      height: "220px!important",
      "& svg": {
        color: theme.colors.primary[0],
        fontSize: "50px"
      }
    },
    "& p": {

      fontSize: 20,
      // fontSize: 25,
      // fontFamily: "monospace",      
      display: "inline-block",
      fontWeight: "bold",
      marginTop: 50,
      // clipPath: "inset(0 3ch 0 0)",
      // "-webkit-animation": "$animateDots .9s steps(4) infinite",
      // animation: "$animateDots .9s steps(4) infinite",
    }
  }
})


export default LoadingProgressStyles