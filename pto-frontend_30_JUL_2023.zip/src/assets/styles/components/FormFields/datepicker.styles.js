
const MuiDatePickerStyles = theme => ({
    root: {
        "& label": {
            color: theme.colors.gray[3],
            fontFamily: "inherit",
            fontWeight: "400",
            fontSize: "14px",
            lineHeight: "1.42857",
            letterSpacing: "unset",
        }
    },
    labelError: {
        "& label": {
            color: theme.colors.danger[0] + "!important"
        }
    },
    underline: {
        "&:hover:not($disabled):before,&:before": {
            borderColor: theme.colors.gray[4],
            borderWidth: "1px !important"
        }
    },
    underlineError: {
        "&:hover:not($disabled):before,&:before": {
            borderColor: theme.colors.danger[0] + " !important",
        }
    },
    disabled: {
        "&:before": {
            backgroundColor: "transparent !important"
        }
    },
    error: {
        color: theme.colors.danger[0],
    },
    marginTop: {
        marginTop: "16px"
    }
})


const defaultMaterialThemeStyles = theme => ({
    palette: {
        primary: {
            main: theme.colors.primary[0]
        },
        secondary: {
            main: theme.colors.gray[3],
        },
        error: {
            main: theme.colors.danger[0]
        }
    },
    components: {
        MuiFormControl: {
            styleOverrides: {
                root: {
                    // backgroundColor: "#f0f!important",
                    // paddingBottom: "10px",
                }
            }
        },
        MuiPickersDay: {
            styleOverrides: {
                daySelected: {
                    color: theme.colors.white + "!important"
                }
            }
        },
    }
})


export {
    MuiDatePickerStyles,
    defaultMaterialThemeStyles
}