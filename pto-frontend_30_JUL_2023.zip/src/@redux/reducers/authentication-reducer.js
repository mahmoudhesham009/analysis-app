import { LOGIN, LOGOUT } from '@redux/types/authentication-types'

const initialState = {
    isLoggedIn: false    
}

const authenticationReducer = (state = initialState, action) => {
    switch (action.type) {
        case LOGIN:
            return { ...state, isLoggedIn: true }
        case LOGOUT:
            return { ...state, isLoggedIn: false }
        default: return state
    }
}

export default authenticationReducer