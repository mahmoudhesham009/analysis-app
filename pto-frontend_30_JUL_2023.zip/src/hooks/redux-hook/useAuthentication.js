import { useCallback } from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { Login, Logout } from '@redux/index'

function useAuthentication() {
    const authState = useSelector(state => state.authentication)
    const dispatch = useDispatch()


    const LoginToSystem = useCallback(() => {
        dispatch(Login())
    }, [])

    
    const LogoutFromSystem = useCallback(() => {
        dispatch(Logout())
    }, [])


    return {
        authState,
        LoginToSystem,
        LogoutFromSystem,
    }
}

export default useAuthentication