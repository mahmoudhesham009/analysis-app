package com.pto.cloneProcess.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.logging.FileHandler;
import java.util.logging.Level;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.XML;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.pto.cloneProcess.model.ActHiTaskinst;
import com.pto.cloneProcess.model.ActHiTaskinstRepository;

import antlr.StringUtils;

@Service
public class NewProcessImpl implements NewProcess {

	@Autowired
	private Environment env;

	@Autowired
	ActHiTaskinstRepository actHiTaskinst;

	private static final Logger log = LoggerFactory.getLogger(NewProcessImpl.class);
	public static java.util.logging.Logger logger;
	static FileHandler fh;
	static int secCount;

//	int taskCount;

	@Override
	public List<Map<String, Object>> copyProcess(Map<String, Object> reqBody) throws SecurityException, IOException {

		List<Map<String, Object>> finalResults = new ArrayList<Map<String, Object>>();

		List<String> resultListString = new ArrayList<String>();

		JSONObject bodyJO = new JSONObject(reqBody), tempJO, extraField;

		String originalProcessInstanceId = "", newProcessInstanceId = "";
		JSONObject originalProInfo, filnalResultJO = new JSONObject();
		secCount = 1;

		if (bodyJO.has("processInstanceId")) {
			originalProcessInstanceId = bodyJO.getString("processInstanceId");
			originalProInfo = getOldProcessInfo(originalProcessInstanceId, bodyJO);

			if (originalProInfo.has("ERROR")) {
				log.error("Error in get original process" + originalProcessInstanceId + " " + originalProInfo);
				filnalResultJO.put("result",
						"ERROR in get original process" + originalProcessInstanceId + " " + originalProInfo);
				finalResults.add(filnalResultJO.toMap());
				return finalResults;
			}
			newProcessInstanceId = createNewProess(originalProInfo, bodyJO);

		}

		if (newProcessInstanceId.startsWith("ERROR:") || newProcessInstanceId.isEmpty()) {

			filnalResultJO.put("ERROR in creating process", newProcessInstanceId);
			finalResults.add(filnalResultJO.toMap());
			return finalResults;
		}

//		if (bodyJO.has("restVariables")) {
//			addNewVariable(newProcessInstanceId, bodyJO);
//		}

		JSONArray originalProcessTasks = getAllTasksFromOriginalProcess(originalProcessInstanceId);

//		log.info("GlobaltaskCount: " + taskCount);
		log.info("Original process tasks list: " + originalProcessTasks);

		extraField = getDataFromXML();
		int countForTask = 0;
		int taskCount = 0;
		String activeTaskId = "";
		String activeTaskDef = "";
		String oldTaskId = "";
		String oldTaskIdTemp = "";
		String finalOldTaskId = "";
		String taskName = "";
		JSONObject taskVariables = new JSONObject();
		int statusCode;
		Map<String, JSONObject> newExtraVariables = new HashMap<String, JSONObject>();
		Map<String, String> activeTaskMap;
		Map<String, Integer> valCounter = new HashMap<String, Integer>();
		int exitCount=0;

		newExtraVariables = newGetExtraVariables(extraField, bodyJO.getString("processName"),
				bodyJO.getJSONArray("taskDefinitionKey"));

		log.info("Fields from XML: " + newExtraVariables);

		Map<String, Integer> defKeyCountMap = new HashMap<>();
		int skipCount;
		int count;
		boolean stopWhileLoop = false;
		while (!stopWhileLoop) {

			log.info("###############################################################");

			activeTaskMap = getProcessActiveTaskId(newProcessInstanceId);

			log.info("-------------------------------------------------------------");
			log.info(" activeTaskMap " + activeTaskMap);
			log.info("-------------------------------------------------------------");

//			if(activeTaskMap.get("name").equals(bodyJO.getString("taskName"))) {
//				//exitCount++;
//				break;
//			}
			
			 if (activeTaskMap.isEmpty())
				stopWhileLoop = true;
			else {
				activeTaskId = activeTaskMap.get("id");

				activeTaskDef = activeTaskMap.get("defKey");
				taskName = activeTaskMap.get("name");
				oldTaskId = "";

				log.info("Current task");
				log.info("Name:" + taskName);
				log.info("Id:" + activeTaskId);
				log.info("taskDefKey: " + activeTaskDef);

				if (defKeyCountMap.containsKey(activeTaskDef)) {
					count = defKeyCountMap.get(activeTaskDef);
					defKeyCountMap.put(activeTaskDef, ++count);
				} else {
					defKeyCountMap.put(activeTaskDef, 1);
				}
				skipCount = 1;

				// fields from old task
				countForTask = countForTask + 1;
				for (Object object : originalProcessTasks) { // 1 2 3 4
					tempJO = (JSONObject) object;

					if (activeTaskDef.equals(tempJO.getString("taskDefinitionKey"))) {

						if (defKeyCountMap.get(activeTaskDef) == skipCount) {
							oldTaskId = tempJO.getString("id");
							log.info("Old task Id:" + oldTaskId);
							taskVariables = getTaskFormVariables(oldTaskId);
							break;
						} else {
							skipCount++;
						}

					}
				}
				Optional<ActHiTaskinst> oldTaskInfo = actHiTaskinst.findById(oldTaskId);
				taskCount = bodyJO.getInt("taskCount");
				System.out.println("===========================================================");
				System.out.println("bodyJO.getInt(\"taskCount\")" + bodyJO.getInt("taskCount"));
				System.out.println("oldTaskInfo+++++++++++++++" + oldTaskInfo);
				System.out.println("LocalcountTask+++++++++++++++" + countForTask);
				System.out.println("GlobalTwotaskCount+++++++++++++++" + taskCount);
				System.out.println(taskCount == countForTask);
				System.out.println("oldTaskInfo.isPresent()+++++++++++++++" + oldTaskInfo.isPresent());
				System.out.println(taskName.equals(bodyJO.getString("taskName")));
				System.out.println("===========================================================");

				/****************
				 * 
				 * rest process
				 */
				if (bodyJO.getBoolean("restProcess")) {
					taskCount = 1;
				}
				if (taskName.equals(bodyJO.getString("taskName"))) {
					if (oldTaskInfo.isPresent()) {
						if (taskCount == countForTask) {
							System.out.print("true++++++++++++++++");
							createLogFile(bodyJO.getString("name"));
							log.info("Stop tasks loop");
							break;
						}
					} else if (taskCount == countForTask) {
						System.out.print("fasle++++++++++++++++");
						createLogFile(bodyJO.getString("name"));
						log.info("Stop tasks loop");
						break;
					}
				}

				// extra fields from XML

				if (newExtraVariables.containsKey(activeTaskDef)) {
					log.info("Inside xml variables");
					JSONObject entry = newExtraVariables.get(activeTaskDef); // 5

					for (String object : entry.keySet()) {
						String values = entry.get(object).toString();
						if (values.contains(",")) {
							if (valCounter.containsKey(object)) {
								valCounter.replace(object, valCounter.get(object) + 1);
							} else {
								valCounter.put(object, 0);
							}
							taskVariables.put(object, values.split(",")[valCounter.get(object)]);
						} else
							taskVariables.put(object, entry.get(object));
					}
				}

//				if (taskVariables.isEmpty()) {
//					log.info("No variables found for this task");
//					break;
//				}

				statusCode = claimTask(activeTaskId);

				if (statusCode == 200) {

					log.info("Variables: " + taskVariables);

					statusCode = completeTask(activeTaskId, taskVariables);

					if (statusCode != 200) {
						log.error("Error in complete task (" + activeTaskId + ")");
						resultListString.add(taskName + " ERROR in complete task (" + activeTaskId + ")");
						break;
					}
					log.info(taskName + " Completed");
					resultListString.add(taskName + " Completed");

					System.out.print("get from body task def"
							+ bodyJO.getJSONArray("taskDefinitionKey").toList().contains(activeTaskDef));

					if (!oldTaskId.isEmpty()
							|| (!bodyJO.getJSONArray("taskDefinitionKey").toList().contains(activeTaskDef))) {
						// new tasks
						changeCompletedTaskInfo(oldTaskId, activeTaskId, false);
						oldTaskIdTemp = oldTaskId;
					} else {
						log.info("add One Sec");
						changeCompletedTaskInfo(oldTaskIdTemp, activeTaskId, true);
						finalOldTaskId = oldTaskIdTemp;
						oldTaskIdTemp = activeTaskId;
					}

				} else {
					log.error("Error in claim task (" + activeTaskId + ")");
					resultListString.add(taskName + " >>> ERROR in claim task (" + activeTaskId + ")");
					break;
				}

			}
		} // end while
		if (resultListString.isEmpty()) {
			log.error("Error no tasks in the original process (" + originalProcessInstanceId + ")");
			resultListString.add("ERROR no tasks in the original process (" + originalProcessInstanceId + ")");
		}

		filnalResultJO.put("result", resultListString);
		filnalResultJO.put("New ProcessInstanceId", newProcessInstanceId);
		finalResults.add(filnalResultJO.toMap());

		return finalResults;
	}

	private void createLogFile(String bussnisKey) throws SecurityException, IOException {
		log.info("bussnisKey" + bussnisKey);

		File file = new File("default" + ".log");
		if (!file.exists()) {
			fh = new FileHandler("default" + ".log");
//			logger = java.util.logging.Logger.getLogger("Log");
//			logger.addHandler(fh);
		}
		logger = java.util.logging.Logger.getLogger("Log");
		logger.addHandler(fh);

		logger.log(Level.INFO, bussnisKey);

	}

	void changeCompletedTaskInfo(String oldTaskId, String newTaskId, boolean addOneSec) {

		log.info("Inside changeCompletedTaskEndDate");
		log.info("Old taskId: " + oldTaskId);
		log.info("New taskId: " + newTaskId);
		log.info("Increase time: " + addOneSec);
		log.info("time: " + secCount);
		

		Optional<ActHiTaskinst> oldTaskInfo = actHiTaskinst.findById(oldTaskId);
		Optional<ActHiTaskinst> newTaskInfo = actHiTaskinst.findById(newTaskId);

		if (oldTaskInfo.isPresent() && newTaskInfo.isPresent()) {
			if (addOneSec) {
				newTaskInfo.get().setStartTime(oldTaskInfo.get().getStartTime().plusNanos(secCount*1000000000));
				newTaskInfo.get().setClaimTime(oldTaskInfo.get().getClaimTime().plusNanos(secCount*1000000000));
				newTaskInfo.get().setEndTime(oldTaskInfo.get().getEndTime().plusNanos(secCount*1000000000));
				secCount++;

			} else {
				newTaskInfo.get().setStartTime(oldTaskInfo.get().getStartTime());
				newTaskInfo.get().setClaimTime(oldTaskInfo.get().getClaimTime());
				newTaskInfo.get().setEndTime(oldTaskInfo.get().getEndTime());
				secCount = 1;
			}
			newTaskInfo.get().setDueDate(oldTaskInfo.get().getDueDate());
			newTaskInfo.get().setDuration(oldTaskInfo.get().getDuration());
			newTaskInfo.get().setAssignee(oldTaskInfo.get().getAssignee());

			actHiTaskinst.saveAndFlush(newTaskInfo.get());
			log.info("Changed successfully");

		} else {
			log.error("Error in changing Completed Task Info");
			log.error("Old Task Info: " + oldTaskInfo.toString());
			log.error("New Task Info: " + newTaskInfo.toString());

		}

	}

	private Map<String, JSONObject> newGetExtraVariables(JSONObject extraField, String processName,
			JSONArray taskDefIdFromeBody) {

		Map<String, JSONObject> result = new HashMap<String, JSONObject>();
		JSONObject tempProcess = new JSONObject();

		if (!extraField.isEmpty() && extraField.has("tasks")) {
			if (extraField.getJSONObject("tasks").has("process")) {
				if (extraField.getJSONObject("tasks").get("process") instanceof JSONObject) {
					tempProcess = extraField.getJSONObject("tasks").getJSONObject("process");
					if (!tempProcess.isEmpty()) {
						if (tempProcess.getString("name").equals(processName)) {
							for (int i = 0; i < taskDefIdFromeBody.length(); i++) {
								if (tempProcess.has(taskDefIdFromeBody.getString(i))) {
									result.put(taskDefIdFromeBody.getString(i), getVariablesFromXMLJSONOject(
											tempProcess.getJSONObject(taskDefIdFromeBody.getString(i))));
								}
							}
						}
					}

				}
			}

		}
		return result;
	}

	private JSONObject getVariablesFromXMLJSONOject(JSONObject extraField) {
		JSONObject result = new JSONObject(), tempField;
		JSONArray tempFieldArr = new JSONArray();
		if (!extraField.isEmpty() && extraField.has("field")) {
			if (extraField.get("field") instanceof JSONArray) {
				tempFieldArr = extraField.getJSONArray("field");
				for (int i = 0; i < tempFieldArr.length(); i++) {
					tempField = tempFieldArr.getJSONObject(i);
					result.put(tempField.getString("field-id"), tempField.get("field-value"));

				}
			} else {
				result.put(extraField.getJSONObject("field").get("field-id").toString(),
						extraField.getJSONObject("field").get("field-value").toString());
			}
		}
		return result;
	}

	JSONObject getTaskFormVariables(String taskId) {
		JSONObject responseJO, resultJO = new JSONObject(), temp, temp2, temp3;
		JSONArray fieldsJA = new JSONArray(), tempJA;
		CloseableHttpClient client = HttpClients.createDefault();
		try {

			HttpGet httpGet = new HttpGet(env.getProperty("alfresco.rootURI") + env.getProperty("alfresco.apsURL")
					+ "enterprise/task-forms/" + taskId);

			httpGet.addHeader("Authorization", "Basic " + getEncryptedBasicAuthorizationCreds());

			httpGet.setHeader("Accept", "application/json");
			CloseableHttpResponse response = client.execute(httpGet);

			String result = EntityUtils.toString(response.getEntity(), "UTF-8");
			int statusCode = response.getStatusLine().getStatusCode(), x;

			if (statusCode == 200) {

				responseJO = new JSONObject(result);

				if (responseJO.has("fields")) {

					fieldsJA = responseJO.getJSONArray("fields");
					for (int i = 0; i < fieldsJA.length(); i++) {
						temp = fieldsJA.getJSONObject(i);
						if (temp.has("fields")) {
							temp2 = temp.getJSONObject("fields");
							x = 1;
							while (true) {
								if (temp2.has(String.valueOf(x))) {
									tempJA = temp2.getJSONArray(String.valueOf(x));
									for (int j = 0; j < tempJA.length(); j++) {
										temp3 = tempJA.getJSONObject(j);
										resultJO.put(temp3.getString("id"), temp3.get("value"));
									}
								} else {
									break;
								}
								x++;
							}

						}

					}

				}

			}

		} catch (IOException ex) {
			log.error("ERROR in getTaskFormVariables: " + ex.getMessage());
		} finally {
			try {
				client.close();
			} catch (IOException ex) {
				log.error("ERROR in getTaskFormVariables: " + ex.getMessage());
			}
		}

		return resultJO;

	}

	public int completeTask(String taskId, JSONObject taskVariables) {

		int statusCode = 0;

		CloseableHttpClient client = HttpClients.createDefault();
		HttpPost httpPost = new HttpPost(env.getProperty("alfresco.rootURI") + env.getProperty("alfresco.apsURL")
				+ "enterprise/task-forms/" + taskId);
		httpPost.addHeader("Authorization", "Basic " + getEncryptedBasicAuthorizationCreds());
		JSONObject json = new JSONObject();

		json.put("outcome", " ");
		json.put("values", taskVariables);

		StringEntity entity;
		try {
			entity = new StringEntity(json.toString(), "UTF-8");

			httpPost.setEntity(entity);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");
			CloseableHttpResponse response = client.execute(httpPost);

			String result = EntityUtils.toString(response.getEntity(), "UTF-8");

			statusCode = response.getStatusLine().getStatusCode();

			if (statusCode != 200) {

				log.info("Error in completeTask (" + taskId + ") " + result);
			}

		} catch (UnsupportedEncodingException ex) {
			log.error("Error in completeTask (" + taskId + ") " + ex.getMessage());
		} catch (IOException ex) {
			log.error("Error in completeTask (" + taskId + ") " + ex.getMessage());
		}
		return statusCode;
	}

	int claimTask(String taskId) {

		CloseableHttpClient client = HttpClients.createDefault();
		try {
			HttpPut httpPut = new HttpPut(env.getProperty("alfresco.rootURI") + env.getProperty("alfresco.apsURL")
					+ "enterprise/tasks/" + taskId + "/action/claim");
			httpPut.addHeader("Authorization", "Basic " + getEncryptedBasicAuthorizationCreds());

			httpPut.setHeader("Accept", "application/json");
			httpPut.setHeader("Content-type", "application/json");
			CloseableHttpResponse response = client.execute(httpPut);
			int statusCode = response.getStatusLine().getStatusCode();
			return statusCode;
		} catch (IOException ex) {
			log.error("Error in claimTask (" + taskId + ") " + ex.getMessage());
		} finally {
			try {
				client.close();
			} catch (IOException ex) {
				log.error("Error in claimTask (" + taskId + ") " + ex.getMessage());
			}
		}

		return 0;

	}

	JSONArray getTaskVariables(String taskId) {
		JSONArray responseJO = new JSONArray();
		CloseableHttpClient client = HttpClients.createDefault();
		try {

			HttpGet httpGet = new HttpGet(env.getProperty("alfresco.rootURI") + env.getProperty("alfresco.apsURL")
					+ "enterprise/task-forms/" + taskId + "/variables");

			httpGet.addHeader("Authorization", "Basic " + getEncryptedBasicAuthorizationCreds());

			httpGet.setHeader("Accept", "application/json");
			CloseableHttpResponse response = client.execute(httpGet);

			String result = EntityUtils.toString(response.getEntity(), "UTF-8");
			int statusCode = response.getStatusLine().getStatusCode();

			if (statusCode == 200) {

				responseJO = new JSONArray(result);

			}

		} catch (IOException ex) {
			log.error("Error in getTaskVariables (" + taskId + ") " + ex.getMessage());
		} finally {
			try {
				client.close();
			} catch (IOException ex) {
				log.error("Error in getTaskVariables (" + taskId + ") " + ex.getMessage());
			}
		}

		return responseJO;

	}

	JSONObject getOldProcessInfo(String proInstId, JSONObject bodyJO) {

		JSONObject resultJO = new JSONObject(), responseJO;
		JSONObject variables = new JSONObject();

		CloseableHttpClient client = HttpClients.createDefault();
		try {

			HttpGet httpGet = new HttpGet(env.getProperty("alfresco.rootURI") + env.getProperty("alfresco.apsURL")
					+ "enterprise/process-instances/" + proInstId);

			httpGet.addHeader("Authorization", "Basic " + getEncryptedBasicAuthorizationCreds());

			httpGet.setHeader("Accept", "application/json");
			CloseableHttpResponse response = client.execute(httpGet);

			String result = EntityUtils.toString(response.getEntity(), "UTF-8");
			int statusCode = response.getStatusLine().getStatusCode();

			if (bodyJO.has("restVariables")) {
				System.out.println("bodyJO.getJSONArray(\"restVariables\")" + bodyJO.getJSONArray("restVariables"));
				for (int i = 0; i < bodyJO.getJSONArray("restVariables").length(); i++) {
					JSONObject o = bodyJO.getJSONArray("restVariables").getJSONObject(i);
					System.out.println("o" + o);
					System.out.println("name" + o.get("name"));
					System.out.println("type" + o.get("type"));
					System.out.println("value" + o.get("value"));
					variables.put("name", o.get("name"));
					variables.put("type", o.get("type"));
					variables.put("value", o.get("value"));
				}
			}

			if (statusCode == 200) {

				responseJO = new JSONObject(result);

				if (!responseJO.isEmpty()) {
					resultJO.put("name", responseJO.get("name"));
					resultJO.put("businessKey", responseJO.getString("businessKey"));
					resultJO.put("processDefinitionKey", responseJO.getString("processDefinitionKey"));
//					responseJO.getJSONArray("variables").put(variables);
					for (int i = 0; i < responseJO.getJSONArray("variables").length(); i++) {
						if (responseJO.getJSONArray("variables").getJSONObject(i).getString("name")
								.equals("RAPPORTEUR_OFFICE")) {
							responseJO.getJSONArray("variables").getJSONObject(i).remove("value");
							responseJO.getJSONArray("variables").getJSONObject(i).put("value", "EP");
						}
					}

//					JSONObject temp = new JSONObject();
//					temp.put("name", "projectType");
//					temp.put("type", "string");
//					temp.put("value", "DP");
//					responseJO.getJSONArray("variables").put(temp);

					resultJO.put("variables", responseJO.getJSONArray("variables"));
				} else {
					resultJO.put("ERROR", "Process Intance Id (" + proInstId + ") does not exist");
				}

			} else {
				resultJO.put("ERROR", result);
			}
		} catch (IOException ex) {
			resultJO.put("ERROR", ex.getMessage());
			log.error("Error in getOldProcessInfo (" + proInstId + ") " + ex.getMessage());

		} finally {
			try {
				client.close();
			} catch (IOException ex) {
				resultJO.put("ERROR", ex.getMessage());
				log.error("Error in getOldProcessInfo (" + proInstId + ") " + ex.getMessage());
			}
		}

		return resultJO;
	}

	private void addNewVariable(String newProcessInstanceId, JSONObject bodyJO) {
		CloseableHttpClient client = HttpClients.createDefault();
		try {
			HttpPost httpPost = new HttpPost(env.getProperty("alfresco.rootURI") + env.getProperty("alfresco.apsURL")
					+ "enterprise/process-instances/" + newProcessInstanceId + "/variables");
			httpPost.addHeader("Authorization", "Basic " + getEncryptedBasicAuthorizationCreds());

			JSONObject json = new JSONObject();
			JSONArray array = new JSONArray();

			if (bodyJO.has("restVariables")) {

				for (int i = 0; i < bodyJO.getJSONArray("restVariables").length(); i++) {
					JSONObject o = bodyJO.getJSONArray("restVariables").getJSONObject(i);

					json.put("name", o.get("name"));
					json.put("scope", o.get("scope"));
					json.put("type", o.get("type"));
					json.put("value", o.get("value"));
					array.put(json);
				}
			}

			StringEntity entity = new StringEntity(array.toString(), "UTF-8");
			httpPost.setEntity(entity);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");
			CloseableHttpResponse response = client.execute(httpPost);

			String result = EntityUtils.toString(response.getEntity(), "UTF-8");

			log.info("Response: " + result);

			int statusCode = response.getStatusLine().getStatusCode();

			if (statusCode == 200) {

			}
		} catch (IOException ex) {

		} finally {
			try {
				client.close();
			} catch (IOException ex) {

			}
		}

	}

	String createNewProess(JSONObject pInfo, JSONObject reqBody) {
		String proInstId = "";
		JSONObject resultJO;

		log.info("Process info before body: " + pInfo);

		CloseableHttpClient client = HttpClients.createDefault();
		try {

			HttpPost httpPost = new HttpPost(env.getProperty("alfresco.rootURI") + env.getProperty("alfresco.apsURL")
					+ "enterprise/process-instances");

			httpPost.addHeader("Authorization", "Basic " + getEncryptedBasicAuthorizationCreds());

			if (reqBody.has("businessKey")) {
				if (!reqBody.getString("businessKey").isEmpty())
					pInfo.put("businessKey", reqBody.getString("businessKey"));
			}
			if (reqBody.has("name")) {
				if (!reqBody.getString("name").isEmpty())
					pInfo.put("name", reqBody.getString("name"));
				else if (pInfo.get("name") == null) {
					pInfo.put("name", pInfo.getString("businessKey"));
				}

			}
			log.info("name " + reqBody.getString("name"));
			log.info("businessKey " + reqBody.getString("businessKey"));
			log.info("Process info after body: " + pInfo);

			StringEntity entity = new StringEntity(pInfo.toString(), "UTF-8");
			httpPost.setEntity(entity);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");
			CloseableHttpResponse response = client.execute(httpPost);

			String result = EntityUtils.toString(response.getEntity(), "UTF-8");

			log.info("Response: " + result);

			int statusCode = response.getStatusLine().getStatusCode();

			if (statusCode == 200) {

				resultJO = new JSONObject(result);

				if (resultJO.has("id")) {
					proInstId = resultJO.getString("id");
				} else {
					proInstId = "ERROR: No Process Instance Id";
					log.error("Error in createNewProess no Process Instance Id");
				}

			} else {
				proInstId = "ERROR: status code: " + statusCode + " " + result;
				log.error("Error in createNewProess with status code: " + statusCode + " " + result);
			}

		} catch (IOException ex) {
			proInstId = "ERROR: " + ex.getMessage();
			log.error("Error in createNewProess: " + ex.getMessage());

		} finally {
			try {
				client.close();
			} catch (IOException ex) {
				proInstId = "ERROR: " + ex.getMessage();
				log.error("Error in createNewProess: " + ex.getMessage());
			}
		}

		return proInstId;
	}

	JSONArray getAllTasksFromOriginalProcess(String originalProcessInstanceId) {

		JSONArray array = new JSONArray();
		CloseableHttpClient client = HttpClients.createDefault();
		try {
			HttpPost httpPost = new HttpPost(env.getProperty("alfresco.rootURI") + env.getProperty("alfresco.apsURL")
					+ "enterprise/tasks/query");
			httpPost.addHeader("Authorization", "Basic " + getEncryptedBasicAuthorizationCreds());

			JSONObject json = new JSONObject(), obj;

			json.put("processInstanceId", originalProcessInstanceId);
			json.put("state", "completed");
			json.put("sort", "created-asc");
			json.put("size", 250);

			StringEntity entity = new StringEntity(json.toString());
			httpPost.setEntity(entity);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");
			CloseableHttpResponse response = client.execute(httpPost);
			String result = EntityUtils.toString(response.getEntity(), "UTF-8");
			int statusCode = response.getStatusLine().getStatusCode();

			if (statusCode == 200) {
				obj = new JSONObject(result);
//				if (obj.has("total")) {
//					taskCount = obj.getInt("total");
//				}
				if (obj.has("data"))
					array = obj.getJSONArray("data");
			} else {
				log.error("Error in getAllTasksFromOriginalProcess with status code: " + statusCode + " " + result);
			}
		} catch (IOException ex) {
			log.error(ex.getMessage());
			log.error("Error in getAllTasksFromOriginalProcess: " + ex.getMessage());
		} finally {
			try {
				client.close();
			} catch (IOException ex) {
				log.error(ex.getMessage());
				log.error("Error in getAllTasksFromOriginalProcess: " + ex.getMessage());
			}
		}

		return array;

	}

	Map<String, String> getProcessActiveTaskId(String processInstanceId) {
		Map<String, String> taskInfo = new HashMap<String, String>();

		CloseableHttpClient client = HttpClients.createDefault();
		String result;
		HttpPost httpPost = new HttpPost(env.getProperty("alfresco.rootURI") + env.getProperty("alfresco.apsURL")
				+ "enterprise/historic-tasks/query");
		httpPost.addHeader("Authorization", "Basic " + getEncryptedBasicAuthorizationCreds());
		JSONObject json = new JSONObject(), resultJO = new JSONObject();
		JSONArray array = new JSONArray();

		json.put("processInstanceId", processInstanceId);
		json.put("finished", false);

		StringEntity entity;
		try {
			entity = new StringEntity(json.toString());

			httpPost.setEntity(entity);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");
			CloseableHttpResponse response = client.execute(httpPost);

			result = EntityUtils.toString(response.getEntity(), "UTF-8");
			int statusCode = response.getStatusLine().getStatusCode();

			if (statusCode == 200) {
				resultJO = new JSONObject(result);
				if (resultJO.has("data")) {
					array = resultJO.getJSONArray("data");
					if (array.length() > 1) {
						log.warn("Warning, they have Multiple active tasks !!!!");
					}
					for (int i = 0; i < array.length(); i++) {
						taskInfo.put("id", array.getJSONObject(i).getString("id"));
						taskInfo.put("defKey", array.getJSONObject(i).getString("taskDefinitionKey"));// pbt01
						taskInfo.put("name", array.getJSONObject(i).getString("name"));

					}
					log.info("Active Task Info Data : " + taskInfo);

				}
			}

		} catch (UnsupportedEncodingException ex) {
			log.error("ERROR in get active task for processIstanceId(" + processInstanceId + ") " + ex.getMessage());
		} catch (IOException ex) {
			log.error("ERROR in get active task for processIstanceId(" + processInstanceId + ") " + ex.getMessage());
		}
		if (taskInfo.isEmpty()) {
			log.error("ERROR, No active task for this process: " + processInstanceId);
		}

		return taskInfo;

	}

	private String getEncryptedBasicAuthorizationCreds() {
		String creds = "";
		creds = env.getProperty("alfresco.userName") + ":" + env.getProperty("alfresco.password");
		Base64 base64 = new Base64();
		creds = new String(base64.encode(creds.getBytes()));
		return creds;
	}

	private JSONObject getDataFromXML() {
		String path = env.getProperty("XML.path");
		String line = "", str = "";
		try (BufferedReader br = new BufferedReader(new FileReader(path))) {
			while ((line = br.readLine()) != null) {
				str += line;
			}
		} catch (FileNotFoundException e) {
			log.error("Error in getDataFromXML: " + e.getMessage());

		} catch (IOException e) {
			log.error("Error in getDataFromXML: " + e.getMessage());
		}
		log.info("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		log.info(str);
		log.info("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
		JSONObject jsondata = XML.toJSONObject(str);
		return jsondata;
	}
}
