package com.pto.updateTaskHis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UpdateTaskHisApplication {

    public static void main(String[] args) {
        SpringApplication.run(UpdateTaskHisApplication.class, args);
    }

}
