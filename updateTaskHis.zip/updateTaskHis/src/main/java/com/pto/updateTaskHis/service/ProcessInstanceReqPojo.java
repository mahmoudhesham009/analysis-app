package com.pto.updateTaskHis.service;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class ProcessInstanceReqPojo {
    private Integer size;
    private Integer total;
    private Integer start;
    private List<ProcessInstanceData> data;

    public ProcessInstanceReqPojo(List<ProcessInstanceData> data) {
        this.data = data;
    }
}
