package com.pto.updateTaskHis.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Base64;

import static java.nio.charset.StandardCharsets.UTF_8;

@Service
public class HttpServiceImpl implements HttpService {

    private final Logger log = LoggerFactory.getLogger(this.getClass());
    @Value("#{'${assertiv.aps.url}'}")
    String BASE_URL;

    @Value("#{'${assertiv.aps.userName}'}")
    String USER;

    @Value("#{'${assertiv.aps.password}'}")
    String PASSWORD;

    @Override
    public <T> T getReq(String path, Class<T> c) throws URISyntaxException {
        WebClient client = WebClient.create();

        return client.get()
                .uri(new URI(BASE_URL + path))
                .accept(MediaType.ALL)
                .header(HttpHeaders.AUTHORIZATION, getCredentials())
                .retrieve()
                .onStatus(s -> !s.equals(HttpStatus.OK),
                        response -> {
                            response.bodyToMono(String.class).subscribe(body -> {
                                log.error("Error: {}", body);
                            });
                            throw new RuntimeException(response.toString());
                        })
                .bodyToMono(c)
                .block();
    }

    @Override
    public <T> T putReq(String path, Class<T> c) throws URISyntaxException {
        WebClient client = WebClient.create();

        return client.put()
                .uri(new URI(BASE_URL + path))
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.AUTHORIZATION, getCredentials())
                .retrieve()
                .onStatus(s -> !s.equals(HttpStatus.OK),
                        response -> {
                            response.bodyToMono(String.class).subscribe(body -> {
                                log.error("Error: {}", body);
                            });
                            throw new RuntimeException(response.toString());
                        })
                .bodyToMono(c)
                .block();
    }

    @Override
    public <T> T putReq(String path, Object body, Class<T> c) throws URISyntaxException {
        WebClient client = WebClient.create();

        return client.put()
                .uri(new URI(BASE_URL + path))
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.AUTHORIZATION, getCredentials())
                .bodyValue(body)
                .retrieve()
                .onStatus(s -> !s.equals(HttpStatus.OK),
                        response -> {
                            response.bodyToMono(String.class).subscribe(b -> {
                                log.error("Error: {}", b);
                            });
                            throw new RuntimeException(response.toString());
                        })
                .bodyToMono(c)
                .block();
    }

    @Override
    public <T> T postReq(String path, Object body, Class<T> c) throws URISyntaxException {
        WebClient client = WebClient.create();

        return client.post()
                .uri(new URI(BASE_URL + path))
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.AUTHORIZATION, getCredentials())
                .bodyValue(body)
                .retrieve()
                .onStatus(
                        s -> !s.equals(HttpStatus.OK),
                        response -> {
                            response.bodyToMono(String.class).subscribe(b -> {
                                log.error("Error: {}", b);
                            });
                            throw new RuntimeException(response.toString());
                        })
                .bodyToMono(c)
                .block();
    }


    @Override
    public <T> T postReqStringBody(String path, String body, Class<T> c) throws URISyntaxException {
        WebClient client = WebClient.create();

        return client.post()
                .uri(new URI(BASE_URL + path))
                .accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.AUTHORIZATION, getCredentials())
                .bodyValue(body)
                .retrieve()
                .onStatus(
                        s -> !s.equals(HttpStatus.OK),
                        response -> {
                            response.bodyToMono(String.class).subscribe(b -> {
                                log.error("Error: {}", b);
                            });
                            throw new RuntimeException(response.toString());
                        })
                .bodyToMono(c)
                .block();
    }

    @Override
    public <T> T deleteReq(String path, Class<T> c) throws URISyntaxException {
        WebClient client = WebClient.create();
        return client.delete()
                .uri(new URI(BASE_URL + path))
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.AUTHORIZATION, getCredentials())
                .retrieve()
                .onStatus(
                        s -> !s.equals(HttpStatus.OK),
                        response -> {
                            response.bodyToMono(String.class).subscribe(b -> {
                                log.error("Error: {}", b);
                            });
                            throw new RuntimeException(response.toString());
                        })
                .bodyToMono(c)
                .block();

    }

    private String getCredentials() {

        String creds = USER + ":" + PASSWORD;
        creds = new String("Basic " + Base64.getEncoder()
                .encodeToString((creds).getBytes(UTF_8)));
        return creds;

        //String creds = (String) SecurityContextHolder.getContext().getAuthentication().getCredentials();
        //return creds;
    }

    public <T> T authenticate(String path, Class<T> c, String credentials) throws URISyntaxException
    {
        WebClient client = WebClient.create();

        return client.get()
                .uri(new URI(BASE_URL + path))
                .accept(MediaType.ALL)
                .header(HttpHeaders.AUTHORIZATION,credentials)
                .retrieve()
                .onStatus(s -> !s.equals(HttpStatus.OK),
                        response -> {
                            response.bodyToMono(String.class).subscribe(body -> {
                                log.error("Error: {}", body);
                            });
                            throw new RuntimeException(response.toString());
                        })
                .bodyToMono(c)
                .block();
    }


    public <T> T getReq_test(String path, Class<T> c,String credentials) throws URISyntaxException
    {
        WebClient client = WebClient.create();

        return client.get()
                .uri(new URI(BASE_URL + path))
                .accept(MediaType.ALL)
                .header(HttpHeaders.AUTHORIZATION, credentials)
                .retrieve()
                .onStatus(s -> !s.equals(HttpStatus.OK),
                        response -> {
                            response.bodyToMono(String.class).subscribe(body -> {
                                log.error("Error: {}", body);
                            });
                            throw new RuntimeException(response.toString());
                        })
                .bodyToMono(c)
                .block();

    }

}
