package com.pto.updateTaskHis.repository.cpc;

import com.pto.updateTaskHis.entity.cpc.ChangeProposalStateTask;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

public interface ChangeProposalStateTaskRepository extends JpaRepository<ChangeProposalStateTask,Long> {

    @Transactional
    @Modifying
    @Query(value = "update CHANGE_PROPOSAL_STATE_TASK set TASK_START_TS = :startDate, TASK_DUE_TS=:dueDate " +
            " where FK_CHANGE_PROPOSAL_ID = " +
            "( select CHANGE_PROPOSAL_ID from CHANGE_PROPOSAL where GUID_ID=:guid )",nativeQuery = true)
    void updateStateTask(Date startDate, Date dueDate, String guid);
}
