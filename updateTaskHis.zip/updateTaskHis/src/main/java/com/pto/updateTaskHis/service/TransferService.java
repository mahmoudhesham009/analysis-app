package com.pto.updateTaskHis.service;

import com.pto.updateTaskHis.repository.cpc.ChangeProposalStateTaskRepository;
import com.pto.updateTaskHis.repository.originalProd.ActHiTaskInstanceOriginalRepository;
import com.pto.updateTaskHis.repository.prod.ActHiTaskInstanceRepository;
import jakarta.persistence.Tuple;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.net.URISyntaxException;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class TransferService {

    @Autowired
    ActHiTaskInstanceOriginalRepository originalRep;

    @Autowired
    ActHiTaskInstanceRepository prodRepo;

    @Autowired
    ChangeProposalStateTaskRepository cpcRepo;

    @Autowired
    HttpService httpService;

    private static Logger log = LoggerFactory.getLogger(TransferService.class);
    boolean transfer(){

        List<String>uuids=getAlluuids();
        
        log.info("number of process: ", uuids.size());
        log.info("===================================================");
        Date processStartDate,startDate,dueDate;
        String guid;
        for(String uuId:uuids){
            processStartDate=originalRep.getProcessIdAndStartDate(uuId);
            Tuple dates= originalRep.getActiveTaskStartAndDueDate(uuId);
            startDate= (Date) dates.get(0);
            dueDate= (Date) dates.get(1);
            guid=toDatabaseFormat(uuId);
            log.info("uuid: ", uuId);
            log.info("guid: ", guid);
            log.info("Process StartDate: ", processStartDate);
            log.info("StartDate: ", startDate);
            log.info("DueDate: ", dates);

            prodRepo.updateProcess(processStartDate,uuId);
            log.info("process Updated");
            prodRepo.updateHisTask(startDate,dueDate,uuId);
            log.info("his task Updated");
            prodRepo.updateRuTask(startDate,dueDate,uuId);
            log.info("ru task Updated");

            cpcRepo.updateStateTask(startDate,dueDate,guid);
            log.info("state task Updated");
            log.info("-----------------------------------------------");
        }

        return true;
    }

    private List<String> getAlluuids() {
        try {
            ProcessInstanceReqPojo resResult = httpService.postReq("/enterprise/historic-process-instances/query",
                    new InstanceWithVars(false),
                    ProcessInstanceReqPojo.class);
            List<ProcessInstanceData> res = resResult.getData();

            return res.stream().map(i->i.getName()).collect(Collectors.toList());
        } catch (URISyntaxException e) {
            e.printStackTrace();
            return null;
        }
    }

    public String toDatabaseFormat(String guid) {
        String ret = null;
        if (guid != null) {
            ret = guid.toLowerCase().replaceAll("(\\{)|(\\})|(-)", "");
        }
        return ret;
    }
}
