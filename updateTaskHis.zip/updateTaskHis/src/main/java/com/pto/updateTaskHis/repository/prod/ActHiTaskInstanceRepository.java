package com.pto.updateTaskHis.repository.prod;

import com.pto.updateTaskHis.entity.prod.ActHiTaskinst;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

public interface ActHiTaskInstanceRepository extends JpaRepository<ActHiTaskinst,String> {


    @Transactional
    @Modifying
    @Query(value = "update ACT_HI_PROCINST set START_time_ = :startDate where NAME_ = :uuid",nativeQuery = true)
    void updateProcess(Date startDate, String uuid);
    @Transactional
    @Modifying
    @Query(value = "update ACT_HI_TASKINST set START_time_ = :startDate ,DUE_DATE_ = :dueDate " +
            "where PROC_INST_ID_ = (select proc_inst_id_ from ACT_HI_PROCINST where NAME_ = :uuid) and END_TIME_ is null",nativeQuery = true)
    void updateHisTask(Date startDate,Date dueDate,String uuid);
    @Transactional
    @Modifying
    @Query(value = "update ACT_RU_TASK set CREATE_TIME_ = :startDate ,DUE_DATE_ = :dueDate " +
            "where PROC_INST_ID_ = (select proc_inst_id_ from ACT_HI_PROCINST where NAME_ = :uuid)",nativeQuery = true)
    void updateRuTask(Date startDate,Date dueDate,String uuid);
}
