package com.pto.updateTaskHis.repository.originalProd;

import com.pto.updateTaskHis.entity.originalProd.ActHiTaskinstOriginal;
import jakarta.persistence.Tuple;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Date;

public interface ActHiTaskInstanceOriginalRepository extends JpaRepository<ActHiTaskinstOriginal,String> {

    @Query(value = "select START_time_ from ACT_HI_PROCINST where  NAME_ = :uuid",nativeQuery = true)
    Date getProcessIdAndStartDate(String uuid);

    @Query(value = "select CREATE_TIME_,DUE_DATE_ from ACT_RU_TASK where PROC_INST_ID_ = (select proc_inst_id_ from ACT_HI_PROCINST where NAME_ = :uuid)",nativeQuery = true)
    Tuple getActiveTaskStartAndDueDate(String uuid);


}
