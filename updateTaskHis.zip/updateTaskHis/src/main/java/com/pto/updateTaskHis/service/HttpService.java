package com.pto.updateTaskHis.service;

import java.net.URISyntaxException;

public interface HttpService {

    <T> T getReq(String path, Class<T> c) throws URISyntaxException;

    <T> T putReq(String path, Class<T> c) throws URISyntaxException;

    <T> T putReq(String path, Object body, Class<T> c) throws URISyntaxException;

    <T> T postReq(String path, Object body, Class<T> c) throws URISyntaxException;


    <T> T postReqStringBody(String path, String body, Class<T> c) throws URISyntaxException;

    public <T> T deleteReq(String path, Class<T> c) throws URISyntaxException;

    public <T> T authenticate(String path, Class<T> c, String credentials) throws URISyntaxException;

    <T> T getReq_test(String path, Class<T> c,String credentials) throws URISyntaxException;

}
