package com.pto.updateTaskHis.entity.cpc;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;
import java.util.TreeSet;

import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedBy;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.Version;

/**
 * Entity Class for handling ORM Persistence for table
 * change_proposal_state_task primary key column is state_task_id
 * 
 * @author 2020
 * @version 1.14.0
 * @date: October 20, 2018
 *
 */
@Entity
@Table(name = "change_proposal_state_task")
public class ChangeProposalStateTask {

    /**
     * Allowing serialization of datamodel elements
     */
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "state_task_id_seq")
    @SequenceGenerator(name = "state_task_id_seq", sequenceName = "state_task_id_seq", initialValue = 1, allocationSize = 1)
    @Column(name = "state_task_id")
    private Long id;

    /** user with this associated settings */

    int fk_change_proposal_id;

    @Column(name = "task_id")
    private String taskId;

    @Column(name = "task_name_tx")
    private String taskName;

    @Column(name = "task_start_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date taskStartTs;

    @Column(name = "task_due_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date taskDueTs;
    
    @Column(name = "cfk_task_assignee_id")
    private String assignee; // VARCHAR2(320) - this is the first user field of
    
    @Column(name = "cfk_task_assignee_role_tx")
    private String taskedRole; // VARCHAR2(100) this is a comma separated list of roles associated with this task

    @Column(name = "cfk_task_assignee_office_cd")
    @Enumerated(EnumType.STRING)
    private String taskedOffice; // VARCHAR2(50)
    
    @Column(name = "task_definition_key_id")
    private String taskDefinitionKey; // VARCHAR2(10)

    @CreatedBy
    @Column(name = "create_user_id")
    private String createUserId; // VARCHAR2(100)

    @CreatedDate
    @Column(name = "create_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date createTs;

    @LastModifiedBy
    @Column(name = "last_mod_user_id")
    private String lastModifiedUserId; // VARCHAR2(100)

    @LastModifiedDate
    @Column(name = "last_mod_ts")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
    private Date lastModifiedTs;

    @SuppressWarnings("CPD-END")
    @Version
    @Column(name = "lock_control_no")
    private Integer lockControl;


    
    /**
     * @see Object#toString()
     */
    @Override
    public String toString() {
        return "ChangeProposalStateTask [id=" + id + ", taskId=" + taskId + ", taskName=" + taskName + ", taskStartTs="
                + taskStartTs + ", taskDueTs=" + taskDueTs + ", assignee=" + assignee + ", createUserId=" + createUserId
                + ", createTs=" + createTs + ", lastModifiedUserId=" + lastModifiedUserId + ", lastModifiedTs="
                + lastModifiedTs + ", lockControl=" + lockControl;
    }
}
