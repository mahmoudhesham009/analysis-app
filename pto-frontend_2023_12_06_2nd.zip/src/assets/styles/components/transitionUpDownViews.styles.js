
const TransitionUpDownViewsStyles = {
    transitionUpDownPage: {
        position: "relative",
        height: "calc(100vh - 64px)",        
        transition: "all 0.5s linear",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        overflow: "hidden",
        marginTop: 0,
        "& > *": {
            width: "100%",
            minHeight: "calc(100vh - 64px)",
        },
        "& > *:nth-child(2)": {
            marginTop: 64,
        },        
        "&.is-open": {
            overflow: "unset",
            marginTop: "-100vh"
        },
        "&.transition-in-progress": {
            overflow: "unset"
        }
    }
}


export default TransitionUpDownViewsStyles