import { transparentize } from 'polished';

const MainLayoutStyles = theme => ({
    root: {
        "& > main": {
            minHeight: "calc(100vh - 64px)",
        }
    }
})

const HeaderStyles = theme => ({
    appbar: {
        position: "relative",
        // zIndex: 1,
        // zIndex: 100000000000000000000,
        zIndex: 1200,
        background: theme.colors.primary[0],
        "& .uspto-logo-link": {
            display: "block",
            width: 100,
            "& svg": {
                fill: theme.colors.white
            }
        }
    }
})

const BreadcrumbStyles = theme => ({
    breadcrumbRoot: {
        backgroundColor: transparentize(0.8, theme.colors.white),
        borderRadius: 6,
        padding: "5px 15px",
        "& li": {
            transition: "all 0.5s linear"
        },
        "& span.breadcrumb-item-inner": {
            display: "inline-block",
            textDecoration: "unset",
            color: theme.colors.white,
            "& svg": {
                verticalAlign: "sub",
                marginRight: 3
            },
            "& span": {
                marginBottom: 3
            }
        }
    }
})

const MuiBreadcrumbTheme = {
    components: {
        MuiBreadcrumbs: {
            styleOverrides: {
                separator: {
                    color: "#fff",
                    fontSize: 20
                }
            }
        }
    }
}


const AccountWithBadgeStyles = ({ theme, isOnline }) => ({
    '& .MuiBadge-badge': {
        backgroundColor: isOnline ? '#44b700' : '#d32f2f',
        color: isOnline ? '#44b700' : '#d32f2f',
        boxShadow: `0 0 0 2px ${theme.palette.background.paper}`,
        '&::after': {
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
            borderRadius: '50%',
            animation: 'ripple 1.2s infinite ease-in-out',
            border: '1px solid currentColor',
            content: '""',
        },
    },
    '@keyframes ripple': {
        '0%': {
            transform: 'scale(.8)',
            opacity: 1,
        },
        '100%': {
            transform: 'scale(2.4)',
            opacity: 0,
        },
    },
})

const AccountMenuPaperStyles = {
    overflow: 'visible',
    filter: 'drop-shadow(0px 2px 8px rgba(0,0,0,0.32))',
    mt: 1.5,
    '& .MuiAvatar-root': {
        width: 32,
        height: 32,
        ml: -0.5,
        mr: 1,
    },
    '&:before': {
        content: '""',
        display: 'block',
        position: 'absolute',
        top: 0,
        right: 14,
        width: 10,
        height: 10,
        bgcolor: 'background.paper',
        transform: 'translateY(-50%) rotate(45deg)',
        zIndex: 0,
    },
}

export { 
    HeaderStyles, 
    BreadcrumbStyles, 
    MuiBreadcrumbTheme,
    AccountWithBadgeStyles,
    AccountMenuPaperStyles
}
export default MainLayoutStyles
