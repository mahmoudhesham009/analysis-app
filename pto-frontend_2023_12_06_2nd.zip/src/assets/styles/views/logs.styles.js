import extraCommonDTStyles from 'assets/styles/shared/commonDatatableComponents.styles';

const LogsStyles = theme => ({
    logsRoot: {
        paddingTop: 25,
        "& .card-icon-wrapper": {
            display: "inline-block",
            marginRight: 20,
            "& > div": {
                float: "right"
            }
        },
        "& .tabsBox": {
            display: "flex",
            justifyContent: "center",
            alignItems: "center"
        },
        "& .tabsContent": {            
            "& > div": {
                paddingTop: 15
            }            
        },
    },
    deleteLogsBtn: {
        ...extraCommonDTStyles(theme).interactiveButton(theme.colors.rose[0]),   
    },
    disabledDeleteLogsBtn: {
        backgroundColor: "rgba(233,30,99,0.3) !important"
    },
    tabsRoot: {
        "& button": {
            borderRadius: 60,
            minHeight: "40px !important",
            "&:not(:last-child)": {
                marginRight: 16,
            }            
        },
        "&.validationTab": {
            "& button:nth-child(1)": {
                backgroundColor: "#006064",
                color: theme.colors.white                
            },
        },
        "&.migrationTab": {
            "& button:nth-child(2)": {
                backgroundColor: "#3D4B7F",
                color: theme.colors.white                
            }
        }
    },
    tabsIndicator: {
        backgroundColor: "transparent !important"
    },
})


const StatusCardsStyles = theme => ({
    statusCardsRoot: {
        display: "flex",
        // justifyContent: "space-between",
        alignItems: "center",
        "& .info-card": {
            padding: 15,
            flex: "0 0 25%",
            maxWidth: "25%",
            overflow: "hidden",
            textOverflow: "ellipsis",
            whiteSpace: "nowrap",
            "& span": {
                ...theme.fonts.comfortaa,
                fontSize: 30,
                fontWeight: "bold",
                color: "inherit"
            },
            "& p": {
                ...theme.fonts.comfortaa,
                color: "inherit",
                margin: "5px 0px 0px 0px",
                fontSize: 16,
                fontWeight: 900,
                // textTransform: "uppercase",
                "-webkit-text-stroke": ".5px"
            },
            "&:first-child": {
                borderRadius: "12px 0px 0px 12px"
            },
            "&:last-child": {
                borderRadius: "0px 12px 12px 0px"
            },
            "&.theme-purple": {
                backgroundColor: "#b39ddb",
                color: "#311b92"
            },
            "&.theme-info": {
                backgroundColor: "#33bfff",
                color: "#007bb2"
            },
            "&.theme-success": {
                backgroundColor: "#6fbf73",
                color: "#357a38"
            },
            "&.theme-danger": {
                backgroundColor: "#f44336",
                color: theme.colors.white,
            },
        }
    }
})

export { StatusCardsStyles }
export default LogsStyles
