import { memo } from "react";
import classNames from "classnames";
import PropTypes from "prop-types";
// *** styles ***
import styles from "assets/styles/components/Card/cardBody.styles";
import { createUseStyles } from 'react-jss';
const useStyles = createUseStyles(styles)



function CardBody({ className, children, plain, profile }) {
  
  const classes = useStyles();
  const cardBodyClasses = classNames({
    [classes.cardBody]: true,
    [classes.cardBodyPlain]: plain,
    [classes.cardBodyProfile]: profile,
    [className]: className !== undefined
  })

  return (
    <div className={cardBodyClasses}>
      {children}
    </div>
  );
}

CardBody.propTypes = {
  className: PropTypes.string,
  plain: PropTypes.bool,
  profile: PropTypes.bool,
  children: PropTypes.node
};

export default memo(CardBody)