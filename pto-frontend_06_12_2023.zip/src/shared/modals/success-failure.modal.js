import { memo } from 'react'
import { Modal, Box, Typography, Button } from '@mui/material';
//*** Icons ***
import FailureIcon from '@mui/icons-material/Cancel';
import SuccessIcon from '@mui/icons-material/CheckCircle';
//*** styles ***
import { createUseStyles } from 'react-jss';
import styles from 'assets/styles/shared/successFailureModal.styles';
const useStyles = createUseStyles(styles)

function SuccessFailureModal({ open, status, title, description, onCloseModal }) {
    const classes = useStyles()

    return (
        <Modal
            open={open}
            onClose={onCloseModal}
            className={classes.modal}
        >
            <Box sx={{ boxShadow: 24 }} className={classes.modalBox}>
                <div className="modal-check-icon">
                    {status === "success" ? <SuccessIcon /> : <FailureIcon />}
                </div>
                <Typography variant='h3' component='h3' className="modal-title">{title}</Typography>
                <Typography className="modal-description">{description}</Typography>
                <div className="modal-close-button-wrapper">
                    <Button onClick={onCloseModal}>
                        Close
                    </Button>
                </div>
            </Box>
        </Modal>
    )
}

export default memo(SuccessFailureModal)
