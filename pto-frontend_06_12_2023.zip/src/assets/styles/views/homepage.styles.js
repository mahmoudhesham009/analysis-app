import extraCommonDTStyles from 'assets/styles/shared/commonDatatableComponents.styles';



// *** common styles ***
const commonModalRootStyles = {
    display: "flex",
    justifyContent: "center",
    alignItems: "center"
}
const commonModalBoxStyles = theme => ({
    maxWidth: 500,
    width: "100%",
    padding: 20,
    borderRadius: 6,
    backgroundColor: theme.colors.white,
    outline: "unset",
    "& .modal-title": {
        fontSize: 24,
        fontWeight: 600
    },
    "& .top-section": {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        marginBottom: 20,
        "& button": {
            background: "#e8e8e8"
        }
    },
    "& .alert-section": {
        marginBottom: 15
    },
})
// *** common styles ***


const HomePageStyles = ({ hexToRgb, ...theme }) => ({
    homepageRoot: {
        paddingTop: 50,
        "& .top-actions-btn": {
            paddingLeft: 6,
            paddingRight: 10,
            boxShadow: "unset",
            "& svg": {
                verticalAlign: "middle",
                marginTop: -3
            },
            "&.create-new-job-button": {
                backgroundColor: theme.colors.primary[0],
            },
            "&.single-process-button": {
                borderColor: theme.colors.primary[0],
                color: theme.colors.primary[0],
                marginLeft: 10
            },
        },
        "& .card-icon-wrapper": {
            display: "inline-block",
            marginRight: 20,
            "& > div": {
                float: "right"
            }
        }
    },
    analysisBtn: {
        ...extraCommonDTStyles(theme).regularButton,
    },
    logsBtn: {
        ...extraCommonDTStyles(theme).warnButton,
    },
    disabledLogsBtn: {
        backgroundColor: "rgba(255,152,0,0.3) !important"
    },
    exceptionsBtn: {
        ...extraCommonDTStyles(theme).roseButton,
    },
    disabledExceptionsBtn: {
        backgroundColor: "rgba(233,30,99,0.3) !important"
    },
    migrationBtn: {
        ...extraCommonDTStyles(theme).interactiveButton(theme.colors.primary[0]),
    },
    validationBtn: {
        ...extraCommonDTStyles(theme).interactiveButton("#006064"),
        "& svg": {
            pointerEvents: "none"
        }
    }
})
const CreateNewJobModalStyles = theme => ({
    createNewJobModal: {
        ...commonModalRootStyles
    },
    modalBox: {
        ...commonModalBoxStyles(theme),
        "& .create-new-job-btn-wrapper": {
            marginTop: 25,
            "& button": {
                backgroundColor: theme.colors.primary[0],
            }
        },
        "& .overlapping-confirmation": {
            marginTop: 25,
            "& .actions": {
                marginTop: 15,
                "& .continue-btn": {
                    backgroundColor: "#ff9800",
                    "&, &:hover, &:active": {
                        boxShadow: "unset"
                    }
                },
                "& .cancel-btn": {
                    marginLeft: 10,
                    color: "rgb(102, 60, 0)"
                }
            }
        }
    }
})
const CreateSingleProcessModalStyles = theme => ({
    createSingleProcessModal: {
        ...commonModalRootStyles
    },
    modalBox: {
        ...commonModalBoxStyles(theme),
        "& .modal-title": {
            fontSize: 22,
            fontWeight: 600
        },
        "& form": {
            "& button": {
                marginTop: 15,
                "& > span": {
                    margin: 0
                }
            }            
        }
    }
})
const MigrateJobDialogStyles = theme => ({
    migrationConfirmDialog: {
        "& .acceptBtn": {
            backgroundColor: theme.colors.success[0],
            color: theme.colors.white
        },
        "& .rejectBtn": {
            backgroundColor: theme.colors.danger[0],
            color: theme.colors.white
        }
    }
})

export { CreateNewJobModalStyles, CreateSingleProcessModalStyles, MigrateJobDialogStyles }
export default HomePageStyles
