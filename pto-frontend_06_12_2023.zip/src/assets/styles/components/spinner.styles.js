const SpinnerStyles = theme => ({
    "@keyframes spinner": {
        from: {
            transform: "rotate(0deg)"
        },
        to: {
            transform: "rotate(360deg)"
        }
    },
    spinnerIcon: {
        animation: "$spinner 1s linear infinite forwards"
    },
    spinnerProgress: {
        marginRight: 7,
        verticalAlign: "sub",
        "& svg": {
            color: theme.colors.white
        }
    }
})


export default SpinnerStyles