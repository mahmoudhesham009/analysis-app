import { memo, createContext, useState, useEffect, useCallback } from 'react'
import axios from 'axios';
import { Link, useLocation } from 'react-router-dom';
import queryString from 'query-string';
// *** views ***
import ErrorPage from 'views/errorPage';
// *** components ***
import DeploymentList from 'components/views/analysis/deployment-list';
// *** hooks ***
import useNavigatingAway from "hooks/useNavigatingAway";
// *** config ***
import PtoResponse from 'config/analysis-dynamic-form.json'; // for demo only
import ProcessApi from 'config/process-api'
// *** styles ***
import { createUseStyles } from 'react-jss';
import styles from 'assets/styles/views/analysis.styles';
const useStyles = createUseStyles(styles)

export const AnalysisNavigatingAwayContext = createContext()

function AnalysisFormList() {
  const classes = useStyles()
  const location = useLocation();
  const parsed = queryString.parse(location.search);
  const [loading, setLoading] = useState(true)
  const [deployments, setDeployments] = useState([])
  const [errorOccurred, setErrorOccurred] = useState("")


  const [canShowDialogLeavingPage, setCanShowDialogLeavingPage] = useState(false);
  const [showDialogLeavingPage, confirmNavigation, cancelNavigation] = useNavigatingAway(canShowDialogLeavingPage);


  const terminateErrors = useCallback((e) => setErrorOccurred(""), []);

  useEffect(() => {
    window.addEventListener("beforeunload", terminateErrors);
    return () => {
      window.removeEventListener("beforeunload", terminateErrors);
    };
  }, [])

  useEffect(() => {
    if (!process.env.NODE_ENV || process.env.NODE_ENV === 'development') {
      //?=================[ DEV ]========================
      setTimeout(() => {
        const processedApi = ProcessApi({ backendResponse: PtoResponse, type: "analysis" })
        setLoading(false)
        setDeployments(processedApi)        
      }, 2000)
    }
    else {
      //?=================[ PROD ]========================
      const headers = { 'Content-Type': 'application/json' }
      axios
        .get(`/api/getJobsById/${parsed?.jobID}`, { headers })
        .then(response => {
          const processedApi = ProcessApi({ backendResponse: response?.data, type: "analysis" })
          setLoading(false)
          //! DEPRECATED: setDeployments(ProcessApi(response?.data))
          setDeployments(processedApi)
        })
        .catch(error => {
          console.log("error: ", error);
          console.error("Something went wrong while fetching data!");
          setLoading(false)
          setErrorOccurred(error.message)
        })
    }
  }, [])


  if (!Boolean(parsed?.jobID)) return (
    <ErrorPage
      errorMessage="Oops!&nbsp;&nbsp;<strong>[ Job ID ]</strong>&nbsp;&nbsp;is not present."
      extraJSX={
        <Link to="/">
          Back to Homepage
        </Link>
      }
    />
  )
  else if (Boolean(errorOccurred)) return (
    <ErrorPage
      errorMessage="Something went wrong while fetching data!"
      extraJSX={<code>{errorOccurred}</code>}
    />
  )
  else return (
    <div className={classes.analysis}>
      <AnalysisNavigatingAwayContext.Provider value={{
        canShowDialogLeavingPage: canShowDialogLeavingPage,
        showDialogLeavingPage: showDialogLeavingPage,
        confirmNavigation: confirmNavigation,
        cancelNavigation: cancelNavigation,
        setCanShowDialogLeavingPage: setCanShowDialogLeavingPage,
      }}>
        <DeploymentList
          loading={loading}
          deployments={deployments}          
          jobID={parsed.jobID}
          viewType="analysis"
          singleProcess={location.state?.singleProcess}
        />
      </AnalysisNavigatingAwayContext.Provider>
    </div>
  )
}

export default memo(AnalysisFormList)
