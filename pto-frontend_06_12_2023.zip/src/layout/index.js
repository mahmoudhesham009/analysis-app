import { memo, useLayoutEffect, useContext } from 'react'
import { Outlet, UNSAFE_NavigationContext } from "react-router-dom";
//*** components ***
import Header from './components/header';
// *** redux ***
import { useDispatch } from 'react-redux'
import {
    ChangeExpandedParentAccordion,
    ChangeExpandedChildAccordion    
} from '@redux'
//*** styles ***
import { createUseStyles } from 'react-jss';
import styles from 'assets/styles/layout/mainLayout.styles';
const useStyles = createUseStyles(styles)

function MainLayout({ isLoggedIn }) {
    const classes = useStyles()
    const dispatch = useDispatch()


    const navigation = useContext(UNSAFE_NavigationContext).navigator;
    useLayoutEffect(() => {
        window.scrollTo(0, 0)
        if (navigation) {
            navigation.listen((locationListener) => {
                // console.log("Route Changes! : ", locationListener.location.pathname)
                // if (!(window.performance.timing.loadEventEnd > 0)) {
                // console.log("%c DETECT ROUTE CHANGE WITHOUT PAGE REFRESH! : ", "background: #FFFF00")
                dispatch(ChangeExpandedParentAccordion(null))
                if (locationListener.location.pathname === "/analysis" || locationListener.location.pathname === "/add-exception" || locationListener.location.pathname === "/exceptions") {                    
                    dispatch(ChangeExpandedChildAccordion(null))
                }
                // }
            });
        }
    }, [navigation])




    return (
        <div className={classes.root}>
            {isLoggedIn && <Header />}
            <main>
                <Outlet />
            </main>
        </div>
    )
}

export default memo(MainLayout)
