import { memo, useState, useRef } from 'react'
import { Alert, AlertTitle, Modal, Box, Stack, Typography, Button, IconButton, Slide, Collapse } from '@mui/material';
import { Formik, Form, Field } from 'formik'
import * as Yup from 'yup'
import axios from 'axios';
import moment from 'moment';
import { motion } from 'framer-motion'
// *** components ***
import DatePicker from 'components/FormFields/Datepicker/formik-date-picker';
import Spinner from 'components/spinner'
// *** icons ***
import CloseIcon from '@mui/icons-material/Close';
// *** styles ***
import { CreateNewJobModalStyles } from 'assets/styles/views/homepage.styles';
import { createUseStyles } from 'react-jss';
const useStyles = createUseStyles(CreateNewJobModalStyles)



function getMinDate() {
    return new Date(1900, 0, 1)
}

function getMaxDate() {
    return new Date()
}


const initialDate = moment(new Date()).format("MM/DD/YYYY").toString()
const dateValidation = Yup.date()
    .nullable()
    .min(getMinDate(), "Date is too short.")
    .max(getMaxDate(), "Date is too intense.")
    .typeError("Invalid Date.")
    .required("Required Field.")

const initialValues = { fromDate: initialDate, toDate: initialDate }
const validationSchema = Yup.object({ fromDate: dateValidation, toDate: dateValidation })
const alertInitialState = { open: false, severity: "success", message: "" }


function CreateNewJobModal({ open, onClose }) {
    const classes = useStyles();
    const formikRef = useRef(null)
    const [loading, setLoading] = useState(false)
    const [alert, setAlert] = useState(alertInitialState)
    const [overlappingDetected, setOverlappingDetected] = useState(false)
    const [overlappingMessage, setOverlappingMessage] = useState("")
    const [processInstanceIDs, setProcessInstanceIDs] = useState([])
    const [userCreateOneJobSuccessfully, setUserCreateOneJobSuccessfully] = useState(false)


    const handleClickCloseModal = () => {
        setLoading(false)
        setAlert(alertInitialState)
        setOverlappingDetected(false)
        setOverlappingMessage("")
        setProcessInstanceIDs([])
        onClose(userCreateOneJobSuccessfully)
        setUserCreateOneJobSuccessfully(false)
    }

    const createNewJob = () => {
        const headers = { "Content-type": "application/json" }
        const body = {
            "fromDate": moment(formikRef.current.values.fromDate).format("YYYY-MM-DD").toString(),
            "toDate": moment(formikRef.current.values.toDate).format("YYYY-MM-DD").toString(),
            "singleProcess": false
        }

        axios
            .post("/api/createNewJob", body, { headers })
            .then(response => {
                setAlert({ open: true, severity: "success", message: "A New Analysis Job Was Created." })
                setUserCreateOneJobSuccessfully(true)
            })
            .catch(error => {
                console.log("error: ", error);
                setAlert({ open: true, severity: "error", message: "Couldn't Create a New Analysis Job." })
            })
            .finally(() => {
                formikRef.current.setSubmitting(false)
                setLoading(false)
                setOverlappingDetected(false)
                setOverlappingMessage("")
                setProcessInstanceIDs([])
            })
    }

    const onSubmit = ({ fromDate, toDate }, { setSubmitting }) => {
        setLoading(true)

        if (!process.env.NODE_ENV || process.env.NODE_ENV === 'development') {
            //?=================[ DEV ]========================
            setTimeout(() => {
                // const isOverlap = (Math.floor(Math.random() * (1000 - 10 + 1) + 10)) % 2 === 0
                const isOverlap = true
                if (!isOverlap)
                    createNewJob()
                else {
                    setLoading(false)
                    setAlert(alertInitialState)
                    setOverlappingDetected(true)
                    setOverlappingMessage("Overlapping detected. if you decide to continue, all new cloned processes inside this ovarlapping timeframe will be deleted.")
                    setProcessInstanceIDs([
                        "93e181ce-91d7-11ed-a1eb-0242ac120002",
                        "d67de0b1-9309-42de-b3b4-95d3ec6f0910",
                        "8232cb44-3739-4151-a545-e05a996ab443",
                        "26d9e3c3-6082-4df6-afd0-3a7f025e265a",
                        "50b991d2-7ad9-445d-85d6-3cb634060d66"
                    ])
                }
            }, 2000)
        }
        else {
            //?=================[ PROD ]========================
            const headers = { "Content-type": "application/json" }
            const body = {
                "fromDate": moment(fromDate).format("YYYY-MM-DD").toString(),
                "toDate": moment(toDate).format("YYYY-MM-DD").toString()
            }

            axios
                .post("/api/checkOverlapping", body, { headers })
                .then(response => {
                    if (String(response?.data?.statusCode) === "200") {
                        setLoading(false)
                        setAlert(alertInitialState)
                        setOverlappingDetected(true) // warning popup will appear to user
                        setOverlappingMessage(response?.data?.message)
                        setProcessInstanceIDs(response?.data?.processInstanceIDs)
                    }
                    else createNewJob()
                })
                .catch(error => {
                    setLoading(false)
                    setSubmitting(false)
                    setAlert({ open: true, severity: "error", message: "Something went wrong while validating overlap. Please try again later." })
                })
        }
    }

    const onUserConfirmOverlapping = () => {
        //TODO: FIRST Delete processInstanceIDs then creating new job
        setLoading(true)
        const headers = { "Content-type": "application/json" }
        axios
            .post("/api/confirmDeleteAllNewProcesses", processInstanceIDs, { headers })
            .then(response => createNewJob())
            .catch(error => {
                console.log("error: ", error);
                formikRef.current.setSubmitting(false)
                setLoading(false)
                setAlert({ open: true, severity: "error", message: "Couldn't Delete All New Process before creating a New Analysis Job." })
            })
    }

    const onUserCancelOverlapping = () => {
        formikRef.current.setSubmitting(false)
        setAlert(alertInitialState)
        setOverlappingDetected(false)
        setOverlappingMessage("")
        setProcessInstanceIDs([])
    }


    return (
        <Modal open={open} className={classes.createNewJobModal}>
            <Slide
                in={open}
                timeout={200}
                direction='up'
                unmountOnExit
            >
                <Box sx={{ boxShadow: 24 }} className={classes.modalBox}>
                    {alert.open && (
                        <motion.div
                            initial={{ opacity: 0, scale: 0.5 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ duration: 0.5 }}
                        >
                            <Alert
                                variant="outlined"
                                severity={alert.severity}
                                className="alert-section"
                            >
                                {alert.message}
                            </Alert>
                        </motion.div>
                    )}

                    <div className="top-section">
                        <Typography variant='h3' component='h3' className="modal-title">
                            Create New Job
                        </Typography>

                        <IconButton onClick={handleClickCloseModal}>
                            <CloseIcon />
                        </IconButton>
                    </div>


                    <Formik
                        innerRef={formikRef}
                        initialValues={initialValues}
                        validationSchema={validationSchema}
                        onSubmit={onSubmit}
                    >
                        {formik => {
                            return (
                                <Form>
                                    <Stack direction="column" spacing={2}>
                                        <Field name="fromDate">
                                            {({ field, form, meta }) => (
                                                <DatePicker
                                                    id="fromDate"
                                                    labelText="Date From"
                                                    fullWidth
                                                    error={Boolean(formik.touched.fromDate && formik.errors.fromDate)}
                                                    helperText={formik.touched.fromDate && formik.errors.fromDate ? formik.errors.fromDate : ""}
                                                    disabled={formik.isSubmitting}
                                                    setFieldTouched={formik.setFieldTouched}
                                                    {...formik.getFieldProps("fromDate")}
                                                />
                                            )}
                                        </Field>
                                        <Field name="toDate">
                                            {({ field, form, meta }) => (
                                                <DatePicker
                                                    id="toDate"
                                                    labelText="Date To"
                                                    fullWidth
                                                    error={Boolean(formik.touched.toDate && formik.errors.toDate)}
                                                    helperText={formik.touched.toDate && formik.errors.toDate ? formik.errors.toDate : ""}
                                                    disabled={formik.isSubmitting}
                                                    setFieldTouched={formik.setFieldTouched}
                                                    {...formik.getFieldProps("toDate")}
                                                />
                                            )}
                                        </Field>
                                    </Stack>


                                    {overlappingDetected ? (
                                        <motion.div
                                            className="overlapping-confirmation"
                                            initial={{ opacity: 0, scale: 0.5 }}
                                            animate={{ opacity: 1, scale: 1 }}
                                            transition={{ duration: 0.5 }}
                                        >
                                            <Alert variant="standard" severity="warning">
                                                <AlertTitle>Warning</AlertTitle>
                                                <Typography>{overlappingMessage}</Typography>
                                                <div className='actions'>
                                                    <Button
                                                        variant='contained'
                                                        className="continue-btn"
                                                        onClick={onUserConfirmOverlapping}
                                                        disabled={loading}
                                                    >
                                                        {loading && <Spinner size={17} />}Continue
                                                    </Button>
                                                    <Button
                                                        className="cancel-btn"
                                                        disabled={loading}
                                                        onClick={onUserCancelOverlapping}
                                                    >
                                                        Cancel Please
                                                    </Button>
                                                </div>
                                            </Alert>

                                        </motion.div>
                                    ) : (
                                        <div className="create-new-job-btn-wrapper">
                                            <Button 
                                                type="submit" 
                                                variant="contained"
                                                disabled={userCreateOneJobSuccessfully}
                                            >
                                                <span>{loading && <Spinner size={17} />}Create</span>
                                            </Button>
                                        </div>
                                    )}
                                </Form>
                            )
                        }}
                    </Formik>
                </Box>
            </Slide>
        </Modal>
    )
}

export default memo(CreateNewJobModal)
