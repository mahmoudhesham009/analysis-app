import React from 'react'
import PropTypes from 'prop-types'
import classNames from 'classnames'
import { Fab, Tooltip } from '@mui/material';
// *** styles ***
import { createUseStyles } from 'react-jss';
import styles from 'assets/styles/components/FormFields/floatingActionButton.styles'
const useStyles = createUseStyles(styles);



function FloatingActionButton({ text, variant, icon, toolTipTitle, ...other }) {
    const classes = useStyles();

    return (
        <Tooltip title={toolTipTitle}>
            <Fab variant={variant} {...other}>
                {
                    icon &&
                    <div className={classNames(classes.middleIcon, { [classes.extendedIcon]: text })}>
                        {icon}
                    </div>
                }
                {text && text}
            </Fab>
        </Tooltip>
    )
}

FloatingActionButton.propTypes = {
    text: PropTypes.string,
    variant: PropTypes.oneOf(["extended", "round"]).isRequired
}

export default React.memo(FloatingActionButton)
