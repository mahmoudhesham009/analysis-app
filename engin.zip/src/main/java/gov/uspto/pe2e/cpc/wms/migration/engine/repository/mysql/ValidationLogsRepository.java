package gov.uspto.pe2e.cpc.wms.migration.engine.repository.mysql;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface ValidationLogsRepository extends JpaRepository<ValidationLogs, Integer>{

	List<ValidationLogs> findByJobId(Integer jobId);
	
	
	@Query(value="select * from validation_logs where job_id=:jobId and process_id=:processId", nativeQuery=true)
	ValidationLogs findByJobIdAndprocessId(Integer jobId, String processId);
	
}
