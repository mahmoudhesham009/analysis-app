/**
 * 
 */
package gov.uspto.pe2e.cpc.ipc.rest.web.util.business;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

import javax.annotation.Nonnull;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.common.collect.Lists;

import fun.mike.dmp.DiffMatchPatch;

/**
 * @author myoung3
 *
 */
public final class CpcDiffTool {
	private static final Logger log = LoggerFactory.getLogger(CpcDiffTool.class);
	public static final ObjectMapper DIFF_MAPPER = new ObjectMapper();
	public static final DiffMatchPatch DIFFMATCHPATCH = new DiffMatchPatch();
	public static final String MUNGABLE_PATCH_OPERATION_VALUE = "replace";
	public static final String PATCH_OPERATION_FIELD_NAME = "op";
	public static final String PATCH_PATH_FIELD_NAME = "path";
	public static final String TREE_RAWTEXT_ATTR_NAME = "content";
	public static final String RAWTEXT_NAME = "RAW";

	/**
	 * Walk over all patch JsonNodes and realign orginal structure and create faux
	 * JsonNode tree that is capable of creating a more focused Diff of text nodes
	 * by chopping up the text object into a series of smaller Objects that match
	 * more broadly
	 * 
	 * @return
	 */
	public static Pair<JsonNode, JsonNode> realignTextDiffs(@Nonnull JsonNode leftTree, @Nonnull JsonNode rightTree,
			@Nonnull JsonNode patchList) {
		ArrayList<JsonNode> elements = Lists.newArrayList(patchList.elements());

		for (JsonNode patchEl : elements) {
			if (isMungableNode(leftTree, rightTree, patchEl)) {
				JsonNode me = leftTree
						.at(StringUtils.substringBeforeLast(patchEl.get(PATCH_PATH_FIELD_NAME).asText(), "/content"));
				String parentPath = deriveParentPath(patchEl.get(PATCH_PATH_FIELD_NAME).asText());
				JsonNode parent = leftTree.at(parentPath);
				JsonNode siblingNode = parent.get("children");
				if (siblingNode.isArray()) {
					LinkedList<JsonNode> siblings = Lists.newLinkedList();
					Iterator<JsonNode> itr = siblingNode.elements();
					while (itr.hasNext()) {
						siblings.add(itr.next());
					}
					// log.debug("elementNode Elements() class = {}",
					// siblingNode.elements().getClass());

					// siblings.addAll( siblingNode.elements());
					if (areAllSiblingsRawTextsiblings(siblings)) {
						// LinkedList<JsonNode> wordbreak =
						// log.debug("siblingArray {}", siblingNode);
						// for (JsonNode n: siblings) {
						// if (n == me) {
						// log.debug("found the node of me");
						// }
						////
						//// }
						// }
					}

				}

				// log.debug("PAtch Operation =
				// {}",patchEl.get(PATCH_OPERATION_FIELD_NAME).getClass());
			}
			// log.debug("Node = {} at path {}", node.getNodeType(), path);

		}
		return Pair.of(leftTree, rightTree);

	}

	private static boolean areAllSiblingsRawTextsiblings(LinkedList<JsonNode> siblings) {
		boolean isRaw = true;
		for (JsonNode n : siblings) {
			if (!StringUtils.equals(RAWTEXT_NAME, n.get("type").asText())) {
				isRaw = false;
				break;
			}
		}
		return isRaw;
	}

	private static boolean isMungableNode(JsonNode leftTree, JsonNode rightTree, JsonNode patchEl) {
		String op = patchEl.get(PATCH_OPERATION_FIELD_NAME).asText();
		String nodePath = patchEl.get(PATCH_PATH_FIELD_NAME).asText();
		JsonNode leftNode = leftTree.at(nodePath);

		return StringUtils.equals(MUNGABLE_PATCH_OPERATION_VALUE, op) && nodePath.endsWith("/content")
				&& StringUtils.equals("STRING", leftNode.getNodeType().toString());
	}

	private static String deriveParentPath(String path) {

		return StringUtils.substringBeforeLast(path, "/children");
	}

	public static JsonNode breakTextNodesOnWhiteSpace(JsonNode tree) {
		log.debug("Tree ={}", tree);
		findAndSplitTextNodes(tree);

		return tree;
	}

	private static void findAndSplitTextNodes(JsonNode node) {
		JsonNode arrayNode = node.get("children");
		if (arrayNode.isArray()) {
			LinkedList<JsonNode> newChildren = new LinkedList<>();
			Iterator<JsonNode> itr = arrayNode.elements();
			while (itr.hasNext()) {
				JsonNode child = itr.next();
				JsonNode childType = child.get("type");
				if (!childType.isMissingNode() && StringUtils.equals(childType.asText(), RAWTEXT_NAME)) {
					int i = 0;
					String[] content = child.get("content").asText().split("\\s");
					for (String word : content) {
						if (i++ > 0) {
							word = " " + word;
						}
						ObjectNode n = DIFF_MAPPER.createObjectNode();
						n.putArray("children");
						n.put("content", word);
						newChildren.add(n);
					}

				} else {
					newChildren.add(child);
					findAndSplitTextNodes(child);
				}
			}
			((ObjectNode) node).putArray("children").addAll(newChildren);
		}

	}

}
