package gov.uspto.pe2e.cpc.ipc.rest.web.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Nonnull;
import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import gov.uspto.pe2e.cpc.ipc.rest.commons.model.SymbolName;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.IpcSymbolHierarchy;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.SchemeHierarchy;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.IpcSymbolHierarchyRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.SchemeHierarchyRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.business.IpcConcordanceUtils;
import gov.uspto.pe2e.cpc.ipc.rest.contract.ipcconcordance.v1_0.IpcConcordanceMapping;
import gov.uspto.pe2e.cpc.ipc.rest.contract.ipcconcordance.v1_0.IpcSymbol;
import lombok.RequiredArgsConstructor;

/**
 * Basic service for interacting with IpcSymbolHierarchy and converting them to Rest 
 * contract object
 * @author 2020
 * @version 1.6
 * @date: 12/7/2017
 *
 */
@Service("ipcConcordanceService")
@RequiredArgsConstructor(onConstructor=@__(@Inject))
public class IpcConcordanceService {
	
    private static final Logger log = LoggerFactory.getLogger(IpcConcordanceService.class);
    
    private static final String CPCONLY_IPC_CONCORDANT_CODE = "CPCONLY";
    
    @Nonnull
    private SchemeHierarchyRepository schemeHierarchyRepository;
    
    @Nonnull
    private IpcSymbolHierarchyRepository ipcSymbolHierarchyRepository;        

    /**
     * Use provided logic to find IPC mapping based on CPCSymbolName
     * @param cpcSymbolName
     * @return IpcConcordanceMapping
     * @since Dec 7, 2016
     */
    public @Nonnull IpcConcordanceMapping resolveIpcConcordanceMapping(@Nonnull String cpcSymbolName) {
        
    	IpcConcordanceMapping mapping = null;        
		SchemeHierarchy dbSymbol = schemeHierarchyRepository
				.findByNameFromLatestSchemeNotIncludingHeadingSymbols(cpcSymbolName);
        if (dbSymbol == null) {
            mapping = createIpcConcordanceMapping(cpcSymbolName);
        } else {
            if (StringUtils.isNotBlank(dbSymbol.getIpcConcordantCode())) {
                if (dbSymbol.getIpcConcordantCode() != null 
                        && dbSymbol.getIpcConcordantCode().equals(CPCONLY_IPC_CONCORDANT_CODE)) {
                    mapping = createIpcConcordanceMapping(cpcSymbolName, Boolean.TRUE);
                } else {
                    mapping = createIpcConcordanceMapping(cpcSymbolName, dbSymbol.getIpcConcordantCode());
                }
            } else if (dbSymbol.getTwoThousandSymbol() != null 
                    && dbSymbol.getTwoThousandSymbol().equals(Boolean.TRUE)) { // No IPC concordance AND is 2000 series
                mapping = createIpcConcordanceMappingWithNoIpcConcordantValue(cpcSymbolName, dbSymbol);
                
            } else {
                mapping = createIpcConcordanceMapping(cpcSymbolName);                
            }
        }
        return mapping;
    }    

    /**
     * Create IpcConcordanceMapping for non-two thousand series Assuming the IPC Concorant code exists.  
     * if it does not, leave it blank
     * @param cpcSymbolName
     * @param ipcConcordantCode
     * @return IpcConcordanceMapping
     * @since Dec 20, 2016
     */
    private IpcConcordanceMapping createIpcConcordanceMapping(String cpcSymbolName, String ipcConcordantCode) {
        IpcConcordanceMapping mapping = createIpcConcordanceMapping(cpcSymbolName);
		IpcSymbolHierarchy ipcSymbolHierarchy = ipcSymbolHierarchyRepository
				.findBySymbolNameInLatest(ipcConcordantCode);
        if (ipcSymbolHierarchy != null) {
            IpcSymbol ipcSymbol = mapIpcSymbol(ipcSymbolHierarchy);
            mapping.setGeneratedIpcSymbol(ipcSymbol);
        }
        return mapping;
    }

    /**
     * Calculate IPC concordance when No IPC is found based on following rules:
     * 1) lookup IPC Symbol by symbol sort key
     *      if found map to generated symbol (CPCONLY = false)
     * 2) if IPC  symbol is not found for sort key, convert sort key to main group
     *      by replacing value after / with 00 and searching again
     *      if maingroup is found map generated symbol (CPCONLY = false)
     * 3) if maingroup sort key is not found CPCONLY = false and generated symbol is null
     * @param cpcSymbolName String
     * @param dbSymbol SchemeHierarchy
     * @return IpcConcordanceMapping
     * @since Dec 20, 2016
     */
	private IpcConcordanceMapping createIpcConcordanceMappingWithNoIpcConcordantValue(String cpcSymbolName,
			SchemeHierarchy dbSymbol) {
    	
        IpcConcordanceMapping mapping = createIpcConcordanceMapping(cpcSymbolName);
        if (dbSymbol != null) {
			IpcSymbolHierarchy ipcSymbolHierarchy = ipcSymbolHierarchyRepository
					.findBySymbolNameInLatest(dbSymbol.getSortKey());
            if (ipcSymbolHierarchy != null) {
                IpcSymbol ipcSymbol = mapIpcSymbol(ipcSymbolHierarchy);
                mapping.setGeneratedIpcSymbol(ipcSymbol);
            } else {
                String mainclassSymbolName = convertSortKeyToMainCGroup(dbSymbol.getSortKey());
                log.debug("Trying maing group symbol {} for {}", mainclassSymbolName, cpcSymbolName);
				SchemeHierarchy mainGroupSymbol = schemeHierarchyRepository
						.findByNameFromLatestSchemeNotIncludingHeadingSymbols(mainclassSymbolName);
                if (mainclassSymbolName != null ) {
					ipcSymbolHierarchy = ipcSymbolHierarchyRepository
							.findBySymbolNameInLatest(mainGroupSymbol.getClassificationSymbolCode());
                    if (ipcSymbolHierarchy == null) {
                        mapping.setCpcOnly(true);
                    }
                }
            }
        }
        return mapping;
    }
    
    /**
     * Replaces value after "/" with 00
     * if no slash exists, the sortkey is returned un-munged!
     * @param sortKeyName
     * @return String representing maingroup sort key
     * @since Dec 20, 2016
     */
    public String convertSortKeyToMainCGroup(String sortKeyName) {
        if (StringUtils.contains(sortKeyName,  SymbolName.SLASH )) {
            sortKeyName = StringUtils.substringBefore(sortKeyName, SymbolName.SLASH);
            sortKeyName = sortKeyName+SymbolName.SLASH+SymbolName.SUBGROUP_FOR_MAINGROUP_IDENT_VALUE;
        }
        return sortKeyName;
    }

    /**
     * Map IPC Symbol based on record
     * @param ipcSymbolHierarchy
     * @return IpcSymbol
     * @since Dec 20, 2016
     */
    protected IpcSymbol mapIpcSymbol(IpcSymbolHierarchy ipcSymbolHierarchy) {
        return IpcConcordanceUtils.mapIpcSymbol(ipcSymbolHierarchy);
    }
    
    /**
     * Map IPC Symbol based on record
     * @param ipcSymbolHierarchy
     * @return IpcSymbol
     * @since Dec 20, 2016
     */
    @Deprecated // I don't think we are using this anywhere.  We aught to try and remove if possible
    protected IpcSymbol mapIpcSymbol(String symbolName) {
        IpcSymbol ipcSymbol = null;
        if ( StringUtils.isNotEmpty(symbolName)) {
            IpcSymbolHierarchy ipcSymbolFromDb = ipcSymbolHierarchyRepository.findBySymbolNameInLatest(symbolName);
            ipcSymbol = IpcConcordanceUtils.mapIpcSymbol(ipcSymbolFromDb);
        }
        return ipcSymbol;
    }


    /**
     * Create IpcConcordanceMapping with symbol name and whether cpconly or not
     * @param cpcSymbolName
     * @param cpcOnly
     * @return IpcConcordanceMapping
     * @since Dec 20, 2016
     */
    protected IpcConcordanceMapping createIpcConcordanceMapping(@Nonnull String cpcSymbolName, boolean cpcOnly) {
        IpcConcordanceMapping mapping = new IpcConcordanceMapping();
        mapping.setCpcOnly(cpcOnly);
        mapping.setSymbolName(cpcSymbolName);
        return mapping;
    }

    /**
     * Create basic mapping object with cpcSymboName and default CPCONLY value (false)
     * @param cpcSymbolName
     * @return IpcConcordanceMapping
     * @since Dec 20, 2016
     */
    private IpcConcordanceMapping createIpcConcordanceMapping(String cpcSymbolName) {
        return createIpcConcordanceMapping(cpcSymbolName, Boolean.FALSE);
    }

    /**
     * Calls resolveIpcConcordanceMapping() in a loop for each string symbol name
     * EVERY symbol in the list should have a corresponding non-null mapping with at least the CPCONLY 
     * boolean and the original symbol name.
     * 
     * @param cpcSymbolName
     * @return List<IpcConcordanceMapping>
     * @since Dec 7, 2016
     */
    public List<IpcConcordanceMapping> resolveIpcConcordanceMappings(List<String> cpcSymbolNames) {
    	
        List<IpcConcordanceMapping> mappings = new ArrayList<>();        
        if(CollectionUtils.isNotEmpty(cpcSymbolNames)){
            for (String cpcSymbolName: cpcSymbolNames) {
                mappings.add(resolveIpcConcordanceMapping(cpcSymbolName));
            }        	
        }
        return mappings;
    }

    /**
     * Finds list of IPC symbol starting with given string (type ahead search)
     * @param ipcSymbolNameSubstring
     * @return List<String>
     * @since Jan, 05, 2017 
     */
    public List<String> findSymbolsStartingWith(String ipcSymbolNameSubstring) {        
        return ipcSymbolHierarchyRepository.findBySymbolNameInLatestStartingWith(ipcSymbolNameSubstring);
    }
}
