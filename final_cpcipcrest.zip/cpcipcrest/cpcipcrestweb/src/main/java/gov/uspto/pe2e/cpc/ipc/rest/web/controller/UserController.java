package gov.uspto.pe2e.cpc.ipc.rest.web.controller;

import javax.annotation.Nonnull;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.saml.SAMLAuthenticationToken;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import gov.uspto.pe2e.cpc.ipc.rest.commons.security.SecurityService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.RestUtils;
import gov.uspto.pe2e.cpc.ipc.rest.contract.saml.UsptoAuthenticationToken;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;

/**
 * US5079: SAML Prototype - External Domain
 * 
 * User Controller
 * 
 * @author 2020
 * @version 1.0
 * @date: 08/4/2015
 *
 */
@Api(value = "/users", description = "Handles all access to authenticated user resources.")
@Component
@RestController
@RequestMapping(value = "/users")
@RequiredArgsConstructor(onConstructor=@__(@Inject))
public class UserController {
    private static final Logger log = LoggerFactory.getLogger(UserController.class);

    @Nonnull
    private SecurityService securityService;

    /**
     * Method to Parse Saml Token
     * 
     * @return UsptoAuthenticationToken
     */
    @ApiOperation("Pulls the Saml Authentication Token from the spring authentication framework "
            + " and parses it out into a Model Object Specifically defined in our service Contract XSDs ")
    @PreAuthorize("isAuthenticated()")
    @RequestMapping(value = "/authentication", method = { RequestMethod.GET })
    @ResponseBody
    public ResponseEntity<UsptoAuthenticationToken> parseSamlToken() {
        UsptoAuthenticationToken usptoToken = null;
        if (SecurityContextHolder.getContext() != null && SecurityContextHolder.getContext().getAuthentication() != null) {
            Object authObj = SecurityContextHolder.getContext().getAuthentication();
            log.debug("Authentication Class is {}! is it Castable to SAMLAuthenticationToken? {}",
                    authObj.getClass().getCanonicalName(), SAMLAuthenticationToken.class.isAssignableFrom(authObj.getClass()));

            Authentication samlAuthenticationToken = (Authentication) authObj;
            log.debug("Saml authentication token: [principal={} credentials={} authorities={}]",
                    samlAuthenticationToken.getPrincipal(), samlAuthenticationToken.getCredentials(),
                    samlAuthenticationToken.getAuthorities());
            usptoToken = securityService.mapSamlTokenToContractModel(samlAuthenticationToken);
        }

        return new ResponseEntity<>(usptoToken, RestUtils.buildRestHttpHeaders(), HttpStatus.OK);

    }
}
