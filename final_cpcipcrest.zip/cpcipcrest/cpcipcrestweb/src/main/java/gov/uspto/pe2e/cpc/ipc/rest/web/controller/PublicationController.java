package gov.uspto.pe2e.cpc.ipc.rest.web.controller;

import java.util.Date;
import java.util.List;

import javax.annotation.Nonnull;
import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import gov.uspto.pe2e.cpc.ipc.rest.commons.util.RestUtils;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.web.service.PublicationService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;

/**
 * Class serves as Publication Controller
 * 
 * @author 2020
 * @date May 10, 2017
 * @version 1.8
 *
 */
@Component
@Api(value = "/publications", description = "Controller for Publications")
@RestController
@RequestMapping(value = "/publications")
@RequiredArgsConstructor(onConstructor=@__(@Inject))
public class PublicationController {

    @Nonnull
    private PublicationService publicationService;

    /**
     * Provide the list of publication versions.
     *
     * @param minDate
     * @return List<SchemePublicationVersion>
     */
    @ApiOperation("Provide list of publications version")
    @RequestMapping(value = "/versions", method = RequestMethod.GET)
    @ResponseBody
    public ResponseEntity<List<SchemePublicationVersion>> listPublicatons(
            @RequestParam(value = "minDate", required = false) Date minDate) {
        HttpStatus status = HttpStatus.OK;
        HttpHeaders headers = RestUtils.buildRestHttpHeaders();
        List<SchemePublicationVersion> publications = publicationService.getPublishedVersions(minDate);
        if (CollectionUtils.isEmpty(publications)) {
            status = HttpStatus.NO_CONTENT;
        }
        return new ResponseEntity<>(publications, headers, status);
    }
}