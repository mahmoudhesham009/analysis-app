package gov.uspto.pe2e.cpc.ipc.rest.web.config;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Bean;

import com.google.common.collect.Sets;

import gov.uspto.pe2e.cpc.ipc.rest.commons.util.RestUtils;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.Parameter;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

/**
 * Class for use with Swagger Documentation and Service Testing
 *
 * @author 2020
 * @version 1.1
 * @date: 08/4/2015
 *
 */
@EnableSwagger2
public class ApplicationSwaggerConfig {
    private static final String HEADER_PARAMETER_TYPE = "header";
    private static final String SCHEME_PUBLICATION_DATE_HEADER_DESC = "*Optional* publication date (format: yyyy-MM-dd).  "
            + "If empty, null or otherwise invalid latest (gold copy) publication is used ";
    
    @Bean
     public Docket api() {
         ParameterBuilder licenseHeaderBuilder = new ParameterBuilder();
            licenseHeaderBuilder.name(RestUtils.SCHEME_PUBLICATION_DATE_HEADER)
            .modelRef(new ModelRef(String.class.getSimpleName().toLowerCase()))
            .parameterType(HEADER_PARAMETER_TYPE).description(SCHEME_PUBLICATION_DATE_HEADER_DESC)
            .required(false).build();

//            ParameterBuilder acceptHeaderBuilder = new ParameterBuilder();
//            acceptHeaderBuilder.name(HttpHeaders.ACCEPT)
//            .modelRef(new ModelRef(String.class.getSimpleName().toLowerCase()))
//            .parameterType(HEADER_PARAMETER_TYPE)
//            .description("Response type (json or XML) that you expect")
//            .allowableValues(new AllowableListValues(Arrays.asList("application/json", "application/xml"),
//            		String.class.getSimpleName().toLowerCase()))
//            .defaultValue("application/json")
//            
//            .required(true)
//            .build();

           // ParameterBuilder acceptHeaderBuilder = new Hea
            List<Parameter> aParameters = new ArrayList<>();
            aParameters.add(licenseHeaderBuilder.build());
           // aParameters.add(acceptHeaderBuilder.build());

            return new Docket(DocumentationType.SWAGGER_2)
                    .select()
                    .apis(RequestHandlerSelectors.any())
                    .paths(PathSelectors.any()).build()
                    .pathMapping(StringUtils.EMPTY)
                    
                    .consumes(Sets.newHashSet("application/json", "application/xml"))
                    .produces(Sets.newHashSet("application/json", "application/xml"))
                    .globalOperationParameters(aParameters);
     }
}
