package gov.uspto.pe2e.cpc.ipc.rest.web.controller;

import javax.annotation.Nonnull;
import javax.inject.Inject;
import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.RevisionChangeItemRequest;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.CpcDiffService;
import io.swagger.annotations.Api;
import lombok.RequiredArgsConstructor;

@Component
@Api(value = "/diff", description = "Controller for Diffing SCT rows")
@RestController
@RequestMapping(value = "/diff")
@PreAuthorize("hasAuthority('PROPOSAL_MANAGER_ENABLED') and hasAuthority('PROPOSAL_UPDATE')")
@RequiredArgsConstructor(onConstructor=@__(@Inject))
public class DiffController {
	
	@Nonnull
	private CpcDiffService cpcDiffService;
    
	@ResponseBody
    @RequestMapping(method = RequestMethod.POST)
	public ResponseEntity<RevisionChangeItemRequest> diff(@Valid @RequestBody RevisionChangeItemRequest sctRow) throws Exception {
		RevisionChangeItemRequest node = cpcDiffService.diffAgainstGoldCopy(sctRow);
		return new ResponseEntity<RevisionChangeItemRequest>(node, HttpStatus.OK);
	}

}
