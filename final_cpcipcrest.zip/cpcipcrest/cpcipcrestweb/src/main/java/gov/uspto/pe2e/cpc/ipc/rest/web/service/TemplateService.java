package gov.uspto.pe2e.cpc.ipc.rest.web.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.annotation.Nonnull;
import javax.annotation.Resource;
import javax.inject.Inject;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.StandardComponentPart;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.StandardComponentPartRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.AdapterUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.ReflexiveAnnotationUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.xml.JaxbUtils;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ComponentCategory;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ComponentPartCategory;
import gov.uspto.pe2e.cpc.ipc.rest.contract.templates.v1_0.ComponentTemplate;
import gov.uspto.pe2e.cpc.ipc.rest.contract.templates.v1_0.DefinitionSectionTemplate;
import gov.uspto.pe2e.cpc.ipc.rest.contract.templates.v1_0.NoteParagraphTemplate;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.Note;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.NoteParagraph;
import gov.uspto.pe2e.cpc.standard.definitions.v1_0.DefinitionItem;
import lombok.RequiredArgsConstructor;

/**
 * Service for generating templates for use with UI
 * @author 2020
 * @date May 4, 2017
 * @version 1.8
 *
 */
@Service
@RequiredArgsConstructor(onConstructor=@__(@Inject))
public class TemplateService {
    private static final Logger log = LoggerFactory.getLogger(TemplateService.class);
    
    private static final String NOTE_XML_PROLOGUE_TEMPLATE = "<notes-and-warnings><note type=\"%s\">";
    private static final String NOTE_XML_EPILOGUE = "</note></notes-and-warnings>";
    private static final String RECLASSIFICATION_DATE_ELEMENT_REGEX = "</{0,1}reclassification-date>";
    
    private static final String REFERENCES_GROUP_NAME = "references";
       
    @Nonnull
    private StandardComponentPartRepository standardNoteWarningTypeRepository;
    
    @Resource(name = "documentAdapterConfig")
    private Map<String, String> documentAdapterConfig;   

    /**
     * Find available and map to rest contract model
     * @param category
     * @param includeTemplates
     * @return List<NoteTemplate>
     * @since May 4, 2017
     */
    public List<ComponentTemplate> findAvailableNoteTemplatesByCategory(ComponentCategory category, boolean includeTemplates) {
        List<ComponentTemplate> templates = new ArrayList<>();
        List<StandardComponentPart> stdNaWTypes = ((category == null)
                ? standardNoteWarningTypeRepository.findAllUnexpired()
                : standardNoteWarningTypeRepository.findUnexpiredByCategory(category));
       
        if(CollectionUtils.isNotEmpty(stdNaWTypes)) {
	        for (StandardComponentPart dbObj: stdNaWTypes) {
	            templates.add(mapCompenentType(dbObj, includeTemplates));
	        }
        }
        return templates;
    } 
    
    /**
     * Finds the Note Template by short description ( name) and Category
     * @param name
     * @param category
     * @return NoteTemplate
     */
    public ComponentTemplate findAvailableTemplateByNameAndType(String name, ComponentCategory category) {        
        ComponentTemplate noteTemplate = null;
        if(StringUtils.isNotBlank(name) && category != null){
			StandardComponentPart stdNaWType = standardNoteWarningTypeRepository
					.findUnexpiredByShortDescriptionAndCategory(name, category);
        	noteTemplate = mapCompenentType(stdNaWType, true);
        }
        return noteTemplate;        
    }
    
    /**
     * Maps db record to rest contract object.
     * 
     * @param componentPartTemplate
     *            - db object containing notewarning type information
     * @param includeTemplate
     *            This determines whether or not we sould map the associated xml
     *            clob which has a performance hit. This should be false when
     *            dealing with lists and true when doing an individual record
     * @return NoteTemplate
     * @since May 5, 2017
     */
    protected ComponentTemplate mapCompenentType(StandardComponentPart componentPartTemplate, boolean includeTemplate) {
        ComponentTemplate tpl = null;
        if (componentPartTemplate != null) {
            if (componentPartTemplate.getCategory().equals(ComponentCategory.NOTE)
                    || componentPartTemplate.getCategory().equals(ComponentCategory.WARNING)) {
                tpl = new NoteParagraphTemplate();
                if (includeTemplate) {
                  mapNoteTemplate(componentPartTemplate, (NoteParagraphTemplate)tpl);
                }
            } else {
                tpl = new DefinitionSectionTemplate();
                if (includeTemplate) {
                    mapDefinitionTemplate(componentPartTemplate, (DefinitionSectionTemplate)tpl);
                }
            }
            // This sets null to false
            tpl.setDefaultTemplate(Boolean.TRUE.equals(componentPartTemplate.getDefaultIndicator()));

            tpl.setCategory(componentPartTemplate.getCategory());
            tpl.setHint(componentPartTemplate.getHint());
            tpl.setName(componentPartTemplate.getShortDescription());
        }
        return tpl;
    }
    /**
     * Map XML fragment for definition to template object
     * @param componentPartTemplate
     * @param tpl
     * @since Dec 7, 2017
     */
    private void mapDefinitionTemplate(StandardComponentPart componentPartTemplate, DefinitionSectionTemplate tpl) {
        
        String xml = wrapTemplateWithApproperiateDefStructure(componentPartTemplate);
        log.debug("Definition XML: "+xml);
        DocumentAdapter adapter = AdapterUtils.latest(documentAdapterConfig);
        DefinitionItem def = (DefinitionItem)adapter.getDefinitonModelRootType().cast(adapter.parseDefinition(xml));

        String[] props = (String[])ReflexiveAnnotationUtils.getAnnotationPropertyForClass(def.getClass(), 
                XmlType.class, JaxbUtils.XML_TAG_ANNOTATION_PROPORDER_PROPERTY);
        for (String fieldName: props) {
            log.debug("Field Name: "+fieldName);
            try {
                
                if(PropertyUtils.getProperty(def,fieldName) !=null){
                    if(fieldName.equals(REFERENCES_GROUP_NAME)){
                        Object ref = PropertyUtils.getProperty(def,fieldName);
                        String[] refProps = (String[])ReflexiveAnnotationUtils.getAnnotationPropertyForClass(ref.getClass(), 
                                XmlType.class, JaxbUtils.XML_TAG_ANNOTATION_PROPORDER_PROPERTY);
                        for (String refFieldName: refProps) {
                            if ( PropertyUtils.getProperty(ref, refFieldName) != null) {
                                PropertyUtils.setProperty(tpl, refFieldName, PropertyUtils.getProperty(ref,refFieldName));
                            
                             break; // innner for
                            } 
                        }
                    } else {
                    
                        PropertyUtils.setProperty(tpl, fieldName, PropertyUtils.getProperty(def,fieldName));
                    }
                    break;
                }
            
            } catch (Exception e) { // do something smart here
                
                log.error("Failed to set definition edit items",e);
                
            } 
        }

    }

    /**
     * Map XML fragment for definition to template object
     * @param componentPartTemplate
     * @param tpl
     * @since Dec 7, 2017
     */
    private void mapNoteTemplate(StandardComponentPart componentPartTemplate, NoteParagraphTemplate tpl) {
        Object nawObj = parseNoteTemplate(componentPartTemplate.getCategory(), componentPartTemplate.getTemplate());
        if (nawObj != null) {
            try {                        
                Note note = ((List<Note>) PropertyUtils.getProperty(nawObj,
                        AdapterUtils.TREE_CHILD_COLLECTION_PROPERTY_NAME)).get(0);
              
                for (Object child: (List)PropertyUtils.getProperty(note, AdapterUtils.TREE_CHILD_COLLECTION_PROPERTY_NAME)) {
                    if (NoteParagraph.class.isAssignableFrom(child.getClass())) {
                        tpl.setNoteItem((NoteParagraph)child);
                        break;
                    }
                }
            } catch (Exception e) {
                log.error("Failed to navigate object tree to first item", e);
            }
        }
        
        
    }

    /**
     * wrap definiton Xml with parsable root node 
     * @param componentPartTemplate
     * @return
     * @since Dec 8, 2017
     */
    private String wrapTemplateWithApproperiateDefStructure(StandardComponentPart componentPartTemplate) {
        String xmlFrag= "<definition-item>"+componentPartTemplate.getTemplate()+"</definition-item>";
        if (Arrays.asList(ComponentPartCategory.APPLICATION_REFERENCES,
                ComponentPartCategory.INFORMATIVE_REFERENCES, ComponentPartCategory.LIMITING_REFERENCES,
                ComponentPartCategory.RESIDUAL_REFERENCES).contains(componentPartTemplate.getPartCategory())) {
            xmlFrag= "<definition-item><references>"+componentPartTemplate.getTemplate()+"</references></definition-item>";
        }
        return xmlFrag;
    }

    /**
	 * This method parses the xml template clob into the LATEST note XML. It
	 * returns object in order to limit the number of places in the code we have
	 * to change if/when the cpc xml version gets bumped
	 * 
	 * @param category
	 * @param template
	 * @return Object
	 * @since May 5, 2017
	 */
    private Object parseNoteTemplate(ComponentCategory category, String template) {
        Object o = null; 
        StringBuilder noteXml = new StringBuilder();
        if (StringUtils.isNotBlank(template) && category != null) {
        	
        	//This is temporary fix. we are striping out the reclassification date tags from the template.
        	//TODO Reclassification date element needs to be added in the contract and adapter for to use as per new scheme XSD
			template = StringUtils.replacePattern(template, RECLASSIFICATION_DATE_ELEMENT_REGEX, StringUtils.EMPTY);
            noteXml.append(String.format(NOTE_XML_PROLOGUE_TEMPLATE, category.name().toLowerCase()));
            noteXml.append(template);
            noteXml.append(NOTE_XML_EPILOGUE);
        }
        
        try {
            o = AdapterUtils.latest(documentAdapterConfig).mapNotesAndWarningsXmlDocument(noteXml.toString());
        } catch (Exception e) {
            log.error("failed to parse note template {}", template, e);
        }
        return o;
    }  
}
