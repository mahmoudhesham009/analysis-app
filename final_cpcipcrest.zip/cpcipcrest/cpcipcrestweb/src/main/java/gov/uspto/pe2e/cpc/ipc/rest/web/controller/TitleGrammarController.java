package gov.uspto.pe2e.cpc.ipc.rest.web.controller;

import java.util.List;

import javax.annotation.Nonnull;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;
import org.springframework.ui.ModelMap;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import gov.uspto.pe2e.cpc.ipc.rest.commons.error.GrammarParseException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.RestUtils;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ValidationMessage;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_1.TitlePartTree;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.TitleService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.RequiredArgsConstructor;
import springfox.documentation.annotations.ApiIgnore;

/**
 * Class serves as title Grammar Controller
 * 
 * @author 2020
 * @date March 10, 2017
 * @version 1.7
 *
 */
@Component
@Api(value = "/titlegrammars", description = "Interact with title grammars")
@RestController
@RequestMapping(value = "/titlegrammars")
@RequiredArgsConstructor(onConstructor=@__(@Inject))
public class TitleGrammarController {

    private static final Logger log = LoggerFactory.getLogger(TitleGrammarController.class);

    @Nonnull
    private TitleService titleService;

    /**
     * Parses the title grammar text
     * 
     * @param titleGrammar
     * @param model
     * @param errors
     * @return TitlePartTree
     * @throws GrammarParseException
     */
    @ApiResponses({ @ApiResponse(code = 200, message = "Parse Successful"),
            @ApiResponse(code = 401, message = "Not Authenticated"),
            @ApiResponse(code = 403, message = "Does not have permission to perform import") })
    @ApiOperation("Accepts a multipart file upload to parse inport file, "
            + "create a proposal object and call the save() method")
    @RequestMapping(value = "/parse", method = RequestMethod.POST, consumes = "text/plain")
    @PreAuthorize("hasAuthority('PROPOSAL_MANAGER_ENABLED')")
    @ResponseBody
    public ResponseEntity<TitlePartTree> parse(@ApiParam("Grammar Text") @RequestBody String titleGrammar)
            throws GrammarParseException {
        log.debug("POSTED Title grammar\n             {} ", titleGrammar);
        TitlePartTree tpTree = titleService.fromGrammar(titleGrammar);
        return new ResponseEntity<>(tpTree, RestUtils.buildRestHttpHeaders(), HttpStatus.OK);
    }

    /**
     * Validates Title grammar
     * 
     * @param titleGrammar
     * @param model
     * @param errors
     * @return List<ValidationMessage>
     */
    @ApiResponses({ @ApiResponse(code = 202, message = "Parse Successful"),
            @ApiResponse(code = 401, message = "Not Authenticated"),
            @ApiResponse(code = 403, message = "Does not have permission to perform import") })
    @ApiOperation("Accepts a multipart file upload to parse inport file, "
            + "create a proposal object and call the save() method")
    @RequestMapping(value = "/validate", method = RequestMethod.POST, consumes = "text/plain")
    @PreAuthorize("hasAuthority('PROPOSAL_MANAGER_ENABLED')")
    @ResponseBody
    public ResponseEntity<List<ValidationMessage>> validate(@ApiParam("Grammar Text") @RequestBody String titleGrammar,
            @ApiIgnore @ModelAttribute ModelMap model, @ApiIgnore Errors errors) {
        log.debug("POSTED Title grammar\n             {} ", titleGrammar);
        List<ValidationMessage> messages = titleService.validateGrammar(titleGrammar);
        return new ResponseEntity<>(messages, RestUtils.buildRestHttpHeaders(), HttpStatus.OK);
    }

}
