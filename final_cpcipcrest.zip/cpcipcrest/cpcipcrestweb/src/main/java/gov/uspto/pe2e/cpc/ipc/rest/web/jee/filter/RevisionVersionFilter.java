package gov.uspto.pe2e.cpc.ipc.rest.web.jee.filter;

import java.io.IOException;
import java.text.ParseException;
import java.util.Date;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ClassificationScheme;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ClassificationSchemeRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.RestUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.web.service.PublicationService;

/**
 * This filter intercepts all requests and specifies the requested (or
 * default/latest) published scheme version along with XSD mappings as thread
 * local context variable for use by subsequent code. Uses include but are not
 * limited to the
 * 
 * @see gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.DocumentAdapter
 *      and the @see
 *      gov.uspto.pe2e.cpc.ipc.rest.entity.repository.SchemeHierarchyRepository
 * 
 * @author 2020
 * @date Oct 19, 2015
 * @version
 */
public class RevisionVersionFilter implements Filter {
    private static final Logger log = LoggerFactory.getLogger(RevisionVersionFilter.class);
   
    private ClassificationSchemeRepository classificationSchemeRepository;

    private PublicationService publicationService;

    /**
     * called when filter is shut down (context destroyed, reloaded, etc)
     */
    @Override
    public void destroy() {
     // Destroy method does nothing because it maintains no state in filter context
    }

    /**
     * This is the work part of this class and the real behind the curtain
     * stuff. steps: - Identify requested scheme publication via date in request
     * header - if none is provided, lookup latest - set publication date,
     * corresponding CPC XSD version and internally mapped XSD response based on
     * date as ThreadLocal Context - set http request to continue on as normal
     */
    @Override
    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) resp;
        try {
            SchemePublicationVersion version = getSchemePublicationVersion(request);
            SchemePublicationVersionContextHolder.setContext(version);
            chain.doFilter(request, response);
        } finally {
            SchemePublicationVersionContextHolder.clear();
        }

    }

    /**
     * This method is responsible for extracting the requested publication
     * version from the request. If the request has no requested publication
     * version (date), then look up the latest publication version that is in
     * "Published" status.
     * 
     * No matter what publication version/date is selected, resolve XSD version
     * and internal API version and bind them together using our model object
     * SchemePublicationVersion.
     * 
     * @param request
     * @return SchemePublicationVersion
     */
    public SchemePublicationVersion getSchemePublicationVersion(HttpServletRequest request) {
        ClassificationScheme classScheme = null;
        Date pubDate = null;
        String dateString = request.getHeader(RestUtils.SCHEME_PUBLICATION_DATE_HEADER);
        if (!StringUtils.isBlank(dateString)) {
            try {
                pubDate = DateUtils.parseDate(dateString, DateFormatUtils.ISO_DATE_FORMAT.getPattern());
            } catch (ParseException pe) {
                log.debug("ParseExeption encountered parsing [{}] Using latest", dateString, pe);
            }
        }
        if (pubDate == null) {
            log.debug("Pubdate is = ({}).  Assuming latest ", dateString);            
            classScheme = classificationSchemeRepository.findLatest();

        } else {
            classScheme = classificationSchemeRepository.findBySchemeVersionDate(pubDate);
            if (classScheme == null) {
                log.debug(
                        "Something terrible happened!.  It appears there is no "
                                + " classificationScheme record with the schemeVersion date {}",
                        new DateTime(pubDate).toString(DateFormatUtils.ISO_DATETIME_FORMAT.getPattern()));
                classScheme = classificationSchemeRepository.findLatest();
            }
        }
        return publicationService.mapSchemePublicationVersion(classScheme);
    }

    /**
     * Called once when the filter is configured as part of context startup. If
     * we allow any configuration of the filter, that needs to be handled here.
     */
    @Override
    public void init(FilterConfig arg0) throws ServletException {
      // This filter maintains no state in the filter context -  nothing to init
    }

    /**
     * Getter for classificationScheme
     * 
     * @return
     */
    public ClassificationSchemeRepository getClassificationSchemeRepository() {
        return classificationSchemeRepository;
    }

    /**
     * setter for classification scheme
     * 
     * @param classificationSchemeRepository
     */
    public void setClassificationSchemeRepository(ClassificationSchemeRepository classificationSchemeRepository) {
        this.classificationSchemeRepository = classificationSchemeRepository;
    }

    /**
     * @return the publicationService
     */
    public PublicationService getPublicationService() {
        return publicationService;
    }

    /**
     * @param publicationService the publicationService to set
     */
    public void setPublicationService(PublicationService publicationService) {
        this.publicationService = publicationService;
    }

   
}
