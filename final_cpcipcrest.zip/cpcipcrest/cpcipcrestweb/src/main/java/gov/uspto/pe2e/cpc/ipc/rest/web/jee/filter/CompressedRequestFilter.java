package gov.uspto.pe2e.cpc.ipc.rest.web.jee.filter;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.List;
import java.util.zip.GZIPInputStream;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ReadListener;
import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpHeaders;

import lombok.extern.slf4j.Slf4j;

/**
 * the original filter is final so the only way to incorporate this code is literally copy/paste
 * 
 * @author myoung3
 *
 */
@Slf4j
public final class CompressedRequestFilter implements Filter {

	private static final List<String> SUPPORTED_COMPRESSION_ENCODING = Arrays.asList("application/gzip", "gzip");
    

    @Override
    public void init(FilterConfig config) throws ServletException {
    }

    public void doFilter(ServletRequest request,
        ServletResponse response,
        FilterChain chain) throws IOException, ServletException {

        ServletRequest chainRequest = getRequest(request);
       

        if (chainRequest == null) {
            chainRequest = request;
        }

        chain.doFilter(chainRequest, response);
        
        

    }

    private ServletRequest getRequest(ServletRequest request) {
        if (!(request instanceof HttpServletRequest)) {
            log.error("Can't unzip non-HTTP request");
            return null;
        }

        HttpServletRequest httpRequest = (HttpServletRequest) request;
        String contentEncoding = httpRequest
            .getHeader(HttpHeaders.CONTENT_ENCODING);
        if (contentEncoding == null) {
            log.debug("Request is not compressed, so not decompressing");
            return null;
        }

        if (!SUPPORTED_COMPRESSION_ENCODING.contains(contentEncoding)) {
            log.warn("Content-Encoding supplied but {} is unsupported ", contentEncoding);
            return null;
        }
       // return new GzippedInputStreamWrapper(httpServletRequest);
        return new GZIPServletRequestWrapper(httpRequest);
    }

    public void destroy() {
        log.info("CompressedRequestFilter is being destroyed...");
    }


    public static class GZIPServletRequestWrapper extends HttpServletRequestWrapper{

        public GZIPServletRequestWrapper(HttpServletRequest request) {
            super(request);
        }

        @Override
        public ServletInputStream getInputStream() throws IOException {
            return new GZIPServletInputStream(super.getInputStream());
        }

        @Override
        public BufferedReader getReader() throws IOException {
            return new BufferedReader(new InputStreamReader(new GZIPServletInputStream(super.getInputStream())));
        }
    }

    public static class GZIPServletInputStream extends ServletInputStream{
        private InputStream input;

        public GZIPServletInputStream(InputStream input) throws IOException {
            this.input = new GZIPInputStream(input);
        }

        @Override
        public int read() throws IOException {
            return input.read();
        }

		@Override
		public boolean isFinished() {
			boolean ret = false;
			try {
				ret = input.available() == 0;
			} catch (Exception e) {
				log.error("Exception verifying availability of the inputStream", e);
			}
			return ret;
		}

		@Override
		public boolean isReady() {
			return true;
		}

		@Override
		public void setReadListener(ReadListener readListener) {

			
		}
    }
}
