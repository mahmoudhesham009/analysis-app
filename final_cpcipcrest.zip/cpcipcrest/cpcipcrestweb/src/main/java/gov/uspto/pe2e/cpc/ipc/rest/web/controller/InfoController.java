/**
 * 
 */
package gov.uspto.pe2e.cpc.ipc.rest.web.controller;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import gov.uspto.pe2e.cpc.ipc.rest.commons.util.RestUtils;
import io.swagger.annotations.Api;

/**
 * This controller provides 2 endpoints: 
 * 		1) App Info Json object containing version and build info 
 * 		2) A plaintext string response of the version string
 * 
 * @author 2020
 * @date Dec 9, 2015 3:45:34 PM
 * @version
 */
@Component
@Api(value = "/info", description = "Controller returns the version string of the application")
@Controller
@RequestMapping(value = "/info")
public class InfoController {
    
    private static final Logger log = LoggerFactory.getLogger(InfoController.class);
    
    /**
     * Get Manifest
     * 
     * @param request
     * @return Map
     */
    @ResponseBody
    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<Map> getManifest(HttpServletRequest request) {
        Map manifest = (Map) request.getServletContext().getAttribute("manifest");
        HttpStatus status = HttpStatus.OK;
        if (manifest == null || manifest.isEmpty()) {
            status = HttpStatus.NOT_FOUND;
        }
        return new ResponseEntity<>(manifest, RestUtils.buildRestHttpHeaders(), status);

    }
    
    /**
     * Get Version
     * 
     * @param request
     * @return String
     */
    @ResponseBody
    @RequestMapping(value = "/version", method = RequestMethod.GET, consumes = "text/plain")
    public String getVersion(HttpServletRequest request) {
        return ((Map) request.getServletContext().getAttribute("manifest")).get("app-version").toString();
    }
    
    /**
     * Get Duplicate class package info
     * 
     * @param request
     * @return Map
     * @throws IOException
     */
    @ResponseBody
    @RequestMapping(value = "/classes/duplicates", method = RequestMethod.GET)
    public ResponseEntity<Map<String, List<String>>> listDuplicateClassPackageInfo(HttpServletRequest request)
            throws IOException {
        log.info("Inside listDuplicateClassPackageInfo - Start");
        Map<String, List<String>> classes = new ConcurrentHashMap<>();
        // RE-ENABLE following block when we switch to JAVA11
//        Iterator<URL> iterator = Thread.currentThread().getContextClassLoader().
//                getResources("").asIterator();
//        while (iterator.hasNext()) {
//            URL url = iterator.next();
//            File f = new File(url.getFile());
//            if (f.exists() && f.isFile()) {
//                populateDuplicateClassMap(classes, url);
//            }
//        }
        Iterator<Entry<String, List<String>>> i = classes.entrySet().iterator();
        while (i.hasNext()) {
            Entry<String, List<String>> e = i.next();
            if (e.getValue().size() < 2) {
                classes.remove(e.getKey());
            }
        }
        HttpStatus status = HttpStatus.OK;
        log.info("Inside listDuplicateClassPackageInfo - End");
        return new ResponseEntity<>(classes, status);
    }
    
    /**
     * Populate Duplicate class package info
     * 
     * @param classes
     * @param url
     * @return 
     * @throws IOException
     */
    private void populateDuplicateClassMap(Map<String, List<String>> classes, URL url) throws IOException {

        try (JarFile jarFile = new JarFile(url.getFile())) {
            Enumeration<JarEntry> e = jarFile.entries();
            while (e.hasMoreElements()) {
                JarEntry je = e.nextElement();
                if (!je.isDirectory() && je.getName().endsWith(".class")) {
                    String name = je.getName().replaceAll("/", ".");
                    List<String> found = classes.get(name);
                    if (found == null) {
                        found = new ArrayList<>();
                        classes.put(name, found);
                    }
                    found.add(new File(url.getPath()).getName());
                }
            }
        }
    }
}
