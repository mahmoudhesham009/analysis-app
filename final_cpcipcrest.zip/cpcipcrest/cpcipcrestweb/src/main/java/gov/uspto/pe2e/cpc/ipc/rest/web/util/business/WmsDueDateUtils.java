package gov.uspto.pe2e.cpc.ipc.rest.web.util.business;

import java.math.BigInteger;
import java.util.Date;

import org.joda.time.DateTime;

/**
 * Utility for Activiti - Workflow management system
 * @author 2020llc
 *
 */
public final class WmsDueDateUtils {
	
	// DO NOT IMPLEMENT PRIVATE Constructor (it breaks ability to get code coverage up)
	
	/**
	 * Returns Max value of integer, if there are not due date defined 
	 * @return int Number of days expected the entire process to take
	 */
	public static int calculateExpectedDays() {
		return Integer.MAX_VALUE;
	}
	
	/**
	 * Returns Zero if the actual days
	 * @return int
	 */
	public static int calculateActualDays() {
		return BigInteger.ZERO.intValue();
	}
	
	/**
	 * Utility to calculate end date based on start date
	 * @param startDate
	 * @param wmsNode
	 * @return Date
	 */
	public static Date calculateEndDate(Date startDate, Object wmsNode) {
		int expectedDays = 0;
		return new DateTime(startDate).plusDays(expectedDays).toDate();
		
	}

}
