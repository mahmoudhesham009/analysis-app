package gov.uspto.pe2e.cpc.ipc.rest.web.controller;

import java.util.List;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.validation.Valid;
import javax.validation.constraints.Null;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import gov.uspto.pe2e.cpc.ipc.rest.commons.util.RestUtils;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ComponentCategory;
import gov.uspto.pe2e.cpc.ipc.rest.contract.templates.v1_0.ComponentTemplate;
import gov.uspto.pe2e.cpc.ipc.rest.web.service.TemplateService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;

/**
 * General template controller that allows for interacting with Templates as a
 * collection Types of templates supported: NoteTemplate
 * 
 * @author 2020
 * @date May 3, 2017
 * @version 1.8
 */
@Component
@Api(value = "/templates", description = "Controller for looking up IPC Concordance values")
@Controller
@RequestMapping(value = "/templates")
@RequiredArgsConstructor(onConstructor=@__(@Inject))
public class TemplateController {

    @Nonnull
    private TemplateService templateService;

    /**
     * Gets a list of note templates available for a given note category
     * (WARNING or NOTE)
     * 
     * @param category
     * @param boolean
     * @return List<NoteTemplate>
     * @since May 3, 2017
     */
    @ResponseBody
    @RequestMapping(value = "/notes", method = RequestMethod.GET)
    @PreAuthorize("hasAuthority('PROPOSAL_MANAGER_ENABLED')")
    public ResponseEntity<List<ComponentTemplate>> listAvailableNoteTemplatesByCategory(
            @ApiParam("NoteWarningCategoryType") 
            @RequestParam(value = "category", required = false) @Nullable ComponentCategory category,
            @ApiParam("Include Templates") 
            @Valid @Null 
            @RequestParam(value = "includeTemplates", required = false, defaultValue = "false") boolean includeTemplates) {
        HttpStatus status = HttpStatus.OK;
        HttpHeaders headers = RestUtils.buildRestHttpHeaders();
        List<ComponentTemplate> templates = templateService.findAvailableNoteTemplatesByCategory(category, includeTemplates);
        if (CollectionUtils.isEmpty(templates)) {
            status = HttpStatus.NO_CONTENT;
        }
        return new ResponseEntity<>(templates, headers, status);
    }

    /**
     * Gets a single note template by name (shortDescription) and category
     * 
     * @param name
     * @param category
     * @return NoteTemplate
     * @since May 3, 2017
     */
    @ResponseBody
    @RequestMapping(value = "/by/category/name", method = RequestMethod.GET, params = { "name", "category" })
    @PreAuthorize("hasAuthority('PROPOSAL_MANAGER_ENABLED')")
    public ResponseEntity<ComponentTemplate> getNoteTemplatesByShortDescriptionAndCategory(@RequestParam("name") String name,
            @RequestParam("category") ComponentCategory category) {
        HttpHeaders headers = RestUtils.buildRestHttpHeaders();
        ComponentTemplate template = templateService.findAvailableTemplateByNameAndType(name, category);
        return new ResponseEntity<>(template, headers, HttpStatus.OK);
    }
}
