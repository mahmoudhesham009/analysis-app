package org.activiti.test;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;




@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes=WmsBypassTest.class)
public class WmsBypassTest {
    private static final Logger log =  LoggerFactory.getLogger(WmsBypassTest.class);
    
    
    @Before
	public void setUp() throws Exception {
    	log.debug("Nothing to test , bypassing all cases");
	}


    @Test
    public void testDummy() throws Exception {
    	log.debug("Nothing to test , bypassing all cases");
    	Assert.assertTrue(true);
    }
    

 

}
