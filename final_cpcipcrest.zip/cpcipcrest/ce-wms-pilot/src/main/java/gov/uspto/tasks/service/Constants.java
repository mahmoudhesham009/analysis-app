package gov.uspto.tasks.service;
//

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

//public enum Constants {
//	US_APPROVALS,
//	EPO_APPROVALS,
//	US,
//	EP
//	
//}

public class Constants {

	public static final String SUB_PHASE_US_APPROVALS = "US_APPROVALS";
	public static final String SUB_PHASE_EPO_APPROVALS = "EPO_APPROVALS";

	public static final String OFFICE_US = "US";
	public static final String OFFICE_EP = "EP";

	// Process instance variables
	public static final String VAR_PI_RAPPORTEUR_OFFICE = "RAPPORTEUR_OFFICE";
	public static final String VAR_PI_INITIATOR = "initiator";
	public static final String VAR_PI_TASK_START_DATE = "taskStartDate";
	public static final String VAR_PI_TASK_DUE_DATE = "taskDueDate";
	public static final String VAR_PI_TARGET_OFFICE = "targetOffice";
	public static final String VAR_PI_NR_TASK_VARIABLE = "nrTaskVariable";
	public static final String VAR_PI_IS_ROTASK = "isROTask";
	public static final String VAR_PI_PHASE = "PHASE";
	public static final String VAR_PI_SUB_PHASE = "SUB_PHASE";
	public static final String VAR_PI_ACTOR = "actor";
	public static final String VAR_PI_PROPOSAL_ID = "PROPOSAL_ID";
	public static final String VAR_PI_PREVIOUS_TASK_KEY = "previousTaskKey";
	public static final String VAR_PI_PROJECT_TYPE = "projectType";
	public static final String VAR_PI_PROJECT_SOURCE = "projectSource";
	public static final String VAR_PI_PHASE_ENTRY_POINT = "PHASE_ENTRY_POINT";
	public static final String VAR_PI_PROPOSAL_ALIAS = "PROPOSAL_ALIAS";

	public static final List<String> PID_VARS = new ArrayList<String>();
	static {
		PID_VARS.add(VAR_PI_RAPPORTEUR_OFFICE);
		PID_VARS.add(VAR_PI_INITIATOR);
		PID_VARS.add(VAR_PI_TASK_START_DATE);
		PID_VARS.add(VAR_PI_TASK_DUE_DATE);
		PID_VARS.add(VAR_PI_TARGET_OFFICE);
		PID_VARS.add(VAR_PI_NR_TASK_VARIABLE);
		PID_VARS.add(VAR_PI_IS_ROTASK);
		PID_VARS.add(VAR_PI_PHASE);
		PID_VARS.add(VAR_PI_SUB_PHASE);
		PID_VARS.add(VAR_PI_ACTOR);
		PID_VARS.add(VAR_PI_PROPOSAL_ID);
		PID_VARS.add(VAR_PI_PREVIOUS_TASK_KEY);
		PID_VARS.add(VAR_PI_PROJECT_TYPE);
		PID_VARS.add(VAR_PI_PROJECT_SOURCE);

	};

	// Task Variables
	public static final String VAR_TASK_OFFICE = "OFFICE";
	public static final String VAR_TASK_EXPECTED_DAYS = "EXPECTED_DAYS";
	public static final String VAR_TASK_TASK_PHASE = "TASK_PHASE";
	public static final String VAR_TASK_STARTED_BY = "STARTED_BY";
	public static final String VAR_TASK_TASK_NUMBER = "TASK_NUMBER";

	public static final String VAR_TASK_ROLE = "ROLE";
	public static final String VAR_TASK_PROJECT_START_DATE = "projectStartDate";

	public static List<String> FINAL_TASK_DEFKEY = new ArrayList<String>();
	static {
		FINAL_TASK_DEFKEY.add("COT01");
		FINAL_TASK_DEFKEY.add("EC_COT01");
		FINAL_TASK_DEFKEY.add("IPC_COT01");
		FINAL_TASK_DEFKEY.add("BH_COT01");

	}

	public static final String FORM_VAR_RAPPORTEUR_OFFICE = "rapporteurOffice_PD";

//	public static final String MIGRATE_DRAFT_CUTTOFF_TASK = "BRT07";

	/*
	 * List of Requesting Office Task Keys
	 */
	public static final String[] RO_TASKS = { "IRT01", "IRT02", "IRT03", "IRT04", "IRT05", "IRT06", "IRT07", "IRT08",
			"PBT01", "PBT03", "PBT04", "PBT06", "BRT01", "BRT02", "BRT04",/* "BRT06", *//* BRT06->JB TASK */"BRT07",
			"BAT01", "BAT02", "BAT04", "BAT06", "BAT07", "BAT08", "BAT09", "BAT13", "BAT14", "BAT16", /*"BAT18",*/

			/*"PIT03",*/ /*"PIT05", */"PIT07", "RET01", "RET02", "RET03", "RET04", "RET05", // ALL RET's are reclassification
																					// team IS RO
			"CLT01", "CLT02", "CLT03", "CLT04", // ALL CLT's are reclassification team IS RO
			"FIT01", "FIT02", "FIT04"
//			"FIT06"
			, "PFT03", "PFT05", "PFT07",
			// DF-Distribution Phase (Final) – DFTxx

			// EC Tasks
			"EC_IRT01", "EC_IRT02", "EC_IRT03", "EC_BAT01", "EC_BAT02", "EC_COT01",

			// IPC Tasks
			"IPC_IRT01", "IPC_IRT02", "IPC_IRT03", "IPC_BAT01", "IPC_BAT02", "IPC_BAT04", "IPC_COT01",

			// BH Tasks
			"BH_IRT01", "BH_IRT02", "BH_IRT03", "BH_BAT01", "BH_BAT02", "BH_BAT04", "BH_COT01"

	};

	/*
	 * List of Non-Requesting Office Task Keys
	 */
	public static final String[] NR_TASKS = { "PBT02", "PBT05", "BRT03", "BRT05", "BAT03", "BAT05", "BAT10", "BAT11",
			"BAT12", "BAT15", "BAT17", "FIT03", "FIT05",
//			"FIT06",
//
//			// EC Tasks
			"EC_BAT03", "EC_COT01",

			// IPC Tasks
			"IPC_BAT03",

			// BH Tasks
			"BH_BAT03" };
	/*
	 * List of Publication Office Task Keys
	 */
	public static final String[] PUB_TASKS = { "PIT01", "PIT02", "PIT04", "PIT06", "PIT08", "PIT09", "DIT01", "PFT01",
			"PFT02", "PFT04", "PFT06", "PFT08", "PFT09", "DFT01",
			// "COT01",

			// EC TASKS
			"EC_PUT01", "EC_PUT02", "EC_PUT03", "EC_DST01",
			// "EC_COT01"
	};

	/*
	 * These are publication phase tasks but should be treated as non pub tasks
	 */
	public static final String[] NON_PUB_TASKS = { /*"PIT03", "PIT05",*/ "PIT07" };

	/*
	 * These tasks need to target both NR & RO groups
	 */
	public static final List<String> RONR_TASKS = new ArrayList<String>();
	static {
		RONR_TASKS.add("EC_BAT01");
		RONR_TASKS.add("FIT06");
		RONR_TASKS.add("IPC_BAT01");
		RONR_TASKS.add("IPC_BAT04");
		RONR_TASKS.add("IPC_BAT05");
		RONR_TASKS.add("IPC_COT01");
		RONR_TASKS.add("BH_BAT01");
		RONR_TASKS.add("BH_BAT04");
		RONR_TASKS.add("BH_BAT05");
		RONR_TASKS.add("BH_COT01");
		RONR_TASKS.add("COT01");
		RONR_TASKS.add("PBT07");
		RONR_TASKS.add("BRT06");
		RONR_TASKS.add("BAT18");
		RONR_TASKS.add("PIT03");
		RONR_TASKS.add("PIT05");
		RONR_TASKS.add("PIT07");
		RONR_TASKS.add("PFT03");
		RONR_TASKS.add("PFT05");
		RONR_TASKS.add("PFT07");

	}

	public static final Map<String, String> phaseMap = new ConcurrentHashMap<>(3);
	static {
		phaseMap.put("IR", "I"); // Internal Request
		phaseMap.put("PB", "E"); // PreBilateral
		phaseMap.put("BR", "Q"); // Bilateral Request
		phaseMap.put("BA", "A"); // Bilateral Active
		phaseMap.put("PI", "PI"); // Publication Initial

		phaseMap.put("DI", "DI"); // Distribution Initial
		phaseMap.put("RE", "R"); // Reclass
		phaseMap.put("CL", "U"); // Cleanup

		phaseMap.put("FI", "F"); // Finalization
		phaseMap.put("PF", "PF"); // Publication Final
		phaseMap.put("DF", "DF"); // Distribution Final
		phaseMap.put("CO", "C"); // Completed

		// EC
		// Last minute changes not upto conventions followed
		// TODO update EC PUT AND DST tasks and task forms with standard names
		phaseMap.put("DS", "DI"); // Distribution
		phaseMap.put("PU", "PI"); // Publication
	}
	public static final Map<String, String> esclationTaskVars = new ConcurrentHashMap<>(3);
	static {
		esclationTaskVars.put("BRT05", "wfFormBRT05CheckJBescalationNeeded");
		esclationTaskVars.put("PIT02", "wfFormPIT02CheckPCreviewNOTRequired_KEEP");
		esclationTaskVars.put("PIT04", "wfFormPIT04CheckPCreviewNOTRequired");
		esclationTaskVars.put("PFT02", "wfFormPFT02CheckPCreviewNOTRequired");
		esclationTaskVars.put("PFT04", "wfFormPFT04CheckPCreviewNOTRequired");
		esclationTaskVars.put("BAT05", "wfFormBAT05CheckTWLReviewNOTRequired_KEEP");
		esclationTaskVars.put("BH_BAT04", "wfFormBHBAT04CreateRevisionProjectsNotRequired");
		esclationTaskVars.put("IPC_BAT04", "wfFormIPCBAT04CreateRevisionProjectsNotRequired");

	}
	public static final String[] REMOVE_VARS = esclationTaskVars.values().toArray(new String[0]);

//	1.RP-Revision Project
//	2.MP-Maintenance Project 
//	3.DP-Definition Project 
//	4.QF-Quick Fixes
//	5.HP-Harmonization Project
//	6.HX- Cross Technology
	public static final List<String> PROJECT_TYPES = new ArrayList<String>();
	static {
		// CPC_REVISION
		PROJECT_TYPES.add("RP");
		PROJECT_TYPES.add("MP");
		PROJECT_TYPES.add("DP");

		// EC
		PROJECT_TYPES.add("EC");

		// IPC
		PROJECT_TYPES.add("HP");
		PROJECT_TYPES.add("HX");
		PROJECT_TYPES.add("IA");
		PROJECT_TYPES.add("IC");
		PROJECT_TYPES.add("ID");
		PROJECT_TYPES.add("IF");
		PROJECT_TYPES.add("IM");
		PROJECT_TYPES.add("IZ");
		PROJECT_TYPES.add("IQ");
		PROJECT_TYPES.add("IV");
		PROJECT_TYPES.add("IW");
		PROJECT_TYPES.add("IE");
		PROJECT_TYPES.add("IJ");
		PROJECT_TYPES.add("IP");
		PROJECT_TYPES.add("IF");
		PROJECT_TYPES.add("IU");

	};

	public static void main(String[] args) {
		String s = "wfFormBRT05CheckJBescalationNeeded";
		System.out.println(esclationTaskVars.containsValue(s));
	}
}