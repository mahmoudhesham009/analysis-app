package gov.uspto.tasks.service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.lang3.CharEncoding;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

public class Utils {
	private static final Logger log = LoggerFactory.getLogger(Utils.class);
	
	public static String toJson(Object o) throws JsonGenerationException, JsonMappingException, IOException {
		String json = null;
		try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
			ObjectMapper mapper = new ObjectMapper();
			mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

			mapper.writer().writeValue(baos, o);
			json = baos.toString(CharEncoding.UTF_8);
		}
		return json;
	}

	public static String toJsonOrStacktrace(Object o) {
		String json = null;
		try {
			json = toJson(o);
		} catch (Exception e) {
			json = ExceptionUtils.getStackTrace(e);
		}
		return json;
	}

	public static <T> T fromJson(InputStream is, Class<T> type) {
		T obj = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			obj = mapper.reader(type).readValue(is);
		} catch (Exception e) {
			log.warn("Exception parsing stream ", e);
		}
		return obj;
	}
}
