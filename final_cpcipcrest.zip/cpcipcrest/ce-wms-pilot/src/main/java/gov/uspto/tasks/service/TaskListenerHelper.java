package gov.uspto.tasks.service;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.activiti.engine.IdentityService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.DelegateTask;
import org.activiti.engine.impl.context.Context;
import org.activiti.engine.task.IdentityLink;
import org.activiti.engine.task.IdentityLinkType;
import org.activiti.engine.task.Task;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.activiti.domain.idm.Group;
import com.activiti.service.api.GroupService;
import com.activiti.service.api.UserService;

import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalStateTaskRepository;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.AssignmentGroup;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.OfficeContactType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ProposalPhase;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ProposalStateType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.ProposalSubphase;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.StandardIpOfficeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.WMSVariableKey;
import gov.uspto.pe2e.cpc.ipc.rest.contract.stateflow.v1_0.TaskStateDetails;
import gov.uspto.pe2e.cpc.ipc.rest.contract.stateflow.v1_0.UserGroupDetails;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalService;
import gov.uspto.pe2e.cpc.ipc.rest.wms.service.WmsCommonService;

/**
 * This is a helper class for task/execution listeners, to provide common
 * methods for the listeners.
 * 
 * @author 2020LLC
 * @release 1.13
 *
 */
public class TaskListenerHelper {
	private static Logger log = LoggerFactory.getLogger(TaskListenerHelper.class);
	@Autowired
	private ChangeProposalStateTaskRepository changeProposalStateTaskRepository;
//	// Technologies
//	public static final Map<String, String> IPC_TECH = MapUtils.putAll(new HashMap<String, String>(),
//			new String[][] { { "Chemistry", "C" }, { "Electricity and Physics", "E" }, { "Mechanics", "M" },
//					{ "Technology-Independent", "T" } });
//
//	public static final Map<String, String> US_TECH = MapUtils.putAll(new HashMap<String, String>(),
//			new String[][] { { "Telecom/Comp", "T_C" }, { "Mechanical", "ME" }, { "Biotech/Organic Chemistry", "B_OC" },
//					{ "Chemistry/Material Science", "C_MS" }, { "Electricity/Optics", "E_O" },
//					{ "Technology Independent", "T_I" } });
//
//	public static final Map<String, String> EPO_TECH = MapUtils.putAll(new HashMap<String, String>(),
//			new String[][] { { "HBC", "HBC" }, { "ICT", "ICT" }, { "M&M", "MM" }, { "Technology Independent", "TI" } });
//
//	

	/*
	 * To get email address of the activiti user by numeric user id.
	 * 
	 * @param userService
	 * 
	 * @param uid
	 * 
	 * @return String
	 */
	public static String getEmailOfUser(UserService userService, IdentityService identityService, String uid) {
		if (uid == null)
			return null;
		else
			uid = uid.trim();

		if (StringUtils.isNumeric(uid)) {
			return userService == null ? identityService.createUserQuery().userId(uid).singleResult().getEmail()
					: userService.getUser(Long.valueOf(uid)).getEmail();
		} else
			return uid;
	}

	/*
	 * To get process name by execution ID.
	 * 
	 * @param runtimeService
	 * 
	 * @param exe
	 * 
	 * @return String
	 */
	public static String getProcessName(RuntimeService runtimeService, DelegateExecution exe) {
		// if we can get the proposal_id set in variable, then get it. Otherwise will
		// return bussness key
		if (runtimeService.getVariable(exe.getId(), WMSVariableKey.PROPOSAL_ID.name()) != null)
			return (String) runtimeService.getVariable(exe.getId(), WMSVariableKey.PROPOSAL_ID.name());
		else
			return exe.getProcessBusinessKey();
	}

	/*
	 * To get process name by task.
	 * 
	 * @param taskService
	 * 
	 * @param task
	 * 
	 * @return String
	 */
	public static String getProcessName(TaskService taskService, DelegateTask task) {
		// if we can get the proposal_id set in variable, then get it. Otherwise will
		// return bussness key
		if (taskService.getVariable(task.getId(), WMSVariableKey.PROPOSAL_ID.name()) != null)
			return (String) taskService.getVariable(task.getId(), WMSVariableKey.PROPOSAL_ID.name());
		else
			return task.getExecution().getProcessBusinessKey();
	}

	/*
	 * Get numeric ID of Activiti user by email
	 * 
	 * @param userService
	 * 
	 * @param email
	 * 
	 * @return String
	 */
	public static String findActiveUserIdByEmail(UserService userService, IdentityService identityService,
			String email) {
		if (StringUtils.isBlank(email))
			return null;
		else if (StringUtils.isNumeric(email))
			return email;
		else {
			return userService == null ? identityService.createUserQuery().userEmail(email).singleResult().getId()
					: userService.findActiveUserByEmail(email).getId().toString();
		}
	}

	/*
	 * Get Activiti Group name by numeric ID of the group
	 * 
	 * @param identityService
	 * 
	 * 
	 * @param id
	 * 
	 * @return String
	 */
	public static String getGroupNameById(IdentityService identityService, String id) {
		return identityService.createGroupQuery().groupId(id).singleResult().getName();
	}

	/*
	 * Get Activiti Group numeric ID by name of the group
	 * 
	 * @param identityService
	 * 
	 * @param id
	 * 
	 * @return String
	 */
	public static String getGroupIdByName(IdentityService identityService, String groupName) {
		return identityService.createGroupQuery().groupName(groupName).singleResult().getId();
	}

	/*
	 * Get ProposalSubphase or null if not valid
	 * 
	 * @param subPhase
	 * 
	 * @return ProposalSubphase
	 */
	public static ProposalSubphase getProposalSubphase(String subPhase) {

		if (EnumUtils.isValidEnum(ProposalSubphase.class, subPhase))
			return ProposalSubphase.fromValue(subPhase);
		else
			return null;
	}

	public static String dateToString(Date date) {
		if (date == null) {
			return null;
		}
		return DateFormatUtils.format(date, DateFormatUtils.ISO_DATE_FORMAT.getPattern());
	}
	/*
	 * To update the proposal state during the workflow process.
	 * 
	 * @param task
	 * 
	 * @param proposalService
	 * 
	 * @param taskService
	 * 
	 * @param userService
	 * 
	 * @param groupService
	 * 
	 * @param identityService
	 * 
	 * @return void
	 */

	public static void updateProposalState(DelegateTask task, ProposalService proposalService, TaskService taskService,
			UserService userService, GroupService groupService, IdentityService identityService) {
		if (Constants.FINAL_TASK_DEFKEY.contains(task.getTaskDefinitionKey())) {
			updateProposalStateWithStatus(task, proposalService, taskService, userService, groupService,
					identityService, ProposalStateType.COMPLETED);
		} else {
			updateProposalStateWithStatus(task, proposalService, taskService, userService, groupService,
					identityService, ProposalStateType.ACTIVE);
		}
	}

	public static void updateProposalStateWithStatus(DelegateTask task, ProposalService proposalService,
			TaskService taskService, UserService userService, GroupService groupService,
			IdentityService identityService, ProposalStateType status) {

		// change state of the proposal and save to CPC database other than activiti DB.
		if (taskService == null)
			taskService = Context.getProcessEngineConfiguration().getTaskService();
		UUID projectUUID = UUID.fromString(TaskListenerHelper.getProcessName(taskService, task));

		String phase = (String) taskService.getVariable(task.getId(), Constants.VAR_PI_PHASE);
		String subphase = (String) taskService.getVariable(task.getId(), Constants.VAR_PI_SUB_PHASE);
//		Date projectStartDate = (Date) taskService.getVariable(task.getId(), "projectStartDate");
		String assignee = TaskListenerHelper.getEmailOfUser(userService, identityService, task.getAssignee());

		Date projectStartDate;
		if (taskService.getVariable(task.getId(), "projectStartDate") == null) {
			projectStartDate = task.getCreateTime();
		} else {
			String strProjectStartDate = (String) taskService.getVariable(task.getId(),
					Constants.VAR_TASK_PROJECT_START_DATE);
			// TODO delete after testing
//			projectStartDate = fromISODate(strProjectStartDate);
			try {
				projectStartDate = DateUtils.parseDate(strProjectStartDate,
						DateFormatUtils.ISO_DATETIME_TIME_ZONE_FORMAT.getPattern());
			} catch (ParseException e) {
				log.error("Error parsing date:{} defaulting to task creating date ", strProjectStartDate);
				projectStartDate = task.getCreateTime();
			}
			log.debug("Task ProjectStart Date vars->ISO-> {} , DateObject->{} ", strProjectStartDate, projectStartDate);
		}
		List<TaskStateDetails> listDetails = new ArrayList<TaskStateDetails>();
		List<Task> tasks = taskService.createTaskQuery().processInstanceId(task.getProcessInstanceId()).list();
		// only valid for parallel tasks
		// String taskRoleNew = "";
		for (Task t : tasks) {
			// ignore current one since it's going to be completed
			if (t.getId().equals(task.getId()))
				continue;

			TaskStateDetails td = new TaskStateDetails();
			String email = TaskListenerHelper.getEmailOfUser(userService, identityService, t.getAssignee());
			log.info("Set task assignee(CM1): {}->{}", t.getAssignee(), email);
			td.setAssignee(email);
			if (t.getAssignee() == null) {
				List<IdentityLink> links = taskService.getIdentityLinksForTask(t.getId());

				for (IdentityLink link : links) {
					if (IdentityLinkType.CANDIDATE.equals(link.getType())) {

						AssignmentGroup assigneeGroup = new AssignmentGroup();
						String groupName = (groupService == null ? getGroupNameById(identityService, link.getGroupId())
								: groupService.getGroup(Long.parseLong(link.getGroupId())).getName());
						// taskRoleNew += groupName.replace("_", ":") + ",";

						// group name reads like: US_COORDINATOR
						if (groupName.contains("_")) {
							String officeName = groupName.substring(0, groupName.indexOf("_"));
							if (EnumUtils.isValidEnum(StandardIpOfficeCode.class, officeName)) {
								assigneeGroup.getOffices().add(StandardIpOfficeCode.fromValue(officeName));
								String roleName = groupName.substring(officeName.length() + 1);
								if (EnumUtils.isValidEnum(OfficeContactType.class, roleName))
									assigneeGroup.setRole(OfficeContactType.fromValue(roleName));
							} else {
								// for groups reads like: JOINT_BOARD, without starting office
								if (EnumUtils.isValidEnum(OfficeContactType.class, groupName))
									assigneeGroup.setRole(OfficeContactType.fromValue(groupName));
							}
						} // for groups read like GROUP1, GROUP2 without starting office(or without _)
						else if (EnumUtils.isValidEnum(OfficeContactType.class, groupName))
							assigneeGroup.setRole(OfficeContactType.fromValue(groupName));

						td.getAssigneeCandidateGroups().add(assigneeGroup);
					}
				}
			}

			td.setDueTs(t.getDueDate());

			td.setEstimatedDays((Integer) taskService.getVariableLocal(t.getId(), Constants.VAR_TASK_EXPECTED_DAYS));
			td.setPhase(ProposalPhase.fromValue(phase));
			td.setStartTs(t.getCreateTime());
			td.setSubphase(TaskListenerHelper.getProposalSubphase(subphase));
			td.setTaskId(t.getId());
			td.setTaskName(t.getName());
			td.setTaskedOffice(StandardIpOfficeCode
					.fromValue((String) taskService.getVariableLocal(t.getId(), Constants.VAR_TASK_OFFICE)));
			td.setTaskedRole((String) taskService.getVariableLocal(t.getId(), Constants.VAR_TASK_ROLE));
			// td.setTaskedRole(taskRoleNew);
			// taskRoleNew = "";
			listDetails.add(td);
		}

		TaskStateDetails[] arrayTasks = new TaskStateDetails[listDetails.size()];
		arrayTasks = listDetails.toArray(arrayTasks);

		if (proposalService != null)
			proposalService.updateProposalStatus(projectUUID, task.getProcessInstanceId(),
					task.getProcessDefinitionId(), projectStartDate, new Date(), ProposalPhase.fromValue(phase),
					TaskListenerHelper.getProposalSubphase(subphase), status, assignee, null, arrayTasks);

	}

	/*
	 * Convert the email of user to assignable numeric user ID
	 * 
	 * @param userService
	 * 
	 * @param task
	 * 
	 * @return void
	 */
//	public static void convertUserToAssignable(UserService userService, IdentityService identityService,
//			TaskService taskService, DelegateTask task) {
//		String[] USER_VARIABLES = { "usEB", "usPC", "epEB", "epPC", "primaryEB", "primaryPC", "secondaryEB",
//				"secondaryPC" };
//		for (int i = 0; i < USER_VARIABLES.length; i++) {
//			if (taskService.getVariable(task.getId(), USER_VARIABLES[i]) == null) {
//				continue;
//			}
//			Object obj = taskService.getVariable(task.getId(), USER_VARIABLES[i]);
//			String userEmail = null;
//			if (Map.class.isAssignableFrom(obj.getClass())) {
//				Map map = (Map) taskService.getVariable(task.getId(), USER_VARIABLES[i]);
//
//				if (map.get("id") != null) {
//					userEmail = map.get("id").toString();
//				} else if (map.get("name") != null) {
//					userEmail = map.get("name").toString();
//				}
//			} else
//				userEmail = taskService.getVariable(task.getId(), USER_VARIABLES[i]).toString();
//
//			String userName = userEmail;
//			String userID = findActiveUserIdByEmail(userService, identityService, userName);
//			if (userID != null) {
//				taskService.setVariable(task.getId(), USER_VARIABLES[i], userID);
//			}
//		}
//
//	}

	/*
	 * Calculate the task End date
	 */
	public static Date getTaskEndDate(Date taskStartDate, int duration, WmsCommonService wmsCommonService) {
		// If LocalDate is used , have to deal the time.

//		List<StandardHolidays> holidays = wmsCommonService.getListOfHolidays();

		// taskStartDate can't be null
		if (duration < 1)
			return taskStartDate;
//
//		
//		DateTimeComparator dtc = DateTimeComparator.getDateOnlyInstance();
//		Calendar endCal = Calendar.getInstance();
//		endCal.setTime(taskStartDate);
//		int count = 0;
//		
//		log.debug("Calculating Working Days :");
//		String tmpStr = "";
//		while (count < duration) {
//			endCal.add(Calendar.DAY_OF_MONTH, 1);
//			
//			boolean isHoliday = false;
//			for (StandardHolidays stdHoliday : holidays) {
//				if (dtc.compare(stdHoliday.getHolidayDate(), endCal.getTime()) == 0) {
//					log.debug("Todays is Holiday :H:" + stdHoliday.getHolidayDate()  + " :T: " + endCal.getTime() + "-->" + stdHoliday.getHolidayName());
//					log.debug("Todays is Holiday :H: {}  :T: {} -->{}" , stdHoliday.getHolidayDate(), endCal.getTime() , stdHoliday.getHolidayName() );
//					isHoliday= true;
//					break;
//				}
//			}
//			
//			//Check if the current day is weekend or holiday
//			
//			if (!(endCal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY
//					|| endCal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY
//					|| isHoliday)) {
//				count++;
//				
////				log.debug("Todays is not sunday or saturday or Holiday :" + endCal.getTime());
//				tmpStr += "->"+count;
//				
//			}
//
//		}
//		log.debug("Day Count : " + tmpStr);

		DateTime endCal = new DateTime(taskStartDate.getTime()).plusDays(duration);
		return endCal.toDate();
	}

	/*
	 * Remove the initial place holder temp groups assigned
	 * 
	 * @param task
	 * 
	 * @return
	 * 
	 */
	public static void removeInitialTempGroups(DelegateTask task) {
		// Remove group temp assigned during the design
		Set<IdentityLink> iLinks = task.getCandidates();
		for (IdentityLink identityLink : iLinks) {
			log.debug("ID Link Type : " + identityLink.getType());
			task.deleteGroupIdentityLink(identityLink.getGroupId(), identityLink.getType());
		}
	}

	/*
	 * 
	 * @param task
	 * 
	 * @return phasePrefix
	 * 
	 */
	public static String getPhaseCode(DelegateTask task) {
		// This should never return null;
		String key = task.getTaskDefinitionKey();
		String taskPrefix = null;

		if (key.contains("_")) {

			int index = key.indexOf("_");
			taskPrefix = key.substring(index + 1, index + 3);

		} else {

			taskPrefix = key.substring(0, 2);

		}
		String phaseCd = Constants.phaseMap.get(taskPrefix);
		log.debug(" Task Key {} ----- TaskPrefix  {} ---- phaseCd {} ", key, taskPrefix, phaseCd);
		return phaseCd;

	}

//	public static void main(String args[]) {
//		String s = getPhaseCode(null);
//		System.out.println(s);
//	}
	/*
	 * Extract the targeted groups for the task based on the targetOffice
	 * 
	 * Get the task groups from Services.
	 * 
	 * @param assignedGroupsList
	 * 
	 * @param groupService
	 * 
	 * @param tenantId
	 * 
	 * @return candidateGroupList
	 */
	public static List<String> getTaskGroups(List<UserGroupDetails> assginedGroupsList, String targetOffice,
			GroupService groupService, Long tenantId, String taskDefKey) {

		List<String> candidateGroupList = new ArrayList<>();

		if (assginedGroupsList != null && assginedGroupsList.size() > 0) {

			for (UserGroupDetails userGroupDetails : assginedGroupsList) {
				List<String> rolesList = userGroupDetails.getRoles();

				for (String roleName : rolesList) {

					String groupName = null;
					if (Constants.RONR_TASKS.contains(taskDefKey)) {

						groupName = userGroupDetails.getOffice() + "_" + roleName;

					} else if (targetOffice.equalsIgnoreCase(userGroupDetails.getOffice())) {

						groupName = userGroupDetails.getOffice() + "_" + roleName;

					}

					if (groupName != null) {

						log.debug(" Office : {}  Role : {}  || {} ", userGroupDetails.getOffice(), roleName,
								groupName.toUpperCase());
						Group group = groupService.getGroupByNameAndTenantId(groupName.toUpperCase(), tenantId).get(0);
						candidateGroupList.add(String.valueOf(group.getId()));

					}

				} // for role

			} // for usergroup
		} else {
			log.error("Assigned groups list is null, Task group assignment failed");
		}
		return candidateGroupList;
	}

	/*
	 * 
	 */
	public static String getTaskNumber(String taskDef) {
//		task.getTaskDefinitionKey().substring(3)

		for (int i = 3; i < taskDef.length(); i++) {
			String s = taskDef.substring(i);
			try {
				Integer.parseInt(s);
				return s;
			} catch (Exception e) {
				// ignore
			}
		}
		return null;
	}

	public static String getTaskReturnVariable(String processDef, String taskKey) {
		String var = "wfFormReturnPath" + taskKey;
		if (processDef.startsWith("EC") || processDef.startsWith("IPC")) {
			var = var.replaceFirst("_", "");
		}
		log.debug("Return Var : {} ", var);
		return var;
	}

	public static String getTaskActionVariable(String processDef, String taskKey) {
		String var = "wfForm" + taskKey + "_ACTION";

		if (processDef.startsWith("EC") || processDef.startsWith("IPC")) {
			return var.replaceFirst("_", "");
		}
		log.debug("Action Var : {} ", var);
		return var;
	}

	/*
	 * Pring Variables for Debugging
	 * 
	 * @param task
	 * 
	 * @return
	 * 
	 */
	public static void printTaskVariables(String prefix, DelegateTask task) {
		log.debug("***FINAL TASK VARS While leaving the listerner ****** --> " + task.getTaskDefinitionKey());
//		task.getVariables().entrySet().stream().forEach(e-> log.debug("TASK VAR:{} :  {}  :-->  {} ", e.getKey() , e.getValue() ));

		int varCnt = 0;
		Map<String, Object> variables = task.getVariables();
		for (Map.Entry<String, Object> entry : variables.entrySet()) {
			++varCnt;
			if (!entry.getKey().toLowerCase().startsWith("wff")
					&& !entry.getKey().toLowerCase().startsWith("instructions ")) {
				log.debug("{} T->VAR:{} :  {}  :-->  {} ", prefix, (varCnt), entry.getKey(), entry.getValue());
			}

		}
		log.debug("******************************************************* ");
		variables = task.getExecution().getVariables();
		for (Map.Entry<String, Object> entry : variables.entrySet()) {
			++varCnt;
			log.debug("{} P->VAR:{} :  {}  :-->  {} ", prefix, (varCnt), entry.getKey(), entry.getValue());

		}
		log.debug("***END PROCESS  VARS While leaving the listerner ****** --> " + task.getTaskDefinitionKey());

	}
}
