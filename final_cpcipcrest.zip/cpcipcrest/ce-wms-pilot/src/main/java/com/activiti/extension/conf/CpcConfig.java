package com.activiti.extension.conf;

import java.util.TimeZone;

import org.joda.time.DateTimeZone;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

import gov.uspto.pe2e.cpc.ipc.rest.commons.util.RestUtils;

/**
 * This is custom resource loader, to load resource file from CPC jar.
 * 
 * @author 2020LLC
 * @release 1.13
 *
 */
@Configuration
@ImportResource({ "classpath:applicationContext.xml" })
public class CpcConfig {
	
	public CpcConfig() {
		super();
		TimeZone.setDefault(TimeZone.getTimeZone(RestUtils.DEFAULT_TIMEZONE));
		DateTimeZone.setDefault(DateTimeZone.UTC);
	}
}
