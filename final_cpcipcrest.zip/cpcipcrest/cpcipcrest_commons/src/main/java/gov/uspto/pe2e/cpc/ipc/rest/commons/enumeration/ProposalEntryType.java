package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;

import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.SchemeChangeType;

/**
 * US35872 - Enum for Proposal Entry types
 * 
 * @author 2020
 * @date Oct 17, 2016
 * @version 1.6
 *
 */
public enum ProposalEntryType {

	
    NEW(SchemeChangeType.N,false, false),
    NEW_WITH_ADMIN_TRANSFER(SchemeChangeType.Q, false, true),
    DELETE(SchemeChangeType.D,true, true),
    CHANGE(SchemeChangeType.C, true, true),
    ENLARGING_SCOPE_FOR_EXISTING_ENTRIES (SchemeChangeType.T, true, false),
    FROZEN_OR_DEPRECATED(SchemeChangeType.F, true, true),
    MODIFICATIONS_WITH_NO_RECLASS (SchemeChangeType.M, true, false),
    UNCHANGED (SchemeChangeType.U, true, false);
    SchemeChangeType restContractType;
    //Informs whether this symbol should exists in Gold copy already
    boolean requiresSymbolShouldExist;
    //Informs whether the transfer to value should be given by user
    boolean requiresTransferTo;
    
    /**
     * Private Constructor of ProposalEntryType
     * 
     * @param restContractType
     * @param requiresSymbolShouldExist
     * @param requiresTransferTo
     */
    private ProposalEntryType(SchemeChangeType restContractType, boolean requiresSymbolShouldExist, boolean requiresTransferTo) {
        this.restContractType = restContractType;
        this.requiresSymbolShouldExist = requiresSymbolShouldExist;
        this.requiresTransferTo = requiresTransferTo;
    }
    
    /**
     * This finds the proposal Entry type associated with the given rest service contract object
     * returns null if not associated
     * 
     * @param restEntryType
     * @return ProposalEntryType
     */
    public static ProposalEntryType fromSchemeChangeType(SchemeChangeType restEntryType) {
        ProposalEntryType type = null;
        for (ProposalEntryType t: ProposalEntryType.values()) {
            if (t.getRestContractType().equals(restEntryType)) {
                type = t;
                break;
            }
        }
        return type;
    }
    
    /**
     * @return the restContractType
     */
    public SchemeChangeType getRestContractType() {
        return restContractType;
    }
    
    /**
     * @return the requiresSymbolShouldExist
     */
    public boolean isRequiresSymbolShouldExist() {
        return requiresSymbolShouldExist;
    }
    
    /**
     * @return the requiresTransferTo
     */
    public boolean isRequiresTransferTo() {
        return requiresTransferTo;
    }    
}