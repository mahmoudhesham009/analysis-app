package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;


/**
 * This is a special Enum that houses only the NAMED dot levels (first 3) and their corresponding indent
 * levels.  All numeric dot levels map to indent level via dot level + offset (4)
 * @author 2020
 * @date May 24, 2016
 * @version 1.4
 *
 */
public enum DotLevelType {
	/**
	 * NOTE: KEEP THESE VALUES IN ORDER OR THE INDENT MAPPING WILL FAIL
	 */
	SECTION(2,"Section"),
	CLASS(4,"Class"),
	SUBCLASS(5,"Subclass"),
    MAINGROUP(7,"0"),
    SUBGROUP(8,"1"),
    TWO(9,"2"),
    THREE(10,"3"),
    FOUR(11,"4"),
    FIVE(12,"5"),
    SIX(13,"6"),
    SEVEN(14,"7"),
    EIGHT(15,"8"),
    NINE(16,"9"),
    TEN(17,"10"),
    ELEVEN(18,"11"),
    TWELVE(19,"12");


    private int indentLevel;
    private String displayValue;
	/**
	 * 
	 * @param level
	 */
	private DotLevelType(int level,String displayValue) {
		indentLevel= level;
		this.displayValue = displayValue;
	}
	/**
	 * @return the indentLevel
	 */
	public int getIndentLevel() {
		return indentLevel;
	}
	
	
	/**
     * @return the displayValue
     */
    public String getDisplayValue() {
        return displayValue;
    }
    /** 
	 * 
	 * @param indentLevelNo
	 * @return
	 * @since Apr 11, 2017
	 */
    public static DotLevelType fromIndentLevel(int indentLevelNo) {
        DotLevelType dlt = null;
        if (indentLevelNo <= getDotLevelOffset()) {
            int i = 0;
            while (dlt == null || dlt.getIndentLevel() < indentLevelNo) {
                dlt = DotLevelType.values()[i++];
            }
        }
        return dlt;
    }
	
    /**
     * Calculate the difference between subgroup values and children
     * @return int (the amount you subtract or add to the 
     * @since Apr 21, 2017
     */
    private static int getDotLevelOffset() {
        return DotLevelType.values()[DotLevelType.values().length-1].getIndentLevel();
    }
    public static DotLevelType fromDisplay(String dotLevel) {
        DotLevelType dlt = null;
        for (DotLevelType tmp : DotLevelType.values()) {
            if (tmp.getDisplayValue().equalsIgnoreCase(dotLevel)) {
                dlt = tmp;
                break;
            }
        }
        return dlt;
    }
	

}
