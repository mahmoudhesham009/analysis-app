package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;

/**
 * Enum class for the QN Contact Type
 * 
 * @author 2020
 * @date Jan 6, 2016 5:17:11 PM
 * @version 
 */
public enum QNContactType {
	EPOQN("epoQualityNominees"),
	QN ("qualityNominees"),
	SPEQN ("supervisoryPatentExaminers"),
	TL ("tcLeads");
	private String collectionName;

	private QNContactType(String collectionName) {
		this.collectionName = collectionName;
	}

	public String getCollectionName() {
		return collectionName;
	}
	
}
