package gov.uspto.pe2e.cpc.ipc.rest.commons.error;

import java.util.Date;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ResourceCheckoutFailureReason;

/**
 * This exception is used to capture that a "lock" (not a real lock but rather a
 * resource checkout) request by resource Id failed.
 * 
 * @author 2020
 * @date Nov 10, 2015 11:05:27 AM
 * @version 1.5.0
 */
public class ResourceCheckoutException extends Exception {
    private static final long serialVersionUID = 1L;
    private Object resourceId;
    private Object currentLockedUser;
    private Date lockExpirationTs;
    private ResourceCheckoutFailureReason reason;
    
    
    /**
     * No arg constructor
     */
    public ResourceCheckoutException() {
        super();
    }

    /**
     * @param message
     * @param cause
     */
    public ResourceCheckoutException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * 
     * @param message
     * @param cause
     * @param enableSuppression
     * @param writableStackTrace
     */
    public ResourceCheckoutException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    /**
     * Use this constructor to make sure error reporting has proper fields to support internationalization of errors
     * @param resourceId
     * @param currentLockedUser
     * @param lockExpirationTs
     * @param reason
     */
    public ResourceCheckoutException(Object resourceId, Object currentLockedUser, Date lockExpirationTs,
            ResourceCheckoutFailureReason reason) {
        super();
        this.resourceId = resourceId;
        this.currentLockedUser = currentLockedUser;
        this.lockExpirationTs = lockExpirationTs;
        this.reason = reason;
    }

    /**
     * @param message
     */
    public ResourceCheckoutException(String message) {
        super(message);
    }

    /**
     * @param cause
     */
    public ResourceCheckoutException(Throwable cause) {
        super(cause);
    }

    /**
     * @return the resourceId
     */
    public Object getResourceId() {
        return resourceId;
    }

    /**
     * @param resourceId the resourceId to set
     */
    public void setResourceId(Object resourceId) {
        this.resourceId = resourceId;
    }

    /**
     * @return the reason
     */
    public ResourceCheckoutFailureReason getReason() {
        return reason;
    }

    /**
     * @param reason the reason to set
     */
    public void setReason(ResourceCheckoutFailureReason reason) {
        this.reason = reason;
    }

    /**
     * @return the currentLockedUser
     */
    public Object getCurrentLockedUser() {
        return currentLockedUser;
    }

    /**
     * @param currentLockedUser the currentLockedUser to set
     */
    public void setCurrentLockedUser(Object currentLockedUser) {
        this.currentLockedUser = currentLockedUser;
    }

    /**
     * @return the lockExpirationTs
     */
    public Date getLockExpirationTs() {
        return lockExpirationTs;
    }

    /**
     * @param lockExpirationTs the lockExpirationTs to set
     */
    public void setLockExpirationTs(Date lockExpirationTs) {
        this.lockExpirationTs = lockExpirationTs;
    }
}
