package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.eclipse.jgit.util.StringUtils;

import lombok.Getter;

/**
 * 
 * Enum class for the FileExtensionType. This is need for supported extensions
 * for File Upload in the proposal Editor
 * 
 * @author 2020
 * @date Nov 22, 2017
 * @version 1.10.0
 */
public enum FileExtensionType {

    BMP("image/bmp", 1024 * 1024 * 3L, new String[] {"title","note","warning", "definition"}),
    JPEG("image/jpeg",1024 * 1024 * 3L, new String[] {"title","note","warning", "definition"}), 
    JPG(JPEG,1024 * 1024 * 3L, new String[] {"title","note","warning", "definition"}), 
    JPE(JPEG,1024 * 1024 * 3L, new String[] {"title","note","warning", "definition"}), 
    PNG("image/png", 1024 * 1024 * 3L, new String[] {"title","note","warning", "definition"}), 
    GIF("image/gif",1024 * 1024 * 3L, new String[] {"title","note","warning", "definition"}), 
    TIFF("image/tiff",1024 * 1024 * 3L, new String[] {"title","note","warning", "definition"}), 
    TIF(TIFF,1024 * 1024 * 3L, new String[] {"title","note","warning", "definition"}),
    PDF ("application/pdf", 1024 * 1024 * 100L, new String[] {"otherDocs"}),
    DOC ("application/msword", 1024 * 1024 * 100L, new String[] {"otherDocs"}),
    DOCX ("application/vnd.openxmlformats-officedocument.wordprocessingml.document", 
            1024 * 1024 * 100L, new String[] {"otherDocs"}),
    XLS ("application/vnd.ms-excel", 1024 * 1024 * 100L, new String[] {"otherDocs"}),
    XLSX ("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", 
            1024 * 1024 * 100L, new String[] {"otherDocs"}),
    ZIP ("application/zip", 
            1024 * 1024 * 100L, new String[] {"otherDocs"}),
    PPT ("application/vnd.ms-powerpoint", 1024 * 1024 * 100L, new String[] {"otherDocs"}),
    PPTX ("application/vnd.openxmlformats-officedocument.presentationml.presentation",
            1024 * 1024 * 100L, new String[] {"otherDocs"}),
    XML ("text/xml", 1024 * 1024 * 100L, new String[] {"otherDocs"})
    ;
    


    private String contentType;
    private FileExtensionType primaryType;
    @Getter
    private long maxSize;
    @Getter
    private List<String> supportedComponents;
    
    /**
     * Constructor for the ExportOutputType
     * 
     * @param contentType
     */
    private FileExtensionType(String contentType, long maxSize, String... supportedComponents) {
        this.contentType = contentType;
        this.maxSize =  maxSize;
        this.supportedComponents = Arrays.asList(supportedComponents);
    }
    
    /**
     * Constructor for the ExportOutputType
     * 
     * @param primaryType
     */
    private FileExtensionType(FileExtensionType primaryType, long maxSize,  String... supportedComponents) {
        this.contentType = null;
        this.primaryType = primaryType;
        this.maxSize =  maxSize;

        this.supportedComponents = Arrays.asList(supportedComponents);

    }

    public FileExtensionType getPrimaryType() {
        return primaryType;
    }
    
    public String getContentType() {
        FileExtensionType target = this;
        while (target.getPrimaryType() != null) {
            target = target.getPrimaryType();
        }        
        return target.contentType;
    }

    public static List<FileExtensionType> byComponentType(String componentType) {
        List<FileExtensionType> matches = new ArrayList<>();
        for (FileExtensionType ft: values()) {
            if (ft.getSupportedComponents().contains(componentType)) {
                matches.add(ft);
            }
        }
        return matches;
    }

  
    public static FileExtensionType byComponentTypeAndExtension(String componentType, String fileExtension) {
        FileExtensionType returnMe = null;
        for (FileExtensionType ft: values()) {
            if (ft.getSupportedComponents().stream().anyMatch(componentType::equalsIgnoreCase) 
                    && StringUtils.toLowerCase(ft.name())
                        .equals(StringUtils.toLowerCase(fileExtension))) {
                returnMe = ft;
                break;
            }
        }
        return returnMe;
    }

}
