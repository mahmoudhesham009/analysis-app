package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;

/**
 * This is an enum for standard field names used in reflection that is AGNOSTIC of which publication tree is in use.
 * If there is a possibility of field names being different between publication trees DO NOT DEFINE THEM HERE!
 * For version specific field name 
 * see gov.uspto.pe2e.cpc.ipc.rest.web.service.document.adapter.insert version>.ReflectionField 
 * @author 2020
 * @date Jul 13, 2017
 * @version 1.8
 *
 */
public enum StandardReflectionField {
    ANNOTATION_ATTRIBUTE_NAME("name"),
    RAWTEXT_CONTENT("content"),
    SYMBOL_REFERENCE_SYMBOL_NAME("symbolName"),
    SCHEME_ATTRIBUTE_NAME("scheme");

    private String value;

    private StandardReflectionField(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
