package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;

/**
 * 
 * Enum class for the Doc Library FileExtensionType. This is need for supported extensions
 * for File Upload.
 * 
 * @author 2020
 * @date 03 22, 2021
 * @version 1.10.0
 */
@Deprecated
public enum DocLibraryFileExtensionType {

    DOC("application/msword"),
    DOCX("application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
    PDF("application/pdf"),
    PPT("application/vnd.ms-powerpoint"),
    PPTX("application/vnd.openxmlformats-officedocument.presentationml.presentation"),
    XLS("application/vnd.ms-excel"),
    XLSX("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");

    private String contentType;
    private DocLibraryFileExtensionType primaryType;

    /**
     * Constructor for the ExportOutputType
     * 
     * @param contentType
     */
    private DocLibraryFileExtensionType(String contentType) {
        this.contentType = contentType;
    }
    
    /**
     * Constructor for the ExportOutputType
     * 
     * @param primaryType
     */
    private DocLibraryFileExtensionType(DocLibraryFileExtensionType primaryType) {
        this.contentType = null;
        this.primaryType = primaryType;
    }

    public DocLibraryFileExtensionType getPrimaryType() {
        return primaryType;
    }
    
    public String getContentType() {
    	DocLibraryFileExtensionType target = this;
        while (target.getPrimaryType() != null) {
            target = target.getPrimaryType();
        }        
        return target.contentType;
    }



}
