package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;
/**
 * Enum for the Application Permissions
 * 
 * 
 * @author 2020
 * @date Mar 9, 2016
 * @version 1.4
 *
 */
public enum ApplicationPermission {
    NAVIGATOR_ENABLED,
	NAVIGATOR_LIST,
	NAVIGATOR_SEARCH,
    NAVIGATOR_GET,
    NAVIGATOR_GET_FULL,
	NAVIGATOR_SIMPLE_EDIT,
	PROPOSAL_MANAGER_ENABLED,
	PROPOSAL_LOCKS_ENABLED,
	PROPOSAL_GET,
	PROPOSAL_LIST,
	PROPOSAL_SEARCH,
	PROPOSAL_CREATE,
	PROPOSAL_UPDATE,
	PROPOSAL_MANAGER_AE_GET,
	RESOURCE_MANAGER_ENABLED,
	PROPOSAL_REVISION_SAVE,
	PROPOSAL_REVISION_UPDATE,
	IPC_CONCORDANCE_GET,
	IPC_CONCORDANCE_SEARCH,
	RESOURCE_LIST,
	RESOURCE_SEARCH, 
	RESOURCE_GET,
	RESOURCE_SAVE,
	RESOURCE_DELETE,
	WMS_INSTANCE_START,
	WMS,
	DIFF_ROW,
	DASHBOARD_ENABLED,
	EB_ENABLED,
	EDITORIAL_BOARD, // special permission/authority used to match names required by activiti group naming
	COORDINATOR, // Coordinator is a special authority created to allow activiti groups to have conventional names.
	PUBLICATION_BOARD,   // PUBLICATION_BOARD
	CPC_ADMIN,
	SME_CONSULTATION, 	// this is READ functions of SME Consultation
	SME_CONSULTATION_PARTICIPATION, // This is any pariticipation by either SME or PC
	START_SME_CONSULTATION,  // this can only be done by PC
	SME_RESPONSE,// only granted to SMEs (SCE(US) or QN_TECH_EXPERT(EP))
	WAT_GET; //only granted to CPC_WAT_MANAGER
}
