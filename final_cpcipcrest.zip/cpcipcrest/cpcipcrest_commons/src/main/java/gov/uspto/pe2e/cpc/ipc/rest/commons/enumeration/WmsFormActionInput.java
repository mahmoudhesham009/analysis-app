package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;

public enum WmsFormActionInput {
	Approve,
	Reject, 
	Suspend,
	Return; // not sure what this value is for

}
