package gov.uspto.pe2e.cpc.ipc.rest.commons.jee.filter;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.preauth.AbstractPreAuthenticatedProcessingFilter;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;

import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationPermission;
import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ApplicationRole;
import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.Tenant;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.SecurityService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.UsptoGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.JsonUtils;
import gov.uspto.pe2e.cpc.ipc.rest.contract.saml.UsptoAuthenticationToken;

/**
 * 
 * @author 2020
 * @date Feb 7, 2019
 * @since __INSERT_VERSION__
 * @version __INSERT_VERSION__
 */
public class ServiceAuthHeaderPreAuthFilter extends AbstractPreAuthenticatedProcessingFilter {
	public static final String SERVICE_AUTH_HEADER_NAME = "X-Service-Auth";
	private static final Logger log = LoggerFactory.getLogger(ServiceAuthHeaderPreAuthFilter.class);
	
	private SecurityService securityService;

	/** 
	 * @see org.springframework.security.web.authentication.preauth.AbstractPreAuthenticatedProcessingFilter
	 * #getPreAuthenticatedPrincipal(javax.servlet.http.HttpServletRequest)
	 */
	@Override
	public Object getPreAuthenticatedPrincipal(HttpServletRequest request) {
		return constructPrincipal(request);
	}

	/**
	 * @see org.springframework.security.web.authentication.preauth.AbstractPreAuthenticatedProcessingFilter
	 * #getPreAuthenticatedCredentials(javax.servlet.http.HttpServletRequest)
	 */
	@Override
	public Object getPreAuthenticatedCredentials(HttpServletRequest request) {
		return constructPrincipal(request);
	}
	
	/**
     * Construct Principal
     * 
     * @param request
     * @return Authentication
     */
	public Authentication constructPrincipal(HttpServletRequest request) {
		PreAuthenticatedAuthenticationToken userToken = null;
		String token = request.getHeader(SERVICE_AUTH_HEADER_NAME);
		if (StringUtils.isNotBlank(token) && validateHeaderToken(token)) {
			InputStream is = null;
			try {
	        	is = Thread.currentThread().getContextClassLoader().getResourceAsStream("service_auth_token.json");
	        	UsptoAuthenticationToken serviceToken = JsonUtils.fromJson(is, UsptoAuthenticationToken.class );
			
	        	userToken = new PreAuthenticatedAuthenticationToken(
	        			serviceToken.getEmail(),
	        			serviceToken,
	        			constructAuthorities(serviceToken.getAuthorities()));
	        	
	        	SecurityContextHolder.getContext().setAuthentication(userToken);

	        } catch (Exception e) {
	        	log.error("Failed to construct UserDetails from Service Auth Header."
	        			+"  This means that the underlying header value algorithm on the client side "
	        			+"is broken or misconfigured (check Timezone, we use UTC)."
	        			+"  Returning now so the Filter chain continues and prompts for Login"
	        			+" rather than throwing error.",e);
	        }
			finally {
	        	IOUtils.closeQuietly(is);
	        }			
		}
		return userToken;
	}
	
	/**
     * Construct Authorities
     * 
     * @param authorityStrings
     * @return Collection
     */
	private Collection<? extends GrantedAuthority> constructAuthorities(List<String> authorityStrings) {
		List<UsptoGrantedAuthority> authorities = new ArrayList<>();
		for (String permission: authorityStrings) {
			if (EnumUtils.isValidEnum(ApplicationPermission.class, permission)) {
                UsptoGrantedAuthority grant = new UsptoGrantedAuthority(Tenant.PTO, ApplicationRole.SERVICE_ACCOUNT,
                        ApplicationPermission.valueOf(permission));
			authorities.add(grant);
			}
		}
		return authorities;
	}
	
	/**
     * Validate Header Token
     * 
     * @param token
     * @return boolean
     */
	private boolean validateHeaderToken(String token) {
		boolean ret = false;

		String localGeneratedHeader = securityService.getServiceAuthHeader();
		if (StringUtils.isNotBlank(token)) {
			if ( StringUtils.equals(localGeneratedHeader, token) 
					|| StringUtils.equals(securityService.getServiceAuthHeader(getLastHour()), token)) {
				ret = true;
			} else {
				throw new BadCredentialsException(token+" does not match expected service Auth header");
			}
		} 
		return ret;
	}

	/**
	 * get last hour datetime
	 * @return DateTime
	 */
	private DateTime getLastHour() {
		DateTime lastHr = new DateTime();
		lastHr = lastHr.minusHours(1);
		return lastHr;
	}

	/**
	 * @param securityService the securityService to set
	 */
	public void setSecurityService(SecurityService securityService) {
		this.securityService = securityService;
	}
	
	/**
	 * Set Authentication Manager
	 */
	public void setAuthenticationManager(AuthenticationManager authenticationManager) {
		super.setAuthenticationManager(authenticationManager);
	}
}
