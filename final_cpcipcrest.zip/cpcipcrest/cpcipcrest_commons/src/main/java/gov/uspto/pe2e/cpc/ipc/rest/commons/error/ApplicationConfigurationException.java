/**
 * 
 */
package gov.uspto.pe2e.cpc.ipc.rest.commons.error;

/**
 * @author 2020
 * @date August 03,2017
 */
public class ApplicationConfigurationException extends Exception {

	
	private static final long serialVersionUID = 1L;

	public ApplicationConfigurationException() {
		super();
	}

	public ApplicationConfigurationException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);		
	}

	public ApplicationConfigurationException(String message, Throwable cause) {
		super(message, cause);		
	}

	public ApplicationConfigurationException(String message) {
		super(message);		
	}

	public ApplicationConfigurationException(Throwable cause) {
		super(cause);		
	}
}
