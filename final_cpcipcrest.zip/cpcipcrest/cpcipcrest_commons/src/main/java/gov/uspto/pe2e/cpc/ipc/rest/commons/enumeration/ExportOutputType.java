package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;

/**
 * enum ExportOutputType class
 * 
 * @author 2020
 * @date Nov 3, 2015 2:39:26 PM
 * @version
 */
public enum ExportOutputType {

	DOCX("application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
	ZIP("application/zip"),
	// JSON formatter/exporters have been replaced by the more easily supported
	// HTML format. This eliminates the need for the
	// UI team having to be aware of future publication changes and keeps the
	// docx/pdf/html views consistent without effort
	JSON("application/json"), HTML("text/html; charset=UTF-8"), PDF("application/pdf"),
	XLSX("application/vnd.ms-excel"),
	CSV("application/csv");
	private String contentType;

	/**
	 * Constructor for the ExportOutputType
	 * 
	 * @param contentType
	 */
	private ExportOutputType(String contentType) {
		this.contentType = contentType;
	}

	public String getContentType() {
		return contentType;
	}

}
