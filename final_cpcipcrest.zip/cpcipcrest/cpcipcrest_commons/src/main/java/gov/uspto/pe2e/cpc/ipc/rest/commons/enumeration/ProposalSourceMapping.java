package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;

/**Mapping for proposal source 
 * 
 * @author msingh4
 *
 */
public enum ProposalSourceMapping {

	IPC("IPC"),
	IP5("IP5"),
	CPC("CPC"),
	IPC_IMPLMN("IPC Implementation"),
	BILATERAL_HARMZN("Bilateral Harmonization (HP/HX)");
	
	private String proposalSource;
	
	ProposalSourceMapping(String proposalSource) {
		this.proposalSource=proposalSource;
	}
	public String getProposalSource() {
		return proposalSource;
	}
}
