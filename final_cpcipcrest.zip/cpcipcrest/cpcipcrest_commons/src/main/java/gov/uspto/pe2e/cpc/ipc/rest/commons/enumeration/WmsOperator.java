package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;

/** 
 * This enum maps the vendor operator string to our operator.  it also has a facility to take a
 * logical operator that typically needs no compare value (such as isEmpty() or isNotEmpty()) 
 * and provides a default right hand side compare value since our expression always has a right 
 * and left side comparison for simplicity 
 * 
 * TODO: Consider moving this to the enumeration package in the WMS JAR
 * 
 * @author myoung3
 *
 */
public enum WmsOperator {
	EMPTY ("empty", "==", "null"),
	NOTEMPTY ("!empty", "!=", "null"),
	EQUALS ("==", "=="),
	NOTEQUALS("!=","!=");
	
	private String vendorOperator;
	private String ourOperator;
	private String compareValueOverride;
	private WmsOperator(String vendorOperator, String ourOperator, String compareValueOverride) {
		this.vendorOperator = vendorOperator;
		this.ourOperator = ourOperator;
		this.compareValueOverride = compareValueOverride;
	}
	private WmsOperator(String vendorOperator, String ourOperator) {
		this.vendorOperator = vendorOperator;
		this.ourOperator = ourOperator;
	}
	/**
	 * @return the vendorOperator
	 */
	public String getVendorOperator() {
		return vendorOperator;
	}
	/**
	 * @return the ourOperator
	 */
	public String getOurOperator() {
		return ourOperator;
	}
	/**
	 * @return the compareValueOverride
	 */
	public String getCompareValueOverride() {
		return compareValueOverride;
	}
	
	public static WmsOperator findOperatorByVendorString(String vendorOp) {
		WmsOperator operator = null;
		for (WmsOperator maybeOp: values()) {
			if (maybeOp.getVendorOperator().equals(vendorOp)) {
				operator = maybeOp;
				break;
			}
		}
		return operator;
	}
}