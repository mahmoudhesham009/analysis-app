package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;

import java.util.Date;

import org.apache.lucene.document.SortedDocValuesField;
import org.apache.lucene.document.StoredField;
import org.apache.lucene.document.StringField;

/**
 * List of fields we index or store in our Search index
 * 
 * NOTE: Raw types are used throughout this class because the contract being
 * implemented allows for potentially returning/handling types that might not
 * extend/implement a common base class. Getting rid of raw types would require
 * the contract objects to extend a common base class which would have to be
 * built into contract XSDs and offers us nothing in the way of concrete type
 * safety as every contract version may add/remove fields. These raw types are
 * then passed back to spring to handle serialization via whatever format the
 * client is expecting. THERE IS NO BENEFIT IN TERMS OF TYPE SAFETY TO TRY AND
 * FORCE THESE RAW TYPES INTO AN CLASS HIERARCHY.
 * 
 * @author 2020
 * @date Dec 16, 2015 1:53:04 PM
 * @version
 */
public enum IndexField {
    /**
     * Classification_scheme date associated with a symbol record
     */
    PUBLICATION_DATE(Date.class, StoredField.class),
    /**
     * numeric primary key column representing the primary key on the
     * scheme_hierarchy table
     */
    ID(Long.class, StoredField.class),
    /**
     * Foreign key field
     */
    PARENT_ID(Long.class, StoredField.class),
    /**
     * Symbol name
     */
    SYMBOL_NAME(String.class, StoredField.class),
    /**
     * Section - this is *usually* the first 
     */
    SECTION(String.class, StringField.class),
    /**
     * List of ancestor strings encoded as int representations of individual chars
     * NOTE: encoding the strings is important in order to prevent lucene from treating some symbols
     * as irrelevant terms
     */
    ANCESTORS(String.class, StringField.class),
    /**
     * parent Symbol name
     */
    PARENT_SYMBOL_NAME(String.class, StoredField.class),
    /**
     * Indent level associated with a symbol
     */
    INDENT_LEVEL(Integer.class, StoredField.class),
    /**
     * String representing xml stripped of any xml tags for a title
     */
    TITLE_TEXT(String.class, StringField.class),
    /**
     * String representing xml stripped of any xml tags for a notes and warnings
     */
    NOTES_AND_WARNINGS_TEXT(String.class, StringField.class),
    /**
     * String representing xml stripped of any xml tags for a definition
     */
    DEFINITION_TEXT(String.class, StringField.class), 
    /**
     * This is a special field containing a duplicate value of section.  This field is not analyzed 
     * and is only used for sorting/grouping.
     */
    SECTION_DOCVAL_SORTABLE (String.class, SortedDocValuesField.class);
    private Class dataType;
    private Class luceneFieldType;

    private IndexField(Class dataType, Class luceneFieldType) {
        this.dataType = dataType;
        this.luceneFieldType = luceneFieldType;
    }

    public Class getDataType() {
        return dataType;
    }

    public Class getLuceneFieldType() {
        return luceneFieldType;
    }

}
