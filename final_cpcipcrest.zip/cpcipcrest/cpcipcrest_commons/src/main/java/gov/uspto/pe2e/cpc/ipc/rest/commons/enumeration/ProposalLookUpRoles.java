package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;

/**
 * Mapping for Proposal Lookup user roles list, 
 * mapping between PD form roles and project details view table role columns
 * 
 * @author vkommareddy
 *
 */
public enum ProposalLookUpRoles {
	
	US_PC_NM("US PC", "CPC Project Coordinator", "usCoordinator"),
	US_EB_NM("US EB", "CPC_EB", "usEditorialBoard"),
	US_SCE_NM("US SCE", "SCE", "usSCE"), 
	US_BACKUP_SCE_NM("US Backup SCE", "SCE", "usBackupSCE"), 
	US_SCESPE_NM("US SCE SPE", "SCE-SPE", "usSupervisoryClassificationOrPatentExaminer"),	 
	US_SPC_NM("US SPC", "CSD", "usSupervisoryPatentClassifier"), 
	US_RECLASS_MGR_NM("US Reclassification Manager", "Reclassification Managers", "usReclassManager"),
	EP_PC_NM("EP PC", "COORDINATOR", "epCoordinator"), 
	EP_EB_NM("EP EB", "EDITORIAL_BOARD", "epEditorialBoard"),
	EP_QN_NM("EP QN", "QN_TECH_EXPERT", "epQNExpert"),
	EP_GERANT_NM("EP Gerant", "GERANT", "epGerant"), 
	EP_CPBM_NM("EP CBM", "CBM", "epClassificationBoardMember"),	
	EP_RECLASS_MGR_NM("EP Reclassification Manager", "RECLASS_MGR", "epReclassManager"),
	PUB_WRITER_EDITOR_NM("Publication Writer Editor", RoleConstants.CPC_PUBLICATION_TEAM_VALUE, "publicationWriterEditor"),
	PUB_SPECIALIST_NM("Publication Specialist", RoleConstants.CPC_PUBLICATION_TEAM_VALUE, "publicationSpecialist"),
	PUB_MGR_NM("Publication Manager", RoleConstants.CPC_PUBLICATION_TEAM_VALUE, "publicationManager");
	
	private String roleDesc;
	private String roleCd;
	private String prjDetailsViewColName;

	ProposalLookUpRoles(String roleDesc, String roleCd, String prjDetailsViewColName) {
		this.roleDesc = roleDesc;
		this.roleCd = roleCd;
		this.prjDetailsViewColName = prjDetailsViewColName;
	}

	public String getRoleDesc() {
		return roleDesc;
	}

	public String getRoleCd() {
		return roleCd;
	}
	
	public String getPrjDetailsViewColName() {
		return prjDetailsViewColName;
	}

	private static class RoleConstants {
		public static final String CPC_PUBLICATION_TEAM_VALUE = "CPC PUBLICATION TEAM";
	}
}
