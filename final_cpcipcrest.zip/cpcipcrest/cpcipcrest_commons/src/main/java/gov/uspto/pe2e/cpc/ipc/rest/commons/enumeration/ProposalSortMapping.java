package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;

import java.util.Objects;

import org.apache.commons.lang3.StringUtils;

import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.GplSortBy;
import lombok.Getter;

/**
 * This class is responsible for mapping GplSortOrder to the field names in the
 * DB
 * 
 * @author msingh4
 *
 */
@Getter
public enum ProposalSortMapping {
	PROJECT(GplSortBy.PROJECT, "projectDetailView.projectSortNum"), 
	CREATE_TS(GplSortBy.CREATE_TS, "createTs"),
	CREATE_BY(GplSortBy.CREATE_BY, "createUserId"),
	US_COORDINATOR(GplSortBy.US_COORDINATOR, "projectDetailView.usCoordinator"),
	EP_COORDINATOR(GplSortBy.EP_COORDINATOR, "projectDetailView.epCoordinator"),
	PHASE(GplSortBy.PHASE, "projectDetailView.proposalPhaseSortNum");

	private GplSortBy sortBy;
	private String entityGraphFieldPath;

	private ProposalSortMapping(GplSortBy sortBy, String entityGraphFieldPath) {
		this.sortBy = sortBy;
		this.entityGraphFieldPath = entityGraphFieldPath;
	}

	public static ProposalSortMapping bySortByRequest(GplSortBy sortByReq) {
		ProposalSortMapping mapping = null;

		for (ProposalSortMapping maybe : ProposalSortMapping.values()) {
			if (Objects.equals(maybe.getSortBy(), sortByReq) || StringUtils.equals(maybe.name(), sortByReq.name())) {
				mapping = maybe;
				break;
			}
		}
		return mapping;
	}
}
