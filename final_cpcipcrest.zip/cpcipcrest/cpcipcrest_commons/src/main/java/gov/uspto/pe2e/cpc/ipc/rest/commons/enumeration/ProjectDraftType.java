package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;

/**
 * Enum class for the project type.
 * 
 * @author 2020
 * @date May 4, 2016
 * @version 1.4 
 *
 */
public enum ProjectDraftType {
	DRAFT,
	PROJECT;

}
