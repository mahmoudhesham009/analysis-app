/**
 * 
 */
package gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration;

/** Proposal Type enum to support search functionality by proposal type code
 * @author msingh4
 *
 */
public enum ProposalTypeMapping {

	DP("DP-Definition Project"),
	MP("MP-Maintenance Project"),
	RP("RP-Revision Project"),
	HP("HP-Harmonization Project"),
	HX("HX- Cross Technology"),
	EC("EC-Editorial Corrections"),
	IA("IA"),
	IC("IC"),
	ID("ID"),
	IF("IF"),
	IM("IM"),
	IZ("IZ"),
	IQ("IQ"),
	IV("IV"),
	IW("IW"),
	IE("IE"),
	IJ("IJ"),
	IP("IP"),
	IU("IU");
	
	private String proposalType;

	ProposalTypeMapping(String proposalType) {
		this.proposalType=proposalType;
	}
	public String getProposalType() {
		return proposalType;
	}
	
}
