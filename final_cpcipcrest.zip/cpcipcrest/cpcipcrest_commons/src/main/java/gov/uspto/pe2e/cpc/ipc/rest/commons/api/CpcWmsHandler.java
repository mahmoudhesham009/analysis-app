package gov.uspto.pe2e.cpc.ipc.rest.commons.api;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import com.activiti.model.runtime.TaskRepresentation;

import gov.uspto.pe2e.cpc.ipc.rest.commons.error.ExternalServiceException;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.OfficeContact;
import gov.uspto.pe2e.cpc.ipc.rest.contract.stateflow.v1_0.TaskStateDetails;

public interface CpcWmsHandler {
    
	public TaskStateDetails getTaskDetailsByTaskId(String taskId) throws ExternalServiceException;

}
