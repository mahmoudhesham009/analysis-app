
package gov.uspto.pe2e.cpc.ipc.rest.cef.contract;

import java.util.Date;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.w3._2001.xmlschema.Adapter1;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

public class CefRapporteurSummary {

    
    protected long projectid;
    
    protected long taskid;
    
    protected String code;
    
    protected String approvalText;
    
    protected String anxlist;
    
    protected String action;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @JsonProperty("created_at")
    protected Date createdAt;
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    @JsonProperty("updated_at")
    protected Date updatedAt;

    /**
     * Gets the value of the projectid property.
     * 
     */
    public long getProjectid() {
        return projectid;
    }

    /**
     * Sets the value of the projectid property.
     * 
     */
    public void setProjectid(long value) {
        this.projectid = value;
    }

    /**
     * Gets the value of the taskid property.
     * 
     */
    public long getTaskid() {
        return taskid;
    }

    /**
     * Sets the value of the taskid property.
     * 
     */
    public void setTaskid(long value) {
        this.taskid = value;
    }

    /**
     * Gets the value of the code property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the value of the code property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCode(String value) {
        this.code = value;
    }

    /**
     * Gets the value of the approvalText property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApprovalText() {
        return approvalText;
    }

    /**
     * Sets the value of the approvalText property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApprovalText(String value) {
        this.approvalText = value;
    }

    /**
     * Gets the value of the anxlist property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAnxlist() {
        return anxlist;
    }

    /**
     * Sets the value of the anxlist property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAnxlist(String value) {
        this.anxlist = value;
    }

    /**
     * Gets the value of the action property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAction() {
        return action;
    }

    /**
     * Sets the value of the action property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAction(String value) {
        this.action = value;
    }

    /**
     * Gets the value of the createdAt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getCreatedAt() {
        return createdAt;
    }

    /**
     * Sets the value of the createdAt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreatedAt(Date value) {
        this.createdAt = value;
    }

    /**
     * Gets the value of the updatedAt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getUpdatedAt() {
        return updatedAt;
    }

    /**
     * Sets the value of the updatedAt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdatedAt(Date value) {
        this.updatedAt = value;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
    }

    @Override
    public boolean equals(Object that) {
        return EqualsBuilder.reflectionEquals(this, that);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

}
