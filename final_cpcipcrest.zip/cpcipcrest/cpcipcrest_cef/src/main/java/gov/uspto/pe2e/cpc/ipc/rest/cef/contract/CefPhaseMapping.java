package gov.uspto.pe2e.cpc.ipc.rest.cef.contract;

/**
 * Enum for mapping CEF status to CE project phase
 * 
 * @author Maximus
 * @date: 10/01/2021
 *
 */
public enum CefPhaseMapping {

	A("A"),
	C("C"),
	D("DI"),
	F("F"),
	P("PI"),
	Q("Q"),
	R("R"),
	U("U");

	private final String phase;
	
	private CefPhaseMapping(String phase) {
		this.phase=phase;
	}
	/**
	 * Get project phase code using CEF status code
	 * @return phase
	 */
	public String getPhase() {
		return phase;
	}	
	
}
