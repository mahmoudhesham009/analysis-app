package gov.uspto.pe2e.cpc.ipc.rest.cef.service;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.annotation.Nonnull;
import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import gov.uspto.pe2e.cpc.ipc.rest.cef.contract.CefPhaseMapping;
import gov.uspto.pe2e.cpc.ipc.rest.cef.contract.CefProject;
import gov.uspto.pe2e.cpc.ipc.rest.cef.contract.WorkflowMapping;
import gov.uspto.pe2e.cpc.ipc.rest.cef.util.CefConstants;
import gov.uspto.pe2e.cpc.ipc.rest.cef.util.CefMigrationHelper;
import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.WmsPhases;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.CefModuleProcessLog;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.CefProjectProcessLog;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.CefModuleProcessLogRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.CefProjectProcessLogRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.CefMigrationStatus;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.CefModuleName;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.CefProjectMigrationRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.saml.UsptoAuthenticationToken;
import gov.uspto.pe2e.cpc.ipc.rest.contract.stateflow.v1_0.WorkflowEntryPoint;
import gov.uspto.pe2e.cpc.ipc.rest.contract.stateflow.v1_0.WorkflowProposalTrack;
import gov.uspto.pe2e.cpc.ipc.rest.wms.service.WmsProcessInstanceService;
import lombok.RequiredArgsConstructor;

/**
 * CEF Migration Service - Project Workflow
 * 
 * @author Maximus
 * @version 2.3.0
 * @date: 08/30/2021
 *
 */
@Component
@Service("cefWorkflowMigrationService")
@RequiredArgsConstructor(onConstructor = @__(@Inject))
public class CefWorkflowMigrationService {

	private static final Logger log = LoggerFactory.getLogger(CefWorkflowMigrationService.class);

	@Nonnull
	private ReloadableResourceBundleMessageSource reloadableResourceBundleMessageSource;

	@Nonnull
	private WmsProcessInstanceService wmsProcessInstanceService;

	@Nonnull
	private CefProjectProcessLogRepository cefProjectProcessLogRepository;

	@Nonnull
	private CefModuleProcessLogRepository cefModuleProcessLogRepository;

	@Nonnull
	private CefMigrationHelper migrationHelper;

	@Nonnull
	private CefCommonService cefCommonService;

	/**
	 * Process CEF projects workflow
	 * 
	 * @param cefRequest
	 * @param authToken
	 * @return
	 */
	@Transactional
	public UUID processCefProjectsWorkflow(CefProjectMigrationRequest request, UsptoAuthenticationToken authToken) {
		UUID proposalGuid = null;

		log.info("Inside processCefProjectsWorkflow -- start");

		List<String> cefProjects = new ArrayList<>();

		if (request.isMigrateAllProjects()) {
			cefProjects = cefCommonService.getListofProjectsToBeMigratedFromDB(CefModuleName.WORKFLOW);
		} else {
			cefProjects = request.getCefProjectCode();
		}
		log.debug("Token - "+authToken.toString());
		if (CollectionUtils.isNotEmpty(cefProjects)) {
			for (String cefProject : cefProjects) {
				if (cefCommonService.isCefMetadataProcessedSuccessfully(cefProject)) {
					if(!verifyProjectStatus(cefProject)) {
					log.debug("Getting list of files for the project {}", cefProject);
					List<File> projectFiles = migrationHelper.getAllFilesByProjectName(cefProject);

					log.debug("Getting project.json file from list of project files");
					File projectFile = migrationHelper.getProjectFileByName(projectFiles,
							CefConstants.PROJECT_FILE_NAME);
					CefProject projectData = null;
					try {
						projectData = cefCommonService.mapJsonFileToCefProject(projectFile);
						if (isWorkflowRequired(projectData)) {
							log.debug("Workflow Migration started for the project:: {}", cefProject);
							log.debug("Getting workflow mapping using project type code");
							WorkflowMapping wfMapping = WorkflowMapping.valueOf(projectData.getTypecode().trim());
							WorkflowProposalTrack track = wfMapping.getProposalTrack();
							WorkflowEntryPoint wfEntryPoint = wfMapping.getWfEntryPoint();
							WmsPhases wmsPhase = WmsPhases
									.valueOf(CefPhaseMapping.valueOf(projectData.getStatuscode().trim()).getPhase());

							CefProjectProcessLog projectLog = cefProjectProcessLogRepository
									.findAllByCefProjectCode(cefProject);
							UUID cpGUID = GUIDUtils.fromDatabaseFormat(projectLog.getChangeProposalExternalId());

							proposalGuid = wmsProcessInstanceService.kickOffWorkFlow(authToken, cpGUID,
									projectLog.getChangeProposalCode(), track, wfEntryPoint, wmsPhase);
							if (proposalGuid != null) {
								cefCommonService.populateCefModuleProcessLog(cefProject, CefMigrationStatus.SUCCESS,
										migrationHelper.getJsonFromObject(request), "", authToken.getEmail(),
										CefModuleName.WORKFLOW);
								// Update project migration status in Process Log table
								populateProcessLogStatusForWorkflow(cefProject, CefMigrationStatus.SUCCESS,
										authToken.getEmail());								
								log.debug("Workflow Migration completed for the project:: {}", cefProject);

							} else {
								String exceptionText = "Workflow can't be started for the CEF project, due to an exception while starting workflow. Refer to server logs for more details.";
								cefCommonService.populateCefModuleProcessLog(cefProject, CefMigrationStatus.FAILED,
										migrationHelper.getJsonFromObject(request), exceptionText, authToken.getEmail(),
										CefModuleName.WORKFLOW);
							}
						} else {
							log.debug("Workflow not required for the phase - {}", projectData.getStatusname());
							cefCommonService.populateCefModuleProcessLog(cefProject, CefMigrationStatus.SUCCESS,
									migrationHelper.getJsonFromObject(request), "", authToken.getEmail(),
									CefModuleName.WORKFLOW);

							// Update project migration status in Process Log table
							populateProcessLogStatusForWorkflow(cefProject, CefMigrationStatus.SUCCESS,
									authToken.getEmail());
						}
					} catch (Exception e) {
						log.debug("Exception occurred while processing workflow for the project", e);
						cefCommonService.populateCefModuleProcessLog(cefProject, CefMigrationStatus.FAILED,
								migrationHelper.getJsonFromObject(request), cefCommonService.getStacktraceString(e),
								authToken.getEmail(), CefModuleName.WORKFLOW);

					}
				}
				} else {
            		if(!isSkipProject(cefProject)) {
					String errorMesssage = "Project Metadata is not processed successfully. Workflow can't be started";
					log.debug(
							"Workflow can't be started for the CEF project : {}, since the project metadata is not processed successfully",
							cefProject);
					cefCommonService.populateCefModuleProcessLog(cefProject, CefMigrationStatus.FAILED,
							migrationHelper.getJsonFromObject(request), errorMesssage, authToken.getEmail(),
							CefModuleName.WORKFLOW);
				}
            	}
			}
		}

		log.info("Inside processCefProjectsWorkflow -- end");
		return proposalGuid;
	}

	/**
	 * Check if workflow is required
	 * 
	 * @param cefProject
	 * @return
	 */
	private boolean isWorkflowRequired(CefProject cefProject) {
		String status = cefProject.getStatusname();
		String projType=cefProject.getTypecode();
		boolean workflowRequired = true;
		if (StringUtils.isBlank(status) || status.trim().equalsIgnoreCase(CefConstants.STATUS_ON_HOLD)
				|| status.trim().equalsIgnoreCase(CefConstants.STATUS_IPC_PHASE)
				|| status.trim().equalsIgnoreCase(CefConstants.STATUS_ONGOING)
				|| status.trim().equalsIgnoreCase(CefConstants.STATUS_SUSPENDED) 
				|| (StringUtils.isNotBlank(projType) && projType.trim().equalsIgnoreCase(CefConstants.PM_PROJECT_TYPE))){
			workflowRequired = false;
		}
		return workflowRequired;
	}

	/**
	 * Check if project needs to be skipped
	 * 
	 * @param cefProjectCode
	 * @return
	 */
	private boolean isSkipProject(String cefProjectCode) {
		boolean skipProject = false;
		File cefProjectFile = migrationHelper.getFileByProjectName(cefProjectCode, CefConstants.PROJECT_FILE_NAME);
		CefProject cefProject;

		try {
			cefProject = cefCommonService.mapJsonFileToCefProject(cefProjectFile);
			skipProject = cefCommonService.isSkipForMigration(cefProject);
		} catch (Exception e) {
			log.debug("Exception occurred while mapping project.json file to CefProject");
		}
		return skipProject;
	}

	/**
	 * Populate CEF migration status - Project Log
	 * 
	 * @param cefProjectCode
	 * @param status
	 * @param userEmail
	 */
	private void populateProcessLogStatus(String cefProjectCode, CefMigrationStatus status, String userEmail) {
		CefProjectProcessLog projectLog = cefProjectProcessLogRepository.findAllByCefProjectCode(cefProjectCode);
		if (projectLog != null) {
			cefCommonService.saveOrUpdateCefProjectProcessLogData(cefProjectCode, projectLog.getChangeProposalCode(),
					projectLog.getChangeProposalExternalId(), status, userEmail);
		}
	}

	/**
	 * Populate Process Log migration status - workflow/ Doc Lib module
	 * 
	 * @param cefProjectCode
	 * @param status
	 * @param userEmail
	 */
	private void populateProcessLogStatusForWorkflow(String cefProjectCode, CefMigrationStatus status,
			String userEmail) {
		CefModuleProcessLog cefModuleLog;

		// Get module logs for doc lib
		cefModuleLog = cefModuleProcessLogRepository.findAllLogsByCefProjectCodeAndModule(cefProjectCode,
				CefModuleName.DOCLIB);

		if (cefModuleLog != null && cefModuleLog.getStatus().equals(CefMigrationStatus.SUCCESS)) {
			populateProcessLogStatus(cefProjectCode, status, userEmail);
		}

	}
	/**
	 * Check Workflow migration status for the project
	 * @param cefProjectCode
	 * @return
	 */
	 private boolean verifyProjectStatus(String cefProjectCode) {
	        boolean migrated = false;
	        CefModuleProcessLog docLibLog = cefModuleProcessLogRepository
	        		.findAllLogsByCefProjectCodeAndModule(cefProjectCode,CefModuleName.WORKFLOW);
	        if (docLibLog != null && (StringUtils.equals(CefMigrationStatus.SUCCESS.name(), docLibLog.getStatus().name()))) {
	            log.debug("Workflow migration is already completed for the project:: {}", cefProjectCode);
	            migrated = true;
	        }
	        return migrated;
	    }
}
