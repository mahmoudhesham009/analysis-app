package gov.uspto.pe2e.cpc.ipc.rest.cef.service;

import java.util.List;
import java.util.Optional;

import javax.annotation.Nonnull;
import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.CefModuleProcessLog;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.CefModuleProcessLogRepository;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.CefMigrationStatus;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.CefModuleName;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.CefProjectMigrationRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.saml.UsptoAuthenticationToken;
import lombok.RequiredArgsConstructor;

/**
 * CEF Migration Retry Service
 * 
 * @author Maximus
 * @version 2.4.0
 * @date: 10/12/2021
 *
 */
@Component
@Service("cefMigrationRetryService")
@RequiredArgsConstructor(onConstructor = @__(@Inject))
public class CefMigrationRetryService {

    private static final Logger log = LoggerFactory.getLogger(CefMigrationRetryService.class);

    @Nonnull
    private ReloadableResourceBundleMessageSource reloadableResourceBundleMessageSource;

    @Nonnull
    private CefModuleProcessLogRepository cefModuleProcessLogRepository;
  
    @Nonnull
    private CefMetadataMigrationService cefMetadataMigrationService;

    @Nonnull
    private CefDocumentLibraryMigrationService cefDocumentLibraryMigrationService;

    @Nonnull
    private CefWorkflowMigrationService cefWorkflowMigrationService;

    /**
     * Retry CEF migration projects
     * 
     * @param cefRequest 
     * @param authToken
     * @return 
     * @throws
     */
    @Transactional
    public void retryCEFMigration(CefProjectMigrationRequest cefRequest, UsptoAuthenticationToken authToken) {

        log.info("Inside retryCEFMigration -- start");
        if (cefRequest.isMigrateAllProjects()) {
            log.info("Inside Retry Migration All Projects -- start");
            retryAllProjects(authToken);
            log.info("Inside Retry Migration All Projects -- end");

        } else if (CollectionUtils.isNotEmpty(cefRequest.getCefProjectCode())) {
            log.info("Inside Retry Migration Individual Projects -- start");
            for (String prjCode : cefRequest.getCefProjectCode()) {
                
                log.debug("Retry Migration Individual Project {} -- started", prjCode);
                List<CefModuleProcessLog> modules = cefModuleProcessLogRepository.findAllLogsByCefProjectCode(prjCode);

                if (CollectionUtils.isNotEmpty(modules)) {

                    retryIndividualProject(authToken, prjCode, modules);
                }
            }
            log.info("Inside Retry Migration Individual Projects -- end");
        }
        log.info("Inside retryCEFMigration -- end");
    }

    /**
     * @param authToken
     * @param prjCode
     * @param modules
     */
    private void retryIndividualProject(UsptoAuthenticationToken authToken, String prjCode,
            List<CefModuleProcessLog> modules) {
        Optional<CefModuleProcessLog> meta = modules.stream().filter(
                modu -> StringUtils.equals(modu.getModuleName().name(), CefModuleName.METADATA.name())
                        && StringUtils.equals(modu.getStatus().name(), CefMigrationStatus.FAILED.name()))
                .findAny();
        if (meta.isPresent()) {
            log.debug("Retry migration started for the Project {} from metatada module", prjCode);
            CefProjectMigrationRequest retryRequest = new CefProjectMigrationRequest();
            retryRequest.setMigrateAllProjects(false);
            retryRequest.getCefProjectCode().add(prjCode);
            // Metadata
            cefMetadataMigrationService.processCefProjects(retryRequest, authToken);
            // Document Library
            cefDocumentLibraryMigrationService.processCefProjectsDocs(retryRequest, authToken);
            // Workflow
            cefWorkflowMigrationService.processCefProjectsWorkflow(retryRequest, authToken);
        } else {
            log.debug("Retry migration started for the individual project {} with out metadata -- started", prjCode);
            Optional<CefModuleProcessLog> doclib = modules.stream().filter(modu -> StringUtils
                    .equals(modu.getModuleName().name(), CefModuleName.DOCLIB.name())
                    && StringUtils.equals(modu.getStatus().name(), CefMigrationStatus.FAILED.name()))
                    .findAny();
            if (doclib.isPresent()) {
                CefProjectMigrationRequest retryRequest = new CefProjectMigrationRequest();
                retryRequest.setMigrateAllProjects(false);
                retryRequest.getCefProjectCode().add(prjCode);
                // Document Library
                cefDocumentLibraryMigrationService.processCefProjectsDocs(retryRequest, authToken);
            }

            Optional<CefModuleProcessLog> workflow = modules.stream().filter(modu -> StringUtils
                    .equals(modu.getModuleName().name(), CefModuleName.WORKFLOW.name())
                    && StringUtils.equals(modu.getStatus().name(), CefMigrationStatus.FAILED.name()))
                    .findAny();
            if (workflow.isPresent()) {
                CefProjectMigrationRequest retryRequest = new CefProjectMigrationRequest();
                retryRequest.setMigrateAllProjects(false);
                retryRequest.getCefProjectCode().add(prjCode);
                // Workflow
                cefWorkflowMigrationService.processCefProjectsWorkflow(retryRequest, authToken);
            }
            
            log.debug("Retry migration started for the individual project {} with out metadata", prjCode);
        }
    }

    /**
     * @param authToken
     */
    private void retryAllProjects(UsptoAuthenticationToken authToken) {
        // Retry metadata module
        List<CefModuleProcessLog> retryProjects = cefModuleProcessLogRepository
                .findAllByCefModuleNameAndStatus(CefModuleName.METADATA, CefMigrationStatus.FAILED);
        if (CollectionUtils.isNotEmpty(retryProjects)) {
            for (CefModuleProcessLog prj : retryProjects) {
                String projectCode = prj.getCefProjectProcessLog().getCefProjectCode();
                log.debug("Retry Migration for the Project {} and MetaData module", projectCode);
                CefProjectMigrationRequest retryRequest = new CefProjectMigrationRequest();
                retryRequest.setMigrateAllProjects(false);
                retryRequest.getCefProjectCode().add(projectCode);
                cefMetadataMigrationService.processCefProjects(retryRequest, authToken);
            }
        }

        // Retry doclib module
        List<CefModuleProcessLog> retryDocProjects = cefModuleProcessLogRepository
                .findAllByCefModuleNameAndStatus(CefModuleName.DOCLIB, CefMigrationStatus.FAILED);
        if (CollectionUtils.isNotEmpty(retryDocProjects)) {
            for (CefModuleProcessLog prj : retryDocProjects) {
                String projectCode = prj.getCefProjectProcessLog().getCefProjectCode();
                log.debug("Retry Migration for the Project {} and Document Library module", projectCode);
                CefProjectMigrationRequest retryRequest = new CefProjectMigrationRequest();
                retryRequest.setMigrateAllProjects(false);
                retryRequest.getCefProjectCode().add(projectCode);
                cefDocumentLibraryMigrationService.processCefProjectsDocs(retryRequest, authToken);
            }
        }

        // Retry workflow module
        List<CefModuleProcessLog> retryWorkflowProjects = cefModuleProcessLogRepository
                .findAllByCefModuleNameAndStatus(CefModuleName.WORKFLOW, CefMigrationStatus.FAILED);
        if (CollectionUtils.isNotEmpty(retryWorkflowProjects)) {
            for (CefModuleProcessLog prj : retryWorkflowProjects) {
                String projectCode = prj.getCefProjectProcessLog().getCefProjectCode();
                log.debug("Retry Migration for the Project {} and WorkFlow module", projectCode);
                CefProjectMigrationRequest retryRequest = new CefProjectMigrationRequest();
                retryRequest.setMigrateAllProjects(false);
                retryRequest.getCefProjectCode().add(projectCode);
                cefWorkflowMigrationService.processCefProjectsWorkflow(retryRequest, authToken);
            }
        }
    }

}
