package gov.uspto.pe2e.cpc.ipc.rest.cef.contract;

public enum CefProjectTypeAndSourceMapping {
	
	DP("CPC","DP-Definition Project"),
	MP("CPC","MP-Maintenance Project"),
	RP("CPC","RP-Revision Project"),
	HP("Bilateral Harmonization (HP/HX)", "HP-Harmonization Project"),
	HX("Bilateral Harmonization (HP/HX)", "HX-Cross Technology" ),
	IA("IPC", "IA"),
	IC("IPC", "IC"),
	ID("IPC", "ID"),	
	IF("IPC", "IF"),
	IM("IPC", "IM"),
	IZ("IPC", "IZ"),
	IQ("IPC", "IQ"),
	IV("IPC", "IV"),
	IW("IPC", "IW"),
	IE("IP5", "IE"),
	IJ("IP5", "IJ"),	
	IP("IP5", "IP"),
	IU("IP5", "IU");

	private final String projectSource;
	private final String projectType;
	
	private CefProjectTypeAndSourceMapping(String projectSource, String projectType) {
		this.projectSource=projectSource;
		this.projectType=projectType;
	}

	public String getProjectSource() {
		return projectSource;
	}

	public String getProjectType() {
		return projectType;
	}
}
