
package gov.uspto.pe2e.cpc.ipc.rest.cef.contract;

import java.util.Date;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

public class CefAnnexes implements Comparable<CefAnnexes> {

   
    protected long projectid;
    
    protected Integer num;
    
    protected String filename;
    
    protected String typefileanx;
    
    protected String officecode;
    
    protected String officename;
    
    protected long planid;
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    protected Date datesend;
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd hh:mm:ss")
    @JsonProperty("created_at")
    protected Date createdAt;
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd hh:mm:ss")
    @JsonProperty("updated_at")
    protected Date updatedAt;

    /**
     * Gets the value of the projectid property.
     * 
     */
    public long getProjectid() {
        return projectid;
    }

    /**
     * Sets the value of the projectid property.
     * 
     */
    public void setProjectid(long value) {
        this.projectid = value;
    }

    /**
     * Gets the value of the num property.
     * 
     */
    public Integer getNum() {
        return num;
    }

    /**
     * Sets the value of the num property.
     * 
     */
    public void setNum(Integer value) {
        this.num = value;
    }

    /**
     * Gets the value of the filename property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFilename() {
        return filename;
    }

    /**
     * Sets the value of the filename property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFilename(String value) {
        this.filename = value;
    }

    /**
     * Gets the value of the typefileanx property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypefileanx() {
        return typefileanx;
    }

    /**
     * Sets the value of the typefileanx property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypefileanx(String value) {
        this.typefileanx = value;
    }

    /**
     * Gets the value of the officecode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOfficecode() {
        return officecode;
    }

    /**
     * Sets the value of the officecode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOfficecode(String value) {
        this.officecode = value;
    }

    /**
     * Gets the value of the officename property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOfficename() {
        return officename;
    }

    /**
     * Sets the value of the officename property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOfficename(String value) {
        this.officename = value;
    }

    /**
     * Gets the value of the planid property.
     * 
     */
    public long getPlanid() {
        return planid;
    }

    /**
     * Sets the value of the planid property.
     * 
     */
    public void setPlanid(long value) {
        this.planid = value;
    }

    /**
     * Gets the value of the datesend property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getDatesend() {
        return datesend;
    }

    /**
     * Sets the value of the datesend property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDatesend(Date value) {
        this.datesend = value;
    }

    /**
     * Gets the value of the createdAt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getCreatedAt() {
        return createdAt;
    }

    /**
     * Sets the value of the createdAt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreatedAt(Date value) {
        this.createdAt = value;
    }

    /**
     * Gets the value of the updatedAt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getUpdatedAt() {
        return updatedAt;
    }

    /**
     * Sets the value of the updatedAt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdatedAt(Date value) {
        this.updatedAt = value;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
    }

    @Override
    public boolean equals(Object that) {
        return EqualsBuilder.reflectionEquals(this, that);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

	@Override
	public int compareTo(CefAnnexes obj) {
		return this.getNum().compareTo(obj.getNum());
	}
}
