package gov.uspto.pe2e.cpc.ipc.rest.cef.util;

/**
 * The Constants class represents a constants defined and used across CEF migration
 * Services
 * 
 * @author Maximus
 * @date Sep 29, 2021
 * @version 2.4.0
 *
 */
public class CefConstants {

    public static final String PROJECT_FILE_NAME = "project.json";
    public static final String PROJECT_ADDITIONAL_FILE_NAME = "AdditionalFields.json";
    public static final String ANNEXES_FILE_NAME="Annexes.json";
    public static final String RAPPORTEUR_SUMMARY_FILE_NAME="RapporteurSummary.json";
    
    //Workflow not required for these project status
    public static final String STATUS_ON_HOLD="On Hold";
    public static final String STATUS_SUSPENDED="Suspended";
    public static final String STATUS_IPC_PHASE="In IPC (IEF) Phase";
    public static final String STATUS_ONGOING="Ongoing";
    public static final String CEF_RECLASS_OFFICE_FIELD_NAME = "Reclassification Office";
    public static final String FAMILY_COUNT_FIELD_NAME = "Number of Families Involved";
    public static final String TECH_US_FIELD_NAME = "Technology - US";
    public static final String TECH_EP_FIELD_NAME= "Technology - EP";
    public static final String SPECIALS_FIELD_NAME = "Specials";
    public static final String NOT_USED_TXT = "not used";
    public static final String RELATED_PROJECT_TXT = "Related IP5/IPC Project";
    
    public static final String CEF_MIGRATION_USER="CEF_MIGRATION";
    public static final String APPROVED_JEB="Approved by JEB";
    public static final String APPROVED_EP_EB="Approved by EPO EB";
    public static final String APPROVED_US_EB="Approved by US EB";
    public static final String APPROVED_US_PC="Approved by US PC";
    public static final String APPROVED_EP_PC="Approved by EPO PC";
    
    //Projects with following type to be skipped
    public static final String CE_PROJECT_TYPE="CE";
    public static final String CM_PROJECT_TYPE="CM";
    public static final String RR_PROJECT_TYPE="RR";
    public static final String PM_PROJECT_TYPE="PM";
    
    public static final String INTENDED_PUB_DATE_TXT = "(Intended) Publication Date";
    public static final String INTENDED_RECLASS_COM_DATE_TXT = "Intended Completion of Reclassification";
    public static final String ACTUAL_PUB_DATE_TEXT = "[Actual] Publication Date";
    public static final String US_COOR_TXT = "Coordinator at US";
    public static final String EP_COOR_TXT = "Coordinator at EP";
    public static final String ACTUAL_FINAL_DATE_TXT = "Actual Finalization Date";
    public static final String RECLASS_FAMILY_NO_TXT = "Number of Families Reclassified so far";
    public static final String ACTIVE_PHASE_START_TXT = "Mature for Promotion Date - EB review (if yes e.g. 01-Nov-16)";
    
    public static final int MAX_STRING_SIZE=3950;
    public static final String CPC_TXT = "CPC";
    public static final String CEF_DATE_FORMAT = "dd-MMM-yy";
    public static final String CE_PD_FORM_DATE_FORMAT = "MMM dd, yyyy";
    public static final String CEF_PUB_DATE_FORMAT = "yyyy.MM";
    public static final String INTENDED_FINAL_DATE_TXT = "Intended Finalization Date";
    public static final String CEF_MIGRATION_REPORT_NAME="CefMigrationStatusReport.csv";
    
    
    /**
     * Constructor - Instantiates a new constants.
     */
    private CefConstants() {
        throw new IllegalAccessError("Constants class");
    }

}
