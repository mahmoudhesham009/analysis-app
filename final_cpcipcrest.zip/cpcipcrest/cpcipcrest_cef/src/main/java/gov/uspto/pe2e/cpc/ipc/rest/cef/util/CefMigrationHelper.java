package gov.uspto.pe2e.cpc.ipc.rest.cef.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

/**
 * This Utility class helps to retrieve the CEF data from server
 * 
 * @author Maximus
 * @date: 09/24/2021
 *
 */
@Service
@NoArgsConstructor
@AllArgsConstructor
public class CefMigrationHelper {
    
    private static final Logger log = LoggerFactory.getLogger(CefMigrationHelper.class);

    // private String cefDataPath="/var/log/cef";

    @Value("${cef_data_path:}")
    private String cefDatapath;

    /**
     * Get List of projects at specified path
     * 
     * @return List<String>
     */
    public List<String> getListOfProjectsAvailable() {
        File projectsDir = new File(cefDatapath);
        List<String> projects = new ArrayList<>();
        if (projectsDir.list()!=null) {
            projects = Arrays.asList(projectsDir.list());
        }
        return projects;
    }

    /**
     * Get list of files available for specified project
     * 
     * @param cefProjectName
     * @return fileNameList
     */
    public List<String> getListOfFileNamesByProject(String cefProjectName) {
        File project = new File(cefDatapath + File.separator + cefProjectName);
        List<String> fileNames = new ArrayList<>();
        if (project.listFiles()!=null) {
            fileNames = Arrays.asList(project.list());
        }
        return fileNames;
    }

    /**
     * Get List of files available for the project
     * 
     * @param cefProjectName
     * @return List<File>
     */
    public List<File> getAllFilesByProjectName(String cefProjectName) {
        File project = new File(cefDatapath + File.separator + cefProjectName);
        List<File> files = new ArrayList<>();
        if (project.listFiles()!=null) {
            files = Arrays.asList(project.listFiles());
        }
        return files;
    }

    /**
     * Get file by name from list of files
     * 
     * @param filesList
     * @param fileName
     * @return File
     */
    public File getProjectFileByName(List<File> filesList, String fileName) {
        File requiredFile = null;
        if (CollectionUtils.isNotEmpty(filesList)) {
            Optional<File> optional = filesList.stream().filter(file -> file.getName().equalsIgnoreCase(fileName))
                    .findFirst();
            if (optional.isPresent()) {
                requiredFile = optional.get();
            }
        }
        return requiredFile;
    }
    
    /**
     * Convert file to multipart file.
     * 
     * @param file
     * @return MultipartFile
     */
    public MultipartFile convertFileToMultipartFile(File file) throws IOException {
        FileItem fileItem = new DiskFileItemFactory().createItem("file", Files.probeContentType(file.toPath()), false,
                file.getName());

        try (InputStream in = new FileInputStream(file); OutputStream out = fileItem.getOutputStream()) {
            IOUtils.copy(in, out);
        } catch (Exception e) {
            throw new IllegalArgumentException("Invalid file: " + e, e);
        }
        return new CommonsMultipartFile(fileItem);
    }

    /**
     * Get file by project name and file name.
     * 
     * @param cefProjectName
     * @param fileName
     * @return File
     */
    public File getFileByProjectName(String cefProjectName, String fileName) {
        File project = new File(cefDatapath + File.separator + cefProjectName);
        List<File> files = new ArrayList<>();
        if (project.listFiles()!=null) {
            files = Arrays.asList(project.listFiles());
        }
        return getProjectFileByName(files, fileName);
    }
    
    /**
     * Get json from Object
     * 
     * @param obj
     * @return String
     */
    public String getJsonFromObject(Object obj) {
        ObjectMapper mapper = new ObjectMapper();
        String json = StringUtils.EMPTY;
        try {
            json = mapper.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            log.error("Error while parsing object to json:: {}", e.getMessage());
        }
        return json;
    }
    
    /**
     * Convert string to date
     * @param dateString
     * @return
     */
    public Date convertStringtoDate(String dateString) {
        Date date = null;
        try {
            date = new SimpleDateFormat(CefConstants.CEF_DATE_FORMAT).parse(dateString);
        } catch (ParseException e) {           
            log.error("Error while parsing string to date:: {}", e.getMessage());
        }
        return date;
    }
    
    /**
     * Convert string to date
     * @param dateString
     * @return
     */
    public Date convertPubStringtoPubDate(String dateString) {
        Date date = null;
        try {
            date = new SimpleDateFormat(CefConstants.CEF_PUB_DATE_FORMAT).parse(dateString);
        } catch (ParseException e) {           
            log.error("Error while parsing publiction date string to date:: {}", e.getMessage());
        }
        return date;
    }
	/**
	 * Handle for cef migration if files are not available on the EC2 instance. 
	 * If directory and files are available for migration, then return true
	 * 
	 * @return boolean
	 */
	public boolean isCefProjectsExistsOnServer() {
		boolean projectsExist=false;
	    File projectsDir = new File(cefDatapath);
	    if(projectsDir.list()!=null){
	    	projectsExist=true;
	    }
	    return projectsExist;
	}
}