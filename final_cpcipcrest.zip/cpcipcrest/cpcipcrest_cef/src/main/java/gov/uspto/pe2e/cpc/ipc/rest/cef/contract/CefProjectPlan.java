
package gov.uspto.pe2e.cpc.ipc.rest.cef.contract;

import java.util.Date;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.w3._2001.xmlschema.Adapter1;
import org.w3._2001.xmlschema.Adapter2;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

public class CefProjectPlan {

    
    protected long id;
    
    protected long projectid;
    
    protected long num;
    
    protected String officename;
    
    protected String officecode;
    
    protected String current;
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    protected Date datetarget;
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd hh:mm:ss")
    @JsonProperty("created_at")
    protected Date createdAt;
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd hh:mm:ss")
    @JsonProperty("updated_at")
    protected Date updatedAt;
    
    protected String actionname;

    /**
     * Gets the value of the id property.
     * 
     */
    public long getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     */
    public void setId(long value) {
        this.id = value;
    }

    /**
     * Gets the value of the projectid property.
     * 
     */
    public long getProjectid() {
        return projectid;
    }

    /**
     * Sets the value of the projectid property.
     * 
     */
    public void setProjectid(long value) {
        this.projectid = value;
    }

    /**
     * Gets the value of the num property.
     * 
     */
    public long getNum() {
        return num;
    }

    /**
     * Sets the value of the num property.
     * 
     */
    public void setNum(long value) {
        this.num = value;
    }

    /**
     * Gets the value of the officename property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOfficename() {
        return officename;
    }

    /**
     * Sets the value of the officename property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOfficename(String value) {
        this.officename = value;
    }

    /**
     * Gets the value of the officecode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOfficecode() {
        return officecode;
    }

    /**
     * Sets the value of the officecode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOfficecode(String value) {
        this.officecode = value;
    }

    /**
     * Gets the value of the current property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrent() {
        return current;
    }

    /**
     * Sets the value of the current property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrent(String value) {
        this.current = value;
    }

    /**
     * Gets the value of the datetarget property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getDatetarget() {
        return datetarget;
    }

    /**
     * Sets the value of the datetarget property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDatetarget(Date value) {
        this.datetarget = value;
    }

    /**
     * Gets the value of the createdAt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getCreatedAt() {
        return createdAt;
    }

    /**
     * Sets the value of the createdAt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreatedAt(Date value) {
        this.createdAt = value;
    }

    /**
     * Gets the value of the updatedAt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getUpdatedAt() {
        return updatedAt;
    }

    /**
     * Sets the value of the updatedAt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdatedAt(Date value) {
        this.updatedAt = value;
    }

    /**
     * Gets the value of the actionname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActionname() {
        return actionname;
    }

    /**
     * Sets the value of the actionname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActionname(String value) {
        this.actionname = value;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
    }

    @Override
    public boolean equals(Object that) {
        return EqualsBuilder.reflectionEquals(this, that);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

}
