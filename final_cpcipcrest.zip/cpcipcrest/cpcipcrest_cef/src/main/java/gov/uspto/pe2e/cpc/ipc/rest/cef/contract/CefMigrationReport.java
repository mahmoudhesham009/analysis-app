package gov.uspto.pe2e.cpc.ipc.rest.cef.contract;

import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.CefMigrationStatus;

public class CefMigrationReport {

	private String cefProjectCode;
	private String ceProjectCode;
	private String guid;
	private CefMigrationStatus status;
	private CefMigrationStatus metadataStatus;
	private String metadataException;
	private String metadataRequest;
	private CefMigrationStatus workflowStatus;
	private String workflowException;
	private String workflowRequest;
	private CefMigrationStatus docLibStatus;
	private String docLibException;
	private String docLibRequest;
	public String getCefProjectCode() {
		return cefProjectCode;
	}
	public void setCefProjectCode(String cefProjectCode) {
		this.cefProjectCode = cefProjectCode;
	}
	public String getCeProjectCode() {
		return ceProjectCode;
	}
	public void setCeProjectCode(String ceProjectCode) {
		this.ceProjectCode = ceProjectCode;
	}
	public String getGuid() {
		return guid;
	}
	public void setGuid(String guid) {
		this.guid = guid;
	}
	public CefMigrationStatus getMetadataStatus() {
		return metadataStatus;
	}
	public void setMetadataStatus(CefMigrationStatus metadataStatus) {
		this.metadataStatus = metadataStatus;
	}
	public String getMetadataException() {
		return metadataException;
	}
	public void setMetadataException(String metadataException) {
		this.metadataException = metadataException;
	}
	public String getMetadataRequest() {
		return metadataRequest;
	}
	public void setMetadataRequest(String metadataRequest) {
		this.metadataRequest = metadataRequest;
	}
	public CefMigrationStatus getWorkflowStatus() {
		return workflowStatus;
	}
	public void setWorkflowStatus(CefMigrationStatus workflowStatus) {
		this.workflowStatus = workflowStatus;
	}
	public String getWorkflowException() {
		return workflowException;
	}
	public void setWorkflowException(String workflowException) {
		this.workflowException = workflowException;
	}
	public String getWorkflowRequest() {
		return workflowRequest;
	}
	public void setWorkflowRequest(String workflowRequest) {
		this.workflowRequest = workflowRequest;
	}
	public CefMigrationStatus getDocLibStatus() {
		return docLibStatus;
	}
	public void setDocLibStatus(CefMigrationStatus docLibStatus) {
		this.docLibStatus = docLibStatus;
	}
	public String getDocLibException() {
		return docLibException;
	}
	public void setDocLibException(String docLibException) {
		this.docLibException = docLibException;
	}
	public String getDocLibRequest() {
		return docLibRequest;
	}
	public void setDocLibRequest(String docLibRequest) {
		this.docLibRequest = docLibRequest;
	}
	
	public CefMigrationStatus getStatus() {
		return status;
	}
	public void setStatus(CefMigrationStatus status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "CefMigrationReport [cefProjectCode=" + cefProjectCode + ", ceProjectCode=" + ceProjectCode + ", guid="
				+ guid + ", status=" + status + ", metadataStatus=" + metadataStatus + ", metadataException="
				+ metadataException + ", metadataRequest=" + metadataRequest + ", workflowStatus=" + workflowStatus
				+ ", workflowException=" + workflowException + ", workflowRequest=" + workflowRequest
				+ ", docLibStatus=" + docLibStatus + ", docLibException=" + docLibException + ", docLibRequest="
				+ docLibRequest + "]";
	}
}
