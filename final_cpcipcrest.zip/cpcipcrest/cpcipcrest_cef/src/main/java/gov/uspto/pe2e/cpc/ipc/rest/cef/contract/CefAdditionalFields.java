
package gov.uspto.pe2e.cpc.ipc.rest.cef.contract;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class CefAdditionalFields {

    protected long projectid;

    protected String fieldname;

    protected String fieldvalue;

    /**
     * Gets the value of the projectid property.
     * 
     */
    public long getProjectid() {
        return projectid;
    }

    /**
     * Sets the value of the projectid property.
     * 
     */
    public void setProjectid(long value) {
        this.projectid = value;
    }

    /**
     * Gets the value of the fieldname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFieldname() {
        return fieldname;
    }

    /**
     * Sets the value of the fieldname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFieldname(String value) {
        this.fieldname = value;
    }

    /**
     * Gets the value of the fieldvalue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFieldvalue() {
        return fieldvalue;
    }

    /**
     * Sets the value of the fieldvalue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFieldvalue(String value) {
        this.fieldvalue = value;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
    }

    @Override
    public boolean equals(Object that) {
        return EqualsBuilder.reflectionEquals(this, that);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

}
