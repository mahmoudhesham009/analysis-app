package gov.uspto.pe2e.cpc.ipc.rest.cef.service;

import java.io.File;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import javax.annotation.Nonnull;
import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.LocalDateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;

import gov.uspto.pe2e.cpc.ipc.rest.cef.contract.CefAdditionalFields;
import gov.uspto.pe2e.cpc.ipc.rest.cef.contract.CefProject;
import gov.uspto.pe2e.cpc.ipc.rest.cef.contract.CefProjectTypeAndSourceMapping;
import gov.uspto.pe2e.cpc.ipc.rest.cef.util.CefConstants;
import gov.uspto.pe2e.cpc.ipc.rest.cef.util.CefMigrationHelper;
import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ExternalSystemCategory;
import gov.uspto.pe2e.cpc.ipc.rest.commons.error.ResourceCheckoutException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.CefProjectProcessLog;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposal;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalAlias;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalDetail;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.CefModuleProcessLogRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.CefProjectProcessLogRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalAliasRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.PersistenceService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.collections.CollectionScanner;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.StandardIpOfficeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.CefMigrationStatus;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.CefModuleName;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.CefProjectMigrationRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProjectSizeCategory;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalCreationRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalDetail;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalFormType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalNamePrefix;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalPageDetail;
import gov.uspto.pe2e.cpc.ipc.rest.contract.saml.UsptoAuthenticationToken;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalDetailsService;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalService;
import lombok.RequiredArgsConstructor;

/**
 * CEF Migration Service - Project metadata
 * 
 * @author Maximus
 * @version 2.3.0
 * @date: 08/30/2021
 *
 */
@Component
@Service("cefMetadataMigrationService")
@RequiredArgsConstructor(onConstructor = @__(@Inject))
public class CefMetadataMigrationService {

	private static final Logger log = LoggerFactory.getLogger(CefMetadataMigrationService.class);
	private static final String PROJECT_NAME_FORMAT = "{0}{1}"; // {type}{sequence}
	private static final String PROJECT_NAME_NUMERIC_FMT = "%05d";

	private static final String CEF_PROJECT_SEQUENCE_NAME = "cef_proposal_number_seq";

	@Nonnull
	private ReloadableResourceBundleMessageSource reloadableResourceBundleMessageSource;

	@Nonnull
	private ProposalService proposalService;

	@Nonnull
	private ProposalDetailsService proposalDetailsService;

	@Nonnull
	private CefProjectProcessLogRepository cefProjectProcessLogRepository;

	@Nonnull
	private CefModuleProcessLogRepository cefModuleProcessLogRepository;

	@Nonnull
	private CefMigrationHelper migrationHelper;

	@Nonnull
	private CefCommonService cefCommonService;

	@Nonnull
	private ChangeProposalRepository changeProposalRepository;

	@Nonnull
	private PersistenceService persistenceService;

	@Nonnull
	private ChangeProposalAliasRepository changeProposalAliasRepository;

	/**
	 * Process CEF projects metadata
	 * 
	 * @param cefRequest
	 * @param authToken
	 * @return
	 * @throws IOException
	 */
	@Transactional
	public void processCefProjects(CefProjectMigrationRequest cefRequest, UsptoAuthenticationToken authToken) {

		log.info("Inside processCefProjects -- start");
		List<String> cefProjects;
		if (cefRequest.isMigrateAllProjects()) {
			cefProjects = migrationHelper.getListOfProjectsAvailable();
		} else {
			cefProjects = cefRequest.getCefProjectCode();
		}

		if (CollectionUtils.isNotEmpty(cefProjects)) {

			for (String cefProjectCode : cefProjects) {
				log.debug("Migration started for the project:: {}", cefProjectCode);

				try {
					File project = migrationHelper.getFileByProjectName(cefProjectCode, CefConstants.PROJECT_FILE_NAME);
					File additional = migrationHelper.getFileByProjectName(cefProjectCode,
							CefConstants.PROJECT_ADDITIONAL_FILE_NAME);

					CefProject cefProject = cefCommonService.mapJsonFileToCefProject(project);
					// Process CEF Migration
					if (cefProject != null && migrationRequired(cefProject) && !verifyProjectStatus(cefProjectCode)) {
						processCEFProjectMigration(cefRequest, authToken, cefProjectCode, additional, cefProject);
					}

				} catch (Exception e) {
					// Update project process log
					cefCommonService.saveOrUpdateCefProjectProcessLogData(cefProjectCode, null, null,
							CefMigrationStatus.FAILED, authToken.getEmail());
					// Update module process log
					cefCommonService.populateCefModuleProcessLog(cefProjectCode, CefMigrationStatus.FAILED,
							migrationHelper.getJsonFromObject(cefRequest), cefCommonService.getStacktraceString(e),
							authToken.getEmail(), CefModuleName.METADATA);
					log.debug("Exception occurred while processing metadata", e);
				}

			}
		}
		log.info("Inside processCefProjects -- end");
	}

	/**
	 * Migrating CEF Project
	 * 
	 * @param cefRequest
	 * @param authToken
	 * @param cefProjectCode
	 * @param additional
	 * @param cefProject
	 * @throws IOException
	 * @throws ResourceCheckoutException
	 */
	private void processCEFProjectMigration(CefProjectMigrationRequest cefRequest, UsptoAuthenticationToken authToken,
			String cefProjectCode, File additional, CefProject cefProject)
			throws IOException, ResourceCheckoutException {

		ProposalCreationRequest request = new ProposalCreationRequest();
		request.setProposalTypeCode(cefProject.getTypecode());
		request.setSize(ProjectSizeCategory.MEDIUM);
		request.setSandbox(false);

		if (EnumUtils.isValidEnum(StandardIpOfficeCode.class, cefProject.getOriginator())) {
			request.setOriginatorOffice(StandardIpOfficeCode.valueOf(cefProject.getOriginator()));
		}

		List<CefAdditionalFields> additionalFields = getCefProjectAdditionalInfo(additional);

		String reclassOffice = populateReclassOffice(additionalFields);
		if (StringUtils.isNotBlank(reclassOffice) && EnumUtils.isValidEnum(StandardIpOfficeCode.class, reclassOffice)) {
			request.setReclassificationOffice(StandardIpOfficeCode.valueOf(reclassOffice));
		}

		UUID id = proposalService.createProposal(request, authToken, true, cefProjectCode);
		String draftName = getNextCEFUniqueInitialProjectName(request.getProposalTypeCode());
		proposalService.convertProposalPrefix(id, draftName, ExternalSystemCategory.CEF, authToken.getEmail());

		// Populating Proposal Details
		List<ProposalDetail> details = new ArrayList<>();
		populateProjectDetails(cefProject, additionalFields, details);

		proposalDetailsService.saveForType(id, ProposalFormType.PROJECT_DETAIL, details, authToken.getEmail());

		// Update project process log
		cefCommonService.saveOrUpdateCefProjectProcessLogData(cefProjectCode, draftName, GUIDUtils.toDatabaseFormat(id),
				CefMigrationStatus.INPROGRESS, authToken.getEmail());

		// Update module process log
		cefCommonService.populateCefModuleProcessLog(cefProjectCode, CefMigrationStatus.SUCCESS,
				migrationHelper.getJsonFromObject(cefRequest), null, authToken.getEmail(), CefModuleName.METADATA);

		log.debug("Migration ended for the project:: {}", cefProjectCode);

	}

	private boolean migrationRequired(CefProject cefProject) {
		boolean isMigrationRequired = true;
		if (StringUtils.isBlank(cefProject.getTypecode())) {
			throw new IllegalArgumentException(
					"Cef project type code does not exist in the project.json file " + cefProject.getPrefix());
		} else if (Arrays.asList("CE", "CM", "RR").contains(StringUtils.upperCase(cefProject.getTypecode()))) {
			isMigrationRequired = false;
		}
		return isMigrationRequired;
	}

	private boolean verifyProjectStatus(String cefProjectCode) {
		boolean migrated = false;
		CefProjectProcessLog processLog = cefProjectProcessLogRepository.findAllByCefProjectCode(cefProjectCode);
		if (processLog != null && (StringUtils.equals(CefMigrationStatus.SUCCESS.name(), processLog.getStatus().name())
				|| StringUtils.equals(CefMigrationStatus.INPROGRESS.name(), processLog.getStatus().name()))) {
			log.debug("Migration is already completed or in-progress for the project:: {}", cefProjectCode);
			migrated = true;
		}
		return migrated;
	}

	private String populateReclassOffice(List<CefAdditionalFields> additionalFields) {
		String reclassOffice = StringUtils.EMPTY;
		if (CollectionUtils.isNotEmpty(additionalFields)) {
			Optional<CefAdditionalFields> reclassOpt = additionalFields.stream()
					.filter(add -> StringUtils.isNotEmpty(add.getFieldname()) && StringUtils
							.equalsIgnoreCase(CefConstants.CEF_RECLASS_OFFICE_FIELD_NAME, add.getFieldname().trim()))
					.findFirst();
			if (reclassOpt.isPresent()
					&& !StringUtils.equalsIgnoreCase(reclassOpt.get().getFieldvalue(), CefConstants.NOT_USED_TXT)) {
				reclassOffice = reclassOpt.get().getFieldvalue();
			}
		}
		return reclassOffice;
	}

	private void populateFamilyCount(List<CefAdditionalFields> additionalFields, List<ProposalDetail> details) {
		if (CollectionUtils.isNotEmpty(additionalFields)) {
			Optional<CefAdditionalFields> opt = additionalFields.stream()
					.filter(add -> StringUtils.isNotEmpty(add.getFieldname()) && StringUtils
							.equalsIgnoreCase(CefConstants.FAMILY_COUNT_FIELD_NAME, add.getFieldname().trim()))
					.findFirst();
			if (opt.isPresent()
					&& !StringUtils.equalsIgnoreCase(opt.get().getFieldvalue(), CefConstants.NOT_USED_TXT)) {
				ProposalDetail familyCountObj = new ProposalDetail();
				familyCountObj.setFormType(ProposalFormType.PROJECT_DETAIL);
				familyCountObj.setItemName("familyCount_PD");
				familyCountObj.setDetails(opt.get().getFieldvalue());
				details.add(familyCountObj);
			}
		}
	}

	private void populateEPPC(List<CefAdditionalFields> additionalFields, List<ProposalDetail> details) {
		if (CollectionUtils.isNotEmpty(additionalFields)) {
			Optional<CefAdditionalFields> opt = additionalFields.stream()
					.filter(add -> StringUtils.isNotEmpty(add.getFieldname())
							&& StringUtils.equalsIgnoreCase(CefConstants.EP_COOR_TXT, add.getFieldname().trim()))
					.findFirst();
			if (opt.isPresent()
					&& !StringUtils.equalsIgnoreCase(opt.get().getFieldvalue(), CefConstants.NOT_USED_TXT)) {
				ProposalDetail eppc = new ProposalDetail();
				eppc.setFormType(ProposalFormType.PROJECT_DETAIL);
				eppc.setItemName("EPPC_PD");
				eppc.setDetails(opt.get().getFieldvalue());
				details.add(eppc);
			}
		}
	}

	private void populateUSPC(List<CefAdditionalFields> additionalFields, List<ProposalDetail> details) {
		if (CollectionUtils.isNotEmpty(additionalFields)) {
			Optional<CefAdditionalFields> opt = additionalFields.stream()
					.filter(add -> StringUtils.isNotEmpty(add.getFieldname())
							&& StringUtils.equalsIgnoreCase(CefConstants.US_COOR_TXT, add.getFieldname().trim()))
					.findFirst();
			if (opt.isPresent()
					&& !StringUtils.equalsIgnoreCase(opt.get().getFieldvalue(), CefConstants.NOT_USED_TXT)) {
				ProposalDetail uspc = new ProposalDetail();
				uspc.setFormType(ProposalFormType.PROJECT_DETAIL);
				uspc.setItemName("coordinatorUS_PD");
				uspc.setDetails(opt.get().getFieldvalue());
				details.add(uspc);
			}
		}
	}

	private void populateProjectLineage(List<CefAdditionalFields> additionalFields, List<ProposalDetail> details) {
		if (CollectionUtils.isNotEmpty(additionalFields)) {
			Optional<CefAdditionalFields> opt = additionalFields.stream()
					.filter(add -> StringUtils.isNotEmpty(add.getFieldname()) && StringUtils
							.equalsIgnoreCase(CefConstants.SPECIALS_FIELD_NAME, add.getFieldname().trim()))
					.findFirst();
			if (opt.isPresent()) {
				ProposalDetail origin = new ProposalDetail();
				origin.setFormType(ProposalFormType.PROJECT_DETAIL);
				origin.setItemName("projectLineage_PD");

				if (Arrays.asList("C-Sets", CefConstants.NOT_USED_TXT).contains(opt.get().getFieldvalue().trim())) {
					origin.setDetails(CefConstants.CPC_TXT);
				} else if (EnumUtils.isValidEnum(CefSpecials.class, opt.get().getFieldvalue())) {
					origin.setDetails(CefSpecials.valueOf(opt.get().getFieldvalue()).getSpec());
				} else {
					origin.setDetails(opt.get().getFieldvalue());
				}
				details.add(origin);
			}
		}
	}

	private void populateRelatedProject(List<CefAdditionalFields> additionalFields, List<ProposalDetail> details) {
		if (CollectionUtils.isNotEmpty(additionalFields)) {
			Optional<CefAdditionalFields> opt = additionalFields.stream()
					.filter(add -> StringUtils.isNotEmpty(add.getFieldname()) && StringUtils
							.equalsIgnoreCase(CefConstants.RELATED_PROJECT_TXT, add.getFieldname().trim()))
					.findFirst();
			if (opt.isPresent()
					&& !StringUtils.equalsIgnoreCase(opt.get().getFieldvalue(), CefConstants.NOT_USED_TXT)) {
				ProposalDetail origin = new ProposalDetail();
				origin.setFormType(ProposalFormType.PROJECT_DETAIL);
				origin.setItemName("relatedProjectsReportedByUser_PD");
				origin.setDetails(opt.get().getFieldvalue());
				details.add(origin);
			}
		}
	}

	private void populateReleaseIntendedDate(List<CefAdditionalFields> additionalFields, List<ProposalDetail> details) {
		if (CollectionUtils.isNotEmpty(additionalFields)) {
			Optional<CefAdditionalFields> opt = additionalFields.stream()
					.filter(add -> StringUtils.isNotEmpty(add.getFieldname()) && StringUtils
							.equalsIgnoreCase(CefConstants.INTENDED_PUB_DATE_TXT, add.getFieldname().trim()))
					.findFirst();
			if (opt.isPresent()
					&& !StringUtils.equalsIgnoreCase(opt.get().getFieldvalue(), CefConstants.NOT_USED_TXT)) {
				ProposalDetail releaseEstimate = new ProposalDetail();
				releaseEstimate.setFormType(ProposalFormType.PROJECT_DETAIL);
				releaseEstimate.setItemName("releaseDateEstimated_PD");
				Date intendedDate = null;
				if (opt.get().getFieldvalue().length() > 7) {
					intendedDate = migrationHelper.convertStringtoDate(opt.get().getFieldvalue());
				} else {
					intendedDate = migrationHelper.convertPubStringtoPubDate(opt.get().getFieldvalue());
				}
				releaseEstimate
						.setDetails(new LocalDateTime(intendedDate).toString(CefConstants.CE_PD_FORM_DATE_FORMAT));
				details.add(releaseEstimate);
			}
		}
	}

	private void populateReclassCompleteIntendedDate(List<CefAdditionalFields> additionalFields,
			List<ProposalDetail> details) {
		if (CollectionUtils.isNotEmpty(additionalFields)) {
			Optional<CefAdditionalFields> opt = additionalFields.stream()
					.filter(add -> StringUtils.isNotEmpty(add.getFieldname()) && StringUtils
							.equalsIgnoreCase(CefConstants.INTENDED_RECLASS_COM_DATE_TXT, add.getFieldname().trim()))
					.findFirst();
			if (opt.isPresent()
					&& !StringUtils.equalsIgnoreCase(opt.get().getFieldvalue(), CefConstants.NOT_USED_TXT)) {
				ProposalDetail reclassCompletion = new ProposalDetail();
				reclassCompletion.setFormType(ProposalFormType.PROJECT_DETAIL);
				reclassCompletion.setItemName("reclassCompletionDateEstimated_PD");
				Date date = migrationHelper.convertStringtoDate(opt.get().getFieldvalue());
				reclassCompletion.setDetails(new LocalDateTime(date).toString(CefConstants.CE_PD_FORM_DATE_FORMAT));
				details.add(reclassCompletion);
			}
		}
	}

	private void populateActualPubicationDate(List<CefAdditionalFields> additionalFields,
			List<ProposalDetail> details) {
		if (CollectionUtils.isNotEmpty(additionalFields)) {
			Optional<CefAdditionalFields> opt = additionalFields.stream()
					.filter(add -> StringUtils.isNotEmpty(add.getFieldname()) && StringUtils
							.equalsIgnoreCase(CefConstants.ACTUAL_PUB_DATE_TEXT, add.getFieldname().trim()))
					.findFirst();
			if (opt.isPresent()
					&& !StringUtils.equalsIgnoreCase(opt.get().getFieldvalue(), CefConstants.NOT_USED_TXT)) {
				ProposalDetail release = new ProposalDetail();
				release.setFormType(ProposalFormType.PROJECT_DETAIL);
				release.setItemName("releaseDate_PD");
				Date pubDate = null;
				if (opt.get().getFieldvalue().length() > 7) {
					pubDate = migrationHelper.convertStringtoDate(opt.get().getFieldvalue());
				} else {
					pubDate = migrationHelper.convertPubStringtoPubDate(opt.get().getFieldvalue());
				}

				release.setDetails(new LocalDateTime(pubDate).toString(CefConstants.CE_PD_FORM_DATE_FORMAT));
				details.add(release);
			}
		}
	}

	private void populateUSTechnology(List<CefAdditionalFields> additionalFields, List<ProposalDetail> details) {
		if (CollectionUtils.isNotEmpty(additionalFields)) {
			Optional<CefAdditionalFields> opt = additionalFields.stream()
					.filter(add -> StringUtils.isNotEmpty(add.getFieldname())
							&& StringUtils.equalsIgnoreCase(CefConstants.TECH_US_FIELD_NAME, add.getFieldname().trim()))
					.findFirst();
			if (opt.isPresent() && !StringUtils.equalsIgnoreCase(opt.get().getFieldvalue(), CefConstants.NOT_USED_TXT)
					&& EnumUtils.isValidEnum(USTechnology.class, opt.get().getFieldvalue())) {
				ProposalDetail usTech = new ProposalDetail();
				usTech.setFormType(ProposalFormType.PROJECT_DETAIL);
				usTech.setItemName("usTechnology_PD");
				usTech.setDetails(USTechnology.valueOf(opt.get().getFieldvalue()).getTech());
				details.add(usTech);
			}
		}
	}

	private void populateEPTechnology(List<CefAdditionalFields> additionalFields, List<ProposalDetail> details) {
		if (CollectionUtils.isNotEmpty(additionalFields)) {
			Optional<CefAdditionalFields> opt = additionalFields.stream()
					.filter(add -> StringUtils.isNotEmpty(add.getFieldname())
							&& StringUtils.equalsIgnoreCase(CefConstants.TECH_EP_FIELD_NAME, add.getFieldname().trim()))
					.findFirst();
			if (opt.isPresent() && !StringUtils.equalsIgnoreCase(opt.get().getFieldvalue(), CefConstants.NOT_USED_TXT)
					&& EnumUtils.isValidEnum(EPTechnology.class, opt.get().getFieldvalue())) {
				ProposalDetail epTech = new ProposalDetail();
				epTech.setFormType(ProposalFormType.PROJECT_DETAIL);
				epTech.setItemName("epTechnology_PD");
				epTech.setDetails(EPTechnology.valueOf(opt.get().getFieldvalue()).getTech());
				details.add(epTech);
			}
		}
	}

	private void populateIntendedFinalizationDate(List<CefAdditionalFields> additionalFields,
			List<ProposalDetail> details) {
		if (CollectionUtils.isNotEmpty(additionalFields)) {
			Optional<CefAdditionalFields> opt = additionalFields.stream()
					.filter(add -> StringUtils.isNotEmpty(add.getFieldname()) && StringUtils
							.equalsIgnoreCase(CefConstants.INTENDED_FINAL_DATE_TXT, add.getFieldname().trim()))
					.findFirst();
			if (opt.isPresent()
					&& !StringUtils.equalsIgnoreCase(opt.get().getFieldvalue(), CefConstants.NOT_USED_TXT)) {
				ProposalDetail activePhase = new ProposalDetail();
				activePhase.setFormType(ProposalFormType.PROJECT_DETAIL);
				activePhase.setItemName("projectFinalizationDate_PD");
				Date date = migrationHelper.convertStringtoDate(opt.get().getFieldvalue());
				activePhase.setDetails(new LocalDateTime(date).toString(CefConstants.CE_PD_FORM_DATE_FORMAT));
				details.add(activePhase);
			}
		}
	}

	private void populateActualFinalizationDate(List<CefAdditionalFields> additionalFields,
			List<ProposalDetail> details) {
		if (CollectionUtils.isNotEmpty(additionalFields)) {
			Optional<CefAdditionalFields> opt = additionalFields.stream()
					.filter(add -> StringUtils.isNotEmpty(add.getFieldname()) && StringUtils
							.equalsIgnoreCase(CefConstants.ACTUAL_FINAL_DATE_TXT, add.getFieldname().trim()))
					.findFirst();
			if (opt.isPresent()
					&& !StringUtils.equalsIgnoreCase(opt.get().getFieldvalue(), CefConstants.NOT_USED_TXT)) {
				ProposalDetail activePhase = new ProposalDetail();
				activePhase.setFormType(ProposalFormType.PROJECT_DETAIL);
				activePhase.setItemName("projectFinalizationDateActual_PD");
				Date date = migrationHelper.convertStringtoDate(opt.get().getFieldvalue());
				activePhase.setDetails(new LocalDateTime(date).toString(CefConstants.CE_PD_FORM_DATE_FORMAT));
				details.add(activePhase);
			}
		}
	}

	private void populateReclassFamilyCount(List<CefAdditionalFields> additionalFields, List<ProposalDetail> details) {
		if (CollectionUtils.isNotEmpty(additionalFields)) {
			Optional<CefAdditionalFields> opt = additionalFields.stream()
					.filter(add -> StringUtils.isNotEmpty(add.getFieldname()) && StringUtils
							.equalsIgnoreCase(CefConstants.RECLASS_FAMILY_NO_TXT, add.getFieldname().trim()))
					.findFirst();
			if (opt.isPresent()
					&& !StringUtils.equalsIgnoreCase(opt.get().getFieldvalue(), CefConstants.NOT_USED_TXT)) {
				ProposalDetail activePhase = new ProposalDetail();
				activePhase.setFormType(ProposalFormType.PROJECT_DETAIL);
				activePhase.setItemName("totalFamilyReclassCount_PD");
				activePhase.setDetails(opt.get().getFieldvalue());
				details.add(activePhase);
			}
		}
	}

	

	/**
	 * @param additionalFields
	 * @param details
	 */
	private void populateActivePhaseStartDate(List<CefAdditionalFields> additionalFields,
			List<ProposalDetail> details) {
		if (CollectionUtils.isNotEmpty(additionalFields)) {
			Optional<CefAdditionalFields> opt = additionalFields.stream()
					.filter(add -> StringUtils.isNotEmpty(add.getFieldname()) && StringUtils
							.equalsIgnoreCase(CefConstants.ACTIVE_PHASE_START_TXT, add.getFieldname().trim()))
					.findFirst();
			if (opt.isPresent()
					&& !StringUtils.equalsIgnoreCase(opt.get().getFieldvalue(), CefConstants.NOT_USED_TXT)) {
				ProposalDetail activePhase = new ProposalDetail();
				activePhase.setFormType(ProposalFormType.PROJECT_DETAIL);
				activePhase.setItemName("projectActivePhaseStartDate_PD");

				Date date = migrationHelper.convertStringtoDate(opt.get().getFieldvalue());
				activePhase.setDetails(new LocalDateTime(date).toString(CefConstants.CE_PD_FORM_DATE_FORMAT));
				details.add(activePhase);
			}
		}
	}

	/**
	 * Map AdditionalFields.json file to CefAdditionalFields object
	 * 
	 * @param file
	 * @return List<CefAdditionalFields>
	 * @throws IOException
	 */
	private List<CefAdditionalFields> getCefProjectAdditionalInfo(File file) throws IOException {
		log.info("Inside getCefProjectAdditionalInfo -- start");
		List<CefAdditionalFields> additionalFields = new ArrayList<>();

		if (file != null) {
			additionalFields = Arrays.asList(new ObjectMapper().readValue(file, CefAdditionalFields[].class));
		}
		log.info("Inside getCefProjectAdditionalInfo -- end");
		return additionalFields;
	}

	/**
	 * Populate Project Details
	 * 
	 * @param cefProject
	 * @param additional
	 * @param details
	 * @return
	 */
	private void populateProjectDetails(CefProject cefProject, List<CefAdditionalFields> additionalFields,
			List<ProposalDetail> details) {

		if (StringUtils.isNotBlank(cefProject.getPrefix())
				&& !StringUtils.equalsIgnoreCase(cefProject.getPrefix(), CefConstants.NOT_USED_TXT)) {
			ProposalDetail cefPrjName = new ProposalDetail();
			cefPrjName.setFormType(ProposalFormType.PROJECT_DETAIL);
			cefPrjName.setItemName("cefProject_PD");
			cefPrjName.setDetails(cefProject.getPrefix());
			details.add(cefPrjName);
		}

		if (StringUtils.isNotBlank(cefProject.getName())
				&& !StringUtils.equalsIgnoreCase(cefProject.getName(), CefConstants.NOT_USED_TXT)) {
			ProposalDetail subject = new ProposalDetail();
			subject.setFormType(ProposalFormType.PROJECT_DETAIL);
			subject.setItemName("subject_PD");
			subject.setDetails(cefProject.getName());
			details.add(subject);
		}

		if (StringUtils.isNotBlank(cefProject.getIpc())
				&& !StringUtils.equalsIgnoreCase(cefProject.getIpc(), CefConstants.NOT_USED_TXT)) {
			ProposalDetail manualCpc = new ProposalDetail();
			manualCpc.setFormType(ProposalFormType.PROJECT_DETAIL);
			manualCpc.setItemName("cpcScopeManual_PD");
			manualCpc.setDetails(cefProject.getIpc());
			details.add(manualCpc);
		}

		if (StringUtils.isNotBlank(cefProject.getOriginator())
				&& !StringUtils.equalsIgnoreCase(cefProject.getOriginator(), CefConstants.NOT_USED_TXT)) {
			ProposalDetail requestingOffice = new ProposalDetail();
			requestingOffice.setFormType(ProposalFormType.PROJECT_DETAIL);
			requestingOffice.setItemName("requestingOffice_PD");
			requestingOffice.setDetails(cefProject.getOriginator());
			details.add(requestingOffice);
		}

		if (StringUtils.isNotBlank(cefProject.getRapporteur())
				&& !StringUtils.equalsIgnoreCase(cefProject.getRapporteur(), CefConstants.NOT_USED_TXT)) {
			ProposalDetail rapporteurOffice = new ProposalDetail();
			rapporteurOffice.setFormType(ProposalFormType.PROJECT_DETAIL);
			rapporteurOffice.setItemName("rapporteurOffice_PD");
			rapporteurOffice.setDetails(cefProject.getRapporteur());
			details.add(rapporteurOffice);
		}

		if (StringUtils.isNotBlank(cefProject.getTechcode())
				&& !StringUtils.equalsIgnoreCase(cefProject.getTechcode(), CefConstants.NOT_USED_TXT)
				&& EnumUtils.isValidEnum(BLTechnology.class, cefProject.getTechcode())) {
			ProposalDetail rapporteurOffice = new ProposalDetail();
			rapporteurOffice.setFormType(ProposalFormType.PROJECT_DETAIL);
			rapporteurOffice.setItemName("bilateralTechnology_PD");
			rapporteurOffice.setDetails(BLTechnology.valueOf(cefProject.getTechcode()).getTech());
			details.add(rapporteurOffice);
		}

		String reclassOfficeCode = populateReclassOffice(additionalFields);
		if (StringUtils.isNotBlank(reclassOfficeCode)
				&& EnumUtils.isValidEnum(StandardIpOfficeCode.class, reclassOfficeCode)) {
			ProposalDetail reclassOffice = new ProposalDetail();
			reclassOffice.setFormType(ProposalFormType.PROJECT_DETAIL);
			reclassOffice.setItemName("reclassificationOffice_PD");
			reclassOffice.setDetails(reclassOfficeCode);
			details.add(reclassOffice);
		}

		if (StringUtils.isNotBlank(cefProject.getTypecode())
				&& EnumUtils.isValidEnum(CefProjectTypeAndSourceMapping.class, cefProject.getTypecode())) {

			ProposalDetail projectSource = new ProposalDetail();
			projectSource.setFormType(ProposalFormType.PROJECT_DETAIL);
			projectSource.setItemName("projectSource_PD");
			projectSource
					.setDetails(CefProjectTypeAndSourceMapping.valueOf(cefProject.getTypecode()).getProjectSource());
			details.add(projectSource);

			ProposalDetail projectType = new ProposalDetail();
			projectType.setFormType(ProposalFormType.PROJECT_DETAIL);
			projectType.setItemName("projectType_PD");
			projectType.setDetails(CefProjectTypeAndSourceMapping.valueOf(cefProject.getTypecode()).getProjectType());
			details.add(projectType);
		}

		if (cefProject.getCreatedAt() != null) {
			ProposalDetail projectType = new ProposalDetail();
			projectType.setFormType(ProposalFormType.PROJECT_DETAIL);
			projectType.setItemName("cefProjectCreationDate_PD");
			projectType.setDetails(
					new LocalDateTime(cefProject.getCreatedAt()).toString(CefConstants.CE_PD_FORM_DATE_FORMAT));
			details.add(projectType);
		}

		if (cefProject.getUpdatedAt() != null) {
			ProposalDetail projectType = new ProposalDetail();
			projectType.setFormType(ProposalFormType.PROJECT_DETAIL);
			projectType.setItemName("cefProectLastUpdateDate_PD");
			projectType.setDetails(
					new LocalDateTime(cefProject.getUpdatedAt()).toString(CefConstants.CE_PD_FORM_DATE_FORMAT));
			details.add(projectType);
		}

		// Family Count
		populateFamilyCount(additionalFields, details);
		// EP PC
		populateEPPC(additionalFields, details);
		// US PC
		populateUSPC(additionalFields, details);
		// Project Lineage
		populateProjectLineage(additionalFields, details);
		// Related Project
		populateRelatedProject(additionalFields, details);
		// Release Intended Date
		populateReleaseIntendedDate(additionalFields, details);
		// Intended reclass completion Date
		populateReclassCompleteIntendedDate(additionalFields, details);
		// Actual Publication Date
		populateActualPubicationDate(additionalFields, details);
		// US Technology
		populateUSTechnology(additionalFields, details);
		// EP Technology
		populateEPTechnology(additionalFields, details);
		// Intended Finalization Date
		populateIntendedFinalizationDate(additionalFields, details);
		// Actual Finalization Date
		populateActualFinalizationDate(additionalFields, details);
		// Reclass Family Count
		populateReclassFamilyCount(additionalFields, details);
		// Active Phase Start Date
		populateActivePhaseStartDate(additionalFields, details);

	}

	private String getNextCEFUniqueInitialProjectName(String proposalTypeCode) {
		boolean isDraftNameUnique = false;
		String draftName = getCefInitialName(proposalTypeCode);
		while (!isDraftNameUnique) {
			ChangeProposalAlias cpDraft = changeProposalAliasRepository.findByChangeProposalCodeIgnoreCase(draftName,
					ExternalSystemCategory.CEF);
			if (cpDraft != null && cpDraft.getName().equalsIgnoreCase(draftName)) {
				draftName = getCefInitialName(proposalTypeCode);
			} else {
				isDraftNameUnique = true;
			}
		}
		return draftName;
	}

	private String getCefInitialName(String proposalTypeCode) {
		String draftName = MessageFormat.format(PROJECT_NAME_FORMAT,
				CollectionScanner.coalesce(proposalTypeCode, ProposalNamePrefix.XX.name()), String.format(
						PROJECT_NAME_NUMERIC_FMT, persistenceService.getNextSequenceValue(CEF_PROJECT_SEQUENCE_NAME)));
		log.debug("returning {} as initial name", draftName);
		return draftName;
	}

	public enum USTechnology {

		C("Chemistry"), M("Mechanical"), E("Electricity"), T("Technology Independent");

		private final String tech;

		private USTechnology(String tech) {
			this.tech = tech;
		}

		/**
		 * Get US technology
		 * 
		 * @return Technology
		 */
		public String getTech() {
			return tech;
		}

	}

	public enum EPTechnology {

		C("HBC- Healthcare, Biotech, Chemistry"), M("M&M- Mobility & Mechatronics"),
		E("ICT- Information & Communication Tech"), T("Technology Independent");

		private final String tech;

		private EPTechnology(String tech) {
			this.tech = tech;
		}

		/**
		 * Get EP technology
		 * 
		 * @return Technology
		 */
		public String getTech() {
			return tech;
		}

	}

	public enum BLTechnology {
		C("Chemistry"), M("Mechanics"), E("Electricity-Physics"), T("Technology-Independent");

		private final String tech;

		private BLTechnology(String tech) {
			this.tech = tech;
		}

		/**
		 * Get BL technology
		 * 
		 * @return Technology
		 */
		public String getTech() {
			return tech;
		}

	}

	public enum CefSpecials {
		IPC2014("IPC2014"), IPC2015("IPC2015"), IPC2016("IPC2016"), IPC2017("IPC2017"), IPC2018("IPC2018"),
		IPC2019("IPC2019"), IPC2020("IPC2020"), IPC2021("IPC2021"), IPC2022("IPC2022"), SERCO("CPC"), Y02("CPC"),
		Y10T("CPC");

		private final String spec;

		private CefSpecials(String spec) {
			this.spec = spec;
		}

		/**
		 * Get CE Mapping
		 * 
		 * @return Specials
		 */
		public String getSpec() {
			return spec;
		}
	}

}
