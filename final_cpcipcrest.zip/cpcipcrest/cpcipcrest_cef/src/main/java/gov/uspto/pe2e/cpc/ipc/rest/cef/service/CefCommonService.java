package gov.uspto.pe2e.cpc.ipc.rest.cef.service;

import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.Nonnull;
import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections4.IterableUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Splitter;
import com.google.common.collect.Range;

import gov.uspto.pe2e.cpc.ipc.rest.cef.contract.CefProject;
import gov.uspto.pe2e.cpc.ipc.rest.cef.util.CefConstants;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.CefModuleProcessLog;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.CefProjectProcessLog;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ApplicationConfigRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.CefModuleProcessLogRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.CefProjectProcessLogRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.PersistenceService;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.CefMigrationStatus;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.CefModuleName;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.CefProjectMigrationRequest;
import lombok.RequiredArgsConstructor;

/**
 * Service for processing audit log and other common operations performed by cef modules
 * @author Maximus
 * @version 1.0
 * @date: 08/30/2021
 *
 */
@Service
@RequiredArgsConstructor(onConstructor = @__(@Inject))
public class CefCommonService {

	private static final Logger log = LoggerFactory.getLogger(CefCommonService.class);
	private static final long CEF_CRON_FREQUENCY_IN_MILISEC=300000;
	private static final String CEF_SCHEDULER_COMPLETE_STATUS = "Completed";
	private static final String EST_ZONE = "America/New_York";
	private static final String MIGRATION_EMAIL_ID="cpccollaborationsupport@uspto.gov";
	private static final String MIGRATION_USER="cpccollaborationsupport";
	
    @Nonnull
    private CefProjectProcessLogRepository cefProjectProcessLogRepository;
    
    @Nonnull
    private CefModuleProcessLogRepository cefModuleProcessLogRepository;
    
	@Nonnull
	private ApplicationConfigRepository applicationConfigRepo;
    
    /**
     * populate CEF module process log data for workflow
     * @param cefProjectName
     * @param status
     * @param request
     * @param exception
     * @param userEmail
     */ 
    @Transactional
    public void populateCefModuleProcessLog(String cefProjectName, CefMigrationStatus status
    		, String request, String exception,String userEmail, CefModuleName moduleName) {
    	log.info("Inside populateCefModuleProcessLog -- start");
    	Date now = new Date();
    	CefModuleProcessLog moduleLog=cefModuleProcessLogRepository.findAllLogsByCefProjectCodeAndModule(cefProjectName, moduleName);
    	CefProjectProcessLog projectLog=cefProjectProcessLogRepository.findAllByCefProjectCode(cefProjectName);    	
    	if(moduleLog==null) {
    		moduleLog= new CefModuleProcessLog();    		
    		moduleLog.setCefProjectProcessLog(projectLog);
    		moduleLog.setModuleName(moduleName);
    		moduleLog.setCreateTs(now);
    		moduleLog.setCreateUserId(userEmail);
    		moduleLog.setLockControl(PersistenceService.INITIAL_LOCK_CONTROL);
    	}
		if(StringUtils.isNotEmpty(request)) {
			moduleLog.setRequest(request);
		}
		if(StringUtils.isNotEmpty(exception)) {
			moduleLog.setException(exception);
		}
		else {
			moduleLog.setException(" ");
		}
		moduleLog.setStatus(status);
		moduleLog.setLastModifiedTs(now);
		moduleLog.setLastModifiedUserId(userEmail);
		
    	cefModuleProcessLogRepository.save(moduleLog);
    	log.info("Inside populateCefModuleProcessLog -- end");
    }
    /**
     * check if cef metadata migration is successful
     * @param cefProjectName
     * @return
     */
    @Transactional
    public boolean isCefMetadataProcessedSuccessfully(String cefProjectName) {
    	log.info("Inside isCefMetadataProcessedSuccessfully -- start");
    	boolean isMetaDataMigrated=false;
    	
    	CefModuleProcessLog cefModuleLog=
    			cefModuleProcessLogRepository.findAllLogsByCefProjectCodeAndModule(cefProjectName,CefModuleName.METADATA);
    	
    	if(cefModuleLog!=null) {
    		isMetaDataMigrated=cefModuleLog.getStatus().equals(CefMigrationStatus.SUCCESS);
    	}
    	log.info("Inside isCefMetadataProcessedSuccessfully -- end");
    	return isMetaDataMigrated;
    }
    /**
     * Map project.json file to CefProject
     * @param projectJsonFile
     * @return
     * @throws JsonParseException
     * @throws JsonMappingException
     * @throws IOException
     */
    public CefProject mapJsonFileToCefProject(File projectJsonFile) throws JsonParseException, JsonMappingException, IOException {
    	CefProject cefProject=null;
    	CefProject[] cefProjectArray = new ObjectMapper().readValue(projectJsonFile, CefProject[].class);
    	if(ArrayUtils.isNotEmpty(cefProjectArray)) {
    		cefProject=cefProjectArray[0];
    	}
    	return cefProject;
    }
    /**
     * Check if project needs to be migrated
     * @param projectCode
     * @return
     */
    public boolean isSkipForMigration(CefProject cefProject) {
    	log.info("Inside isSkipForMigration -- start");
    	boolean skipProject=false;     	
	    	if(StringUtils.isBlank(cefProject.getTypecode())
	    			|| cefProject.getTypecode().trim().equalsIgnoreCase(CefConstants.CE_PROJECT_TYPE)
	    			|| cefProject.getTypecode().trim().equalsIgnoreCase(CefConstants.CM_PROJECT_TYPE)
	    			|| cefProject.getTypecode().trim().equalsIgnoreCase(CefConstants.RR_PROJECT_TYPE)) {
	    		skipProject=true;
	    	}
    	log.info("Inside isSkipForMigration -- end");
    	return skipProject;
    }
    
    /**
     * Get Stacktrace String with limit
     * @param e
     * @return
     */
    public String getStacktraceString(Exception e) {
    	String stacktrace = ExceptionUtils.getStackTrace(e);
    	//Get only max allowed string
        if (stacktrace.length() > CefConstants.MAX_STRING_SIZE) {
            return StringUtils.substring(stacktrace, 0, CefConstants.MAX_STRING_SIZE);
        } else {
            return stacktrace;
        }
    }
       
    /**
     * Populate CEF project process log data
     * 
     * @param cefProposalCode
     * @param changeProposalCode
     * @param externalId
     * @param status
     * @param userEmail
     */ 
    @Transactional
    public CefProjectProcessLog saveOrUpdateCefProjectProcessLogData(String cefProposalCode, String changeProposalCode,
            String externalId, CefMigrationStatus status, String userEmail) {

        Date now = new Date();
        CefProjectProcessLog projectLog = cefProjectProcessLogRepository.findAllByCefProjectCode(cefProposalCode);

        if (projectLog == null) {
            projectLog = new CefProjectProcessLog();
            projectLog.setCefProjectCode(cefProposalCode);
            projectLog.setCreateTs(now);
            projectLog.setCreateUserId(userEmail);
            projectLog.setLockControl(PersistenceService.INITIAL_LOCK_CONTROL);
        }

        if (StringUtils.isNotEmpty(changeProposalCode)) {
            projectLog.setChangeProposalCode(changeProposalCode);
        }
        if (StringUtils.isNotEmpty(externalId)) {
            projectLog.setChangeProposalExternalId(externalId);
        }
        projectLog.setStatus(status);
        projectLog.setLastModifiedTs(now);
        projectLog.setLastModifiedUserId(userEmail);

        return cefProjectProcessLogRepository.save(projectLog);
    }
    /**
     * Get list of project to be migrated from DB
     * @return List<String>
     */
	@Transactional
	public List<String> getListofProjectsToBeMigratedFromDB(CefModuleName filterModule) {
		List<String> projectCodes = new ArrayList<>();

		List<CefProjectProcessLog> projectLog = cefProjectProcessLogRepository.findAll();
		List<CefModuleProcessLog> excludeProjects = cefModuleProcessLogRepository
				.findAllLogsByCefModuleNameAndStatus(filterModule, CefMigrationStatus.SUCCESS);
		if (CollectionUtils.isNotEmpty(projectLog)) {
			if (CollectionUtils.isNotEmpty(excludeProjects)) {
				List<String> filteredProjects = projectLog.stream().map(proj -> proj.getCefProjectCode())
						.filter(projCode -> !excludeProjects.stream()
								.map(p -> p.getCefProjectProcessLog().getCefProjectCode()).collect(Collectors.toSet())
								.contains(projCode))
						.collect(Collectors.toList());
				if (CollectionUtils.isNotEmpty(filteredProjects)) {
					projectCodes.addAll(filteredProjects);
				}
			} else {
				projectCodes
						.addAll(projectLog.stream().map(proj -> proj.getCefProjectCode()).collect(Collectors.toList()));
			}
		}
		return projectCodes;
	}
	/**
	 * Check if cef migration job can be started
	 * @param currentTs
	 * @return
	 */
	@Transactional
	public boolean isStartMigration(Timestamp currentTs) {
		boolean startJob=false;
		
		String scheduleTsStr=applicationConfigRepo.getCefMigrationScheduleDateTime();
		if(StringUtils.isNotBlank(scheduleTsStr)) {
			Timestamp scheduleTs=Timestamp.valueOf(scheduleTsStr);
			long timeDiff=scheduleTs.getTime()-currentTs.getTime();
			
			Range<Long> range = Range.closed(-CEF_CRON_FREQUENCY_IN_MILISEC, CEF_CRON_FREQUENCY_IN_MILISEC);
					
			if(range.contains(timeDiff)) {
				startJob=true;
			}
		}
		return startJob;
	}

	/**
	 * Check if cef retry job can be started
	 * @param currentTs
	 * @return
	 */
	@Transactional
	public boolean isRetryMigration(Timestamp currentTs) {
		boolean startJob=false;
		
		String scheduleTsStr=applicationConfigRepo.getCefRetryMigrationScheduleDateTime();
		if(StringUtils.isNotBlank(scheduleTsStr)) {
			Timestamp scheduleTs=Timestamp.valueOf(scheduleTsStr);
			long timeDiff=scheduleTs.getTime()-currentTs.getTime();
			
			Range<Long> range = Range.closed(-CEF_CRON_FREQUENCY_IN_MILISEC, CEF_CRON_FREQUENCY_IN_MILISEC);
					
			if(range.contains(timeDiff)) {
				startJob=true;
			}
		}
		return startJob;
	}
	/**
	 * Get cef migration scheduler status
	 * 
	 * @return String
	 */
	@Transactional
	public String cefMigrationSchedulerStatus() {
		return applicationConfigRepo.getCefMigrationSchedularStatus();
	}
	
	/**
	 * Get cef retry scheduler status
	 * 
	 * @return String
	 */
	@Transactional
	public String cefRetrySchedulerStatus() {
		return applicationConfigRepo.getCefRetrySchedularStatus();
	}

	/**
	 * Get cef migration request for scheduler from Application_Config table
	 * 
	 * @return request
	 */
	@Transactional
	public CefProjectMigrationRequest getCefMigrationRequestFromConfig() {
		CefProjectMigrationRequest request = new CefProjectMigrationRequest();

		String projects = applicationConfigRepo.getCefProjectList();
		String migrateAll = applicationConfigRepo.getMigrateAllValue();

		if (StringUtils.isNotBlank(migrateAll) && migrateAll.trim().equalsIgnoreCase("TRUE")) {
			request.setMigrateAllProjects(true);
		}
		if (StringUtils.isNotBlank(projects)) {
			request.getCefProjectCode().addAll(Splitter.on(",").trimResults().splitToList(projects));
		}
		return request;
	}
	
	/**
	 * Get cef retry request for scheduler from Application_Config table
	 * 
	 * @return request
	 */
	@Transactional
	public CefProjectMigrationRequest getCefRetryMigrationRequestFromDB() {
		CefProjectMigrationRequest request = new CefProjectMigrationRequest();

		String projects = applicationConfigRepo.getRetryProjectList();
		String migrateAll = applicationConfigRepo.getRetryAllValue();

		if (StringUtils.isNotBlank(migrateAll) && migrateAll.trim().equalsIgnoreCase("TRUE")) {
			request.setMigrateAllProjects(true);
		}
		if (StringUtils.isNotBlank(projects)) {
			request.getCefProjectCode().addAll(Splitter.on(",").trimResults().splitToList(projects));
		}
		return request;
	}
	@Transactional
	public void beforeCefScheduler(SimpleDateFormat sdf) {
		//Update the config table with migration start time
		applicationConfigRepo.updateCefMigrationStartTime(sdf.format(new Date()));
	}
	@Transactional
	public void afterCefScheduler(SimpleDateFormat sdf) {
		// Mark the status as complete once scheduler finishes the job
		applicationConfigRepo.updateCefSchedulerStatus(CEF_SCHEDULER_COMPLETE_STATUS);
		//Update the config table with migration end time
		applicationConfigRepo.updateCefMigrationEndTime(sdf.format(new Date()));
	}
	@Transactional
	public void beforeCefRetryScheduler(SimpleDateFormat sdf) {
		//Update the config table with migration start time
		applicationConfigRepo.updateRetryMigrationStartTime(sdf.format(new Date()));
	}
	@Transactional
	public void afterCefRetryScheduler(SimpleDateFormat sdf) {
		// Mark the status as complete once scheduler finishes the job
		applicationConfigRepo.updateCefRetrySchedulerStatus(CEF_SCHEDULER_COMPLETE_STATUS);
		applicationConfigRepo.updateRetryMigrationEndTime(sdf.format(new Date()));
	}
}
