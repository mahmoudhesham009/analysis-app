package gov.uspto.pe2e.cpc.ipc.rest.cef.service;

import java.io.ByteArrayOutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.Nonnull;
import javax.annotation.Resource;
import javax.inject.Inject;

import org.apache.commons.collections4.IterableUtils;
import org.apache.commons.lang3.CharEncoding;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import biweekly.util.IOUtils;
import freemarker.template.Configuration;
import freemarker.template.Template;
import gov.uspto.pe2e.cpc.ipc.rest.cef.contract.CefMigrationReport;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.CefModuleProcessLog;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.CefProjectProcessLog;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.CefModuleProcessLogRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.CefProjectProcessLogRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.SchemeHierarchyRepository;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.CefModuleName;
import lombok.RequiredArgsConstructor;

/**
 * CEF Migration Service - Migration Report
 * 
 * @author Maximus
 * @version 1.0
 * @date: 10/04/2021
 */

@Service("cefMigrationReportService")
@RequiredArgsConstructor(onConstructor = @__(@Inject))
public class CefMigrationReportService {

	private static final Logger log = LoggerFactory.getLogger(CefMigrationReportService.class);
	private static final String REPORT_TEMPLATE_PATH = "templates/template.tpl";
	private static final String REPLACE_REGEX="(\\r|\\n|,)";

	@Nonnull
	private CefProjectProcessLogRepository cefProjectProcessLogRepository;

	@Nonnull
	private CefModuleProcessLogRepository cefModuleProcessLogRepository;

	@Nonnull
	private SchemeHierarchyRepository schemeHierarchyRepository;

	@Resource(name = "documentAdapterConfig")
	private Map<String, String> documentAdapterConfig;

	/**
	 * Generate CEF migration report
	 * 
	 * @return byte[]
	 */
	@Transactional
	public byte[] generateCefMigrationStatusReport() {
		byte[] dataForReport = null;
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		OutputStreamWriter writer = null;
		try {
			writer = new OutputStreamWriter(baos, CharEncoding.UTF_8);
			List<CefMigrationReport> reportLogs = buildMigrationReportObject();

			Map<String, Object> templateParam = new HashMap<>();
			templateParam.put("reportLogs", reportLogs);

			Configuration cfg = new Configuration(Configuration.VERSION_2_3_23);
			cfg.setClassForTemplateLoading(getClass(), "/");

			Template template = null;
			template = cfg.getTemplate(REPORT_TEMPLATE_PATH);
			template.process(templateParam, writer);

			writer.flush();
			baos.flush();
			dataForReport = baos.toByteArray();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			IOUtils.closeQuietly(writer);
			IOUtils.closeQuietly(baos);
		}
		return dataForReport;
	}

	/**
	 * Build migration report object
	 * 
	 * @return List<CefMigrationReport>
	 */
	private List<CefMigrationReport> buildMigrationReportObject() {
		List<CefModuleProcessLog> moduleLogList = new ArrayList<>();
		List<CefMigrationReport> reportItems = new ArrayList<>();

		Iterable<CefProjectProcessLog> projectLog = cefProjectProcessLogRepository.findAll();
		Iterable<CefModuleProcessLog> moduleLogItr = cefModuleProcessLogRepository.findAll();
		if (!IterableUtils.isEmpty(moduleLogItr)) {
			moduleLogList = IterableUtils.toList(moduleLogItr);
		}

		if (!IterableUtils.isEmpty(projectLog)) {
			List<CefProjectProcessLog> logList = IterableUtils.toList(projectLog);
			for (CefProjectProcessLog log : logList) {
				List<CefModuleProcessLog> moduleLogs = moduleLogList.stream().filter(module -> module
						.getCefProjectProcessLog().getCefProjectCode().equalsIgnoreCase(log.getCefProjectCode()))
						.collect(Collectors.toList());
				CefMigrationReport report = new CefMigrationReport();

				report.setCefProjectCode(log.getCefProjectCode());
				report.setStatus(log.getStatus());
				if (StringUtils.isNotBlank(log.getChangeProposalCode())) {
					report.setCeProjectCode(log.getChangeProposalCode());
				}
				if (StringUtils.isNotBlank(log.getChangeProposalExternalId())) {
					report.setGuid(log.getChangeProposalExternalId());
				}
				for (CefModuleProcessLog ml : moduleLogs) {
					if (ml.getModuleName().equals(CefModuleName.METADATA)) {
						report.setMetadataStatus(ml.getStatus());
						if (StringUtils.isNotBlank(ml.getRequest())) {
							report.setMetadataRequest(ml.getRequest().replaceAll(",", " "));
						}						
						if (StringUtils.isNotBlank(ml.getException())) {
							report.setMetadataException(ml.getException().replaceAll(REPLACE_REGEX, " "));
						}
					} else if (ml.getModuleName().equals(CefModuleName.WORKFLOW)) {
						report.setWorkflowStatus(ml.getStatus());
						if (StringUtils.isNotBlank(ml.getRequest())) {
							report.setWorkflowRequest(ml.getRequest().replaceAll(",", " "));
						}
						if (StringUtils.isNotBlank(ml.getException())) {
							report.setWorkflowException(ml.getException().replaceAll(REPLACE_REGEX, " "));
						}

					} else if (ml.getModuleName().equals(CefModuleName.DOCLIB)) {
						report.setDocLibStatus(ml.getStatus());
						if (StringUtils.isNotBlank(ml.getRequest())) {
							report.setDocLibRequest(ml.getRequest().replaceAll(",", " "));
						}
						if (StringUtils.isNotBlank(ml.getException())) {
							report.setDocLibException(ml.getException().replaceAll(REPLACE_REGEX, " "));
						}
					}
				}
				reportItems.add(report);
			}
		}
		return reportItems;
	}
}
