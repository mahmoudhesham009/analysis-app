package gov.uspto.pe2e.cpc.ipc.rest.cef.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import javax.annotation.Nonnull;
import javax.inject.Inject;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Splitter;

import gov.uspto.pe2e.cpc.ipc.rest.cef.contract.CefAnnexes;
import gov.uspto.pe2e.cpc.ipc.rest.cef.contract.CefProject;
import gov.uspto.pe2e.cpc.ipc.rest.cef.contract.CefRapporteurSummary;
import gov.uspto.pe2e.cpc.ipc.rest.cef.util.CefConstants;
import gov.uspto.pe2e.cpc.ipc.rest.cef.util.CefMigrationHelper;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.CefModuleProcessLog;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.CefProjectProcessLog;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalDocument;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.ChangeProposalDocumentApproval;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.CefModuleProcessLogRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.CefProjectProcessLogRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalDocumentApprovalRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ChangeProposalDocumentRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.GUIDUtils;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.CloudResource;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.MetadataKey;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.StandardIpOfficeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.CefMigrationStatus;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.CefModuleName;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.CefProjectMigrationRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.DocumentPhase;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalDocument;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalDocumentApproval;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalDocumentApproverRole;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalDocumentTypeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalDocumentVersionClassificationCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.saml.UsptoAuthenticationToken;
import gov.uspto.pe2e.cpc.ipc.rest.pm.service.ProposalDocumentService;
import gov.uspto.pe2e.cpc.ipc.rest.rm.service.ResourceService;
import lombok.RequiredArgsConstructor;

/**
 * CEF Migration Service - Project metadata
 * 
 * @author Maximus
 * @version 2.3.0
 * @date: 08/30/2021
 *
 */
@Component
@Service("cefDocumentLibraryMigrationService")
@RequiredArgsConstructor(onConstructor = @__(@Inject))
public class CefDocumentLibraryMigrationService {

	private static final Logger log = LoggerFactory.getLogger(CefDocumentLibraryMigrationService.class);

	@Nonnull
	private CefProjectProcessLogRepository cefProjectProcessLogRepository;

	@Nonnull
	private CefModuleProcessLogRepository cefModuleProcessLogRepository;

	@Nonnull
	private ProposalDocumentService proposalDocumentService;

	@Nonnull
	private ResourceService resourceService;

	@Nonnull
	private CefMigrationHelper migrationHelper;

	@Nonnull
	private ChangeProposalDocumentRepository changeProposalDocumentRepository;

	@Nonnull
	private ChangeProposalDocumentApprovalRepository changeProposalDocumentApprovalRepository;

	@Nonnull
	private CefCommonService cefCommonService;

	/**
	 * Process CEF projects documents
	 * 
	 * @param cefRequest
	 * @param authToken
	 * @return boolean
	 * @throws IOException
	 */
	@Transactional
	public void processCefProjectsDocs(CefProjectMigrationRequest request, UsptoAuthenticationToken authToken) {
		log.info("Inside processCefProjectsDocs -- start");
		List<String> cefProjects = new ArrayList<>();

		if (request.isMigrateAllProjects()) {
			cefProjects = cefCommonService.getListofProjectsToBeMigratedFromDB(CefModuleName.DOCLIB);
		} else {
			cefProjects = request.getCefProjectCode();
		}
		if (CollectionUtils.isNotEmpty(cefProjects)) {
			for (String cefProject : cefProjects) {
				log.debug("Document Migration started for the project:: {}", cefProject);
				
				if (cefCommonService.isCefMetadataProcessedSuccessfully(cefProject)) {
					if(!verifyProjectStatus(cefProject)) {
					log.debug("Getting list of files for the projRect {}", cefProject);
					List<File> projectFiles = migrationHelper.getAllFilesByProjectName(cefProject);

					File annexesFile = migrationHelper.getProjectFileByName(projectFiles,
							CefConstants.ANNEXES_FILE_NAME);

					File rapporteurSummaryFile = migrationHelper.getProjectFileByName(projectFiles,
							CefConstants.RAPPORTEUR_SUMMARY_FILE_NAME);

					// For all the documents uploaded under document library, it is set to
					// 'otherDocs'
					String componentType = "otherDocs";

					CefProjectProcessLog projectLog = cefProjectProcessLogRepository
							.findAllByCefProjectCode(cefProject);
					UUID proposalUUID = GUIDUtils.fromDatabaseFormat(projectLog.getChangeProposalExternalId());

					try {
						// Map Annexes.json data to CefAnnexes object
						List<CefAnnexes> cefAnnexes = mapAnnexesFileDataToCefAnnexes(annexesFile);
						Collections.sort(cefAnnexes);

						List<ProposalDocument> docs = mapCefDataToProposalDocuments(cefAnnexes, authToken.getEmail());

						if (CollectionUtils.isNotEmpty(docs)) {

							for (ProposalDocument doc : docs) {
								log.debug("Getting actual file to upload and converting to MultipartFile format");
								MultipartFile file = getFileToUpload(projectFiles, doc.getName());
								
								if(file !=null) {
									
								
								log.debug("Preparing metadata for the document to upload");
								Map<String, String> metadata = resourceService.populateResouceMetadata(null, null, null,
										proposalUUID.toString(), 1, null, componentType, file);

								metadata.put(MetadataKey.CREATE_USERID.name(), authToken.getEmail().toLowerCase());

								log.debug("Uploading file to cloud");
								CloudResource cloudResource = resourceService.uploadResource(file, metadata);
								// Setting resource id from cloud resource
								if (GUIDUtils.extract(cloudResource.getId()) != null) {
									doc.setResourceId(GUIDUtils.extract(cloudResource.getId()));
								} else {
									throw new IllegalArgumentException(
											"Expected resource id in GUID string format but returned: "
													+ cloudResource.getId() + ", Document Name: "
													+ file.getOriginalFilename());
								}
								log.debug("Saving uploaded proposal document details to database");
								UUID docID = proposalDocumentService.saveAsNew(
										GUIDUtils.fromDatabaseFormat(projectLog.getChangeProposalExternalId()), doc,
										authToken.getEmail());
								if (rapporteurSummaryFile != null) {
									log.debug("Mapping RapporteurSummary.json to ProposalDocumentApproval");
									List<ProposalDocumentApproval> docApprovals = mapRapporteurSummaryToDocApprovals(
											rapporteurSummaryFile, doc.getAnxNumber(), authToken.getEmail());
									if (CollectionUtils.isNotEmpty(docApprovals)) {
										log.debug("Saving ProposalDocumentApproval");
										proposalDocumentService.saveOrUpdateApprovals(proposalUUID, docID, docApprovals,
												authToken);
									}
								}
								}
							}
							log.debug("All Documents for project {} processed successfully.", cefProject);
							cefCommonService.populateCefModuleProcessLog(cefProject, CefMigrationStatus.SUCCESS,
									migrationHelper.getJsonFromObject(request), "", authToken.getEmail(),
									CefModuleName.DOCLIB);

							// Update project migration status in Process Log table
							populateProcessLogStatusForDocLib(cefProject, CefMigrationStatus.SUCCESS,
									authToken.getEmail());
						} else {
							log.debug("No documents available for the project {}", cefProject);
							cefCommonService.populateCefModuleProcessLog(cefProject, CefMigrationStatus.SUCCESS,
									migrationHelper.getJsonFromObject(request), "", authToken.getEmail(),
									CefModuleName.DOCLIB);

							// Update project migration status in Process Log table
							populateProcessLogStatusForDocLib(cefProject, CefMigrationStatus.SUCCESS,
									authToken.getEmail());
						}
					} catch (Exception e) {
						log.debug("Exception occurred while processing documents", e);
						// Populate exception in the audit tables
						cefCommonService.populateCefModuleProcessLog(cefProject, CefMigrationStatus.FAILED,
								migrationHelper.getJsonFromObject(request), cefCommonService.getStacktraceString(e),
								authToken.getEmail(), CefModuleName.DOCLIB);

						deleteUploadedDocs(proposalUUID);
					}
				}
				} else {
					if(!isSkipProject(cefProject)) {
						String error = "Project metadata is not processed successfully";
						log.debug(error);
						cefCommonService.populateCefModuleProcessLog(cefProject, CefMigrationStatus.FAILED,
								migrationHelper.getJsonFromObject(request), error, authToken.getEmail(),
								CefModuleName.DOCLIB);
					}					
				}
				log.debug("Document Migration ended for the project:: {}", cefProject);
			}
		}
		log.info("Inside processCefProjectsDocs -- end");
	}

	/**
	 * Maps CefAnnexes to ProposalDocument
	 * 
	 * @param cefAnnexes
	 * @return List<ProposalDocument>
	 */
	private List<ProposalDocument> mapCefDataToProposalDocuments(List<CefAnnexes> cefAnnexes, String userEmail) {
		log.info("Inside mapCefDataToProposalDocuments -- start");
		// Hard coded values based on biz clarifications
		ProposalDocumentTypeCode docType = ProposalDocumentTypeCode.OTH;
		DocumentPhase phase = DocumentPhase.PROJECT;
		ProposalDocumentVersionClassificationCode version = ProposalDocumentVersionClassificationCode.Initial;

		// processing the documents
		List<ProposalDocument> docs = new ArrayList<>();
		if (CollectionUtils.isNotEmpty(cefAnnexes)) {
			for (CefAnnexes cefAnx : cefAnnexes) {
				ProposalDocument doc = new ProposalDocument();
				Date now = new Date();
				doc = new ProposalDocument();
				doc.setAnxNumber(cefAnx.getNum());
				doc.setComment(cefAnx.getFilename());
				doc.setCreateTs(now);
				doc.setCreateUserId(userEmail);
				doc.setDocumentType(docType);
				doc.setIpOfficeCode(StandardIpOfficeCode.valueOf(cefAnx.getOfficecode()));
				doc.setName(cefAnx.getFilename());
				doc.setPhase(phase);
				doc.setUpdateTs(now);
				doc.setUpdateUserId(userEmail);
				doc.setVersion(version);
				// As per biz clarification, all docs by default should be archived
				doc.setDeleted(true);
				docs.add(doc);
			}
		}
		log.info("Inside mapCefDataToProposalDocuments -- end");
		return docs;
	}

	/**
	 * Map Annexes.json file to CefAnnexes object
	 * 
	 * @param file
	 * @return List<CefAnnexes>
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	private List<CefAnnexes> mapAnnexesFileDataToCefAnnexes(File file)
			throws JsonParseException, JsonMappingException, IOException {
		log.info("Inside mapAnnexesFileDataToCefAnnexes -- start");
		List<CefAnnexes> annexes = new ArrayList<>();

		if (file != null) {
			annexes = Arrays.asList(new ObjectMapper().readValue(file, CefAnnexes[].class));
		}
		log.info("Inside mapAnnexesFileDataToCefAnnexes -- end");
		return annexes;
	}

	/**
	 * Get file from project files list and convert it to MultipartFile
	 * 
	 * @param projectFiles
	 * @param fileName
	 * @return MultipartFile
	 * @throws IOException
	 */
	private MultipartFile getFileToUpload(List<File> projectFiles, String fileName) throws IOException {
		log.info("Inside getFileToUpload -- start");
		MultipartFile multipartFile = null;
		File fileToUpload = migrationHelper.getProjectFileByName(projectFiles, fileName);
		log.info("Inside getFileToUpload -- end");
		if(fileToUpload !=null) {
			multipartFile =  migrationHelper.convertFileToMultipartFile(fileToUpload);
		}
		return multipartFile;
	}

	/**
	 * Map RpporteurSummary.json data to ProposalDocumentApproval
	 * 
	 * @param file
	 * @param anxNum
	 * @return List<ProposalDocumentApproval>
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	private List<ProposalDocumentApproval> mapRapporteurSummaryToDocApprovals(File file, Integer anxNum,
			String userEmail) throws JsonParseException, JsonMappingException, IOException {
		log.info("Inside mapRapporteurSummaryToDocApprovals -- start");
		List<ProposalDocumentApproval> docApprovals = new ArrayList<>();
		List<CefRapporteurSummary> rapporteurSummary = mapRapporteurSummaryToCefRapporteurSummary(file);
		if (CollectionUtils.isNotEmpty(rapporteurSummary)) {
			for (CefRapporteurSummary rapSummary : rapporteurSummary) {
				if (StringUtils.isNotEmpty(rapSummary.getAnxlist())
						&& StringUtils.isNotEmpty(rapSummary.getApprovalText())
						&& Splitter.on(",").trimResults().splitToList(rapSummary.getAnxlist()).contains("Anx" + anxNum)) {
					if (StringUtils.equalsIgnoreCase(rapSummary.getApprovalText().trim(), CefConstants.APPROVED_JEB)) {
						// When approved by JEB, that means it is approved by US and EP office
						ProposalDocumentApproval approval = prepareDocApproval(StandardIpOfficeCode.US,
								ProposalDocumentApproverRole.EB, userEmail);
						approval.setComment(rapSummary.getApprovalText());
						// Add first entry for US
						docApprovals.add(approval);
						// Add second entry for EP
						ProposalDocumentApproval epApproval = prepareDocApproval(StandardIpOfficeCode.EP,
								ProposalDocumentApproverRole.EB, userEmail);
						epApproval.setComment(rapSummary.getApprovalText());
						docApprovals.add(epApproval);
					}
					if (StringUtils.equalsIgnoreCase(rapSummary.getApprovalText().trim(),
							CefConstants.APPROVED_EP_EB)) {
						ProposalDocumentApproval approval = prepareDocApproval(StandardIpOfficeCode.EP,
								ProposalDocumentApproverRole.EB, userEmail);
						approval.setComment(rapSummary.getApprovalText());
						docApprovals.add(approval);
					}
					if (StringUtils.equalsIgnoreCase(rapSummary.getApprovalText().trim(),
							CefConstants.APPROVED_US_EB)) {
						ProposalDocumentApproval approval = prepareDocApproval(StandardIpOfficeCode.US,
								ProposalDocumentApproverRole.EB, userEmail);
						approval.setComment(rapSummary.getApprovalText());
						docApprovals.add(approval);
					}
					if (StringUtils.equalsIgnoreCase(rapSummary.getApprovalText().trim(),
							CefConstants.APPROVED_EP_PC)) {
						ProposalDocumentApproval approval = prepareDocApproval(StandardIpOfficeCode.EP,
								ProposalDocumentApproverRole.PC, userEmail);
						approval.setComment(rapSummary.getApprovalText());
						docApprovals.add(approval);
					}
					if (StringUtils.equalsIgnoreCase(rapSummary.getApprovalText().trim(),
							CefConstants.APPROVED_US_PC)) {
						ProposalDocumentApproval approval = prepareDocApproval(StandardIpOfficeCode.US,
								ProposalDocumentApproverRole.PC, userEmail);
						approval.setComment(rapSummary.getApprovalText());
						docApprovals.add(approval);
					}
				}
			}
		}
		log.info("Inside mapRapporteurSummaryToDocApprovals -- end");
		return docApprovals;
	}

	/**
	 * Map Json file data to CefRapporteurSummary object
	 * 
	 * @param file
	 * @return List<CefRapporteurSummary>
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	private List<CefRapporteurSummary> mapRapporteurSummaryToCefRapporteurSummary(File file)
			throws JsonParseException, JsonMappingException, IOException {
		log.info("Inside mapRapporteurSummaryToCefRapporteurSummary -- start");
		List<CefRapporteurSummary> rapporteurSummary = new ArrayList<>();
		List<CefRapporteurSummary> filteredList =  new ArrayList<>();

		if (file != null) {
			rapporteurSummary = Arrays.asList(new ObjectMapper().readValue(file, CefRapporteurSummary[].class));
			filteredList=rapporteurSummary.stream().filter(distinctBy(rs->rs.getAnxlist())).collect(Collectors.toList());
		}
		log.info("Inside mapRapporteurSummaryToCefRapporteurSummary -- end");
		return filteredList;
	}
	/** Filter duplicate records by property
	 * 
	 * @param <T>
	 * @param f
	 * @return
	 */
	private static <T> Predicate<T> distinctBy(Function<? super T, ?> f) {
		  Set<Object> objects = new HashSet();
		  return t -> objects.add(f.apply(t));
		}

	/**
	 * Prepare ProposalDocumentApproval
	 * 
	 * @param office
	 * @param approverRole
	 * @return ProposalDocumentApproval
	 */
	private ProposalDocumentApproval prepareDocApproval(StandardIpOfficeCode office,
			ProposalDocumentApproverRole approverRole, String userEmail) {
		log.info("Inside prepareDocApproval -- start");
		ProposalDocumentApproval approval = new ProposalDocumentApproval();
		Date now = new Date();
		approval.setApproved(true);
		approval.setIpOfficeCode(office);
		approval.setProposerRoleCode(approverRole);
		approval.setCreateTs(now);
		approval.setCreateUserId(userEmail);
		approval.setUpdateTs(now);
		approval.setUpdateUserId(userEmail);

		log.info("Inside prepareDocApproval -- end");
		return approval;
	}

	/**
	 * Delete all documents for the proposal
	 * 
	 * @param proposalId
	 */
	private void deleteUploadedDocs(UUID proposalId) {
		log.info("Inside deleteUploadedDocs -- start");
		List<ChangeProposalDocument> proposalDocs = changeProposalDocumentRepository
				.findDocumentsByChangeProposalExternalId(GUIDUtils.toDatabaseFormat(proposalId));
		List<ChangeProposalDocumentApproval> docApprovals = new ArrayList<>();
		List<UUID> resourceIds = new ArrayList<>();

		log.info("Preparing documents info to be deleted");
		if (CollectionUtils.isNotEmpty(proposalDocs)) {
			for (ChangeProposalDocument doc : proposalDocs) {
				resourceIds.add(GUIDUtils.fromDatabaseFormat(doc.getDocumentId()));
				if (CollectionUtils.isNotEmpty(doc.getApprovals())) {
					docApprovals.addAll(doc.getApprovals());
				}
			}
		}
		log.info("Deleting all document approvals");
		if (CollectionUtils.isNotEmpty(docApprovals)) {
			changeProposalDocumentApprovalRepository.delete(docApprovals);
		}
		log.info("Deleting all documents from ChangeProposalDocument");
		if (CollectionUtils.isNotEmpty(proposalDocs)) {
			changeProposalDocumentRepository.delete(proposalDocs);
		}
		// TODO: This might not be needed. But don't remove this yet
//		log.info("Deleting all documents from cloud");
//		if (CollectionUtils.isNotEmpty(resourceIds)) {
//			for (UUID resourceID : resourceIds) {
//				resourceService.deleteResource(GUIDUtils.toDatabaseFormat(resourceID));
//			}
//		}
		log.info("Inside deleteUploadedDocs -- end");
	}

	/**
	 * Populate CEF migration status - Project Log
	 * 
	 * @param cefProjectCode
	 * @param status
	 * @param userEmail
	 */
	private void populateProcessLogStatus(String cefProjectCode, CefMigrationStatus status, String userEmail) {
		CefProjectProcessLog projectLog = cefProjectProcessLogRepository.findAllByCefProjectCode(cefProjectCode);
		if (projectLog != null) {
			cefCommonService.saveOrUpdateCefProjectProcessLogData(cefProjectCode, projectLog.getChangeProposalCode(),
					projectLog.getChangeProposalExternalId(), status, userEmail);
		}
	}

	/**
	 * Populate Process Log migration status - workflow/ Doc Lib module
	 * 
	 * @param cefProjectCode
	 * @param status
	 * @param userEmail
	 */
	private void populateProcessLogStatusForDocLib(String cefProjectCode, CefMigrationStatus status, String userEmail) {
		CefModuleProcessLog cefModuleLog;
		// Get module logs for workflow
		cefModuleLog = cefModuleProcessLogRepository.findAllLogsByCefProjectCodeAndModule(cefProjectCode,
				CefModuleName.WORKFLOW);

		if (cefModuleLog != null && cefModuleLog.getStatus().equals(CefMigrationStatus.SUCCESS)) {
			populateProcessLogStatus(cefProjectCode, status, userEmail);
		}
	}
	
	/**
	 * Check if project needs to be skipped
	 * 
	 * @param cefProjectCode
	 * @return
	 */
	private boolean isSkipProject(String cefProjectCode) {
		boolean skipProject = false;
		File cefProjectFile = migrationHelper.getFileByProjectName(cefProjectCode, CefConstants.PROJECT_FILE_NAME);
		CefProject cefProject;

		try {
			cefProject = cefCommonService.mapJsonFileToCefProject(cefProjectFile);
			skipProject = cefCommonService.isSkipForMigration(cefProject);
		} catch (Exception e) {
			log.debug("Exception occurred while mapping project.json file to CefProject");
		}
		return skipProject;
	}
	/**
	 * Check DOC Lib migration status for the project
	 * @param cefProjectCode
	 * @return
	 */
	 private boolean verifyProjectStatus(String cefProjectCode) {
	        boolean migrated = false;
	        CefModuleProcessLog docLibLog = cefModuleProcessLogRepository
	        		.findAllLogsByCefProjectCodeAndModule(cefProjectCode,CefModuleName.DOCLIB);
	        if (docLibLog != null && (StringUtils.equals(CefMigrationStatus.SUCCESS.name(), docLibLog.getStatus().name()))) {
	            log.debug("Document library migration is already completed for the project:: {}", cefProjectCode);
	            migrated = true;
	        }
	        return migrated;
	    }
}
