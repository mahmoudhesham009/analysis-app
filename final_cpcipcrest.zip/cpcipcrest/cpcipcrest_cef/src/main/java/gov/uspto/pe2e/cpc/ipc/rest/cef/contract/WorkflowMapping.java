package gov.uspto.pe2e.cpc.ipc.rest.cef.contract;

import gov.uspto.pe2e.cpc.ipc.rest.contract.stateflow.v1_0.WorkflowEntryPoint;
import gov.uspto.pe2e.cpc.ipc.rest.contract.stateflow.v1_0.WorkflowProposalTrack;
/**
 * Enum for mapping CEF Project type to proposal track and workflow entry point for starting workflow
 * 
 * @author Maximus
 * 	@date: 10/01/2021
 *
 */
public enum WorkflowMapping {
	
	DP("CPC_REVISION","CPC_PROPOSAL"),
	MP("CPC_REVISION","CPC_PROPOSAL"),
	RP("CPC_REVISION","CPC_PROPOSAL"),
	HP("HARMONIZATION","HARMONIZATION_PROJECT"),
	HX("HARMONIZATION","HARMONIZATION_PROJECT"),	
	IA("IPC","IPC"),
	IC("IPC","IPC"),
	ID("IPC","IPC"),
	IE("IPC","IP5"),
	IF("IPC","IPC"),
	IJ("IPC","IP5"),
	IM("IPC","IPC"),
	IP("IPC","IP5"),
	IQ("IPC","IPC"),
	IU("IPC","IP5"),
	IV("IPC","IPC"),
	IW("IPC","IPC"),
	IZ("IPC","IPC"),
	PM("CPC_REVISION","CPC_PROPOSAL");

	private final String proposalTrack;
	private final String wfEntryPoint;
	
	private WorkflowMapping(String proposalTrack, String wfEntryPoint) {
		this.proposalTrack=proposalTrack;
		this.wfEntryPoint=wfEntryPoint;
	}
	/**
	 * Get workflow track for cef project type
	 * @return WorkflowProposalTrack
	 */
	public WorkflowProposalTrack getProposalTrack() {
		return WorkflowProposalTrack.fromValue(proposalTrack);
	}
	/**
	 * Get Workflow entry point for cef project type
	 * @return WorkflowEntryPoint
	 */
	public WorkflowEntryPoint getWfEntryPoint() {
		return WorkflowEntryPoint.fromValue(wfEntryPoint);
	}
}
