
package gov.uspto.pe2e.cpc.ipc.rest.cef.contract;

import java.util.Date;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.w3._2001.xmlschema.Adapter1;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

public class CefProject {

    
    protected long id;
    
    protected String name;
    
    protected String typecode;
    
    protected String typename;
    
    protected String techcode;
    
    protected String techname;
    
    protected String statuscode;
    
    protected String statusname;
    
    protected String ipc;
    
    protected String originator;
    
    protected String rapporteur;
    
    protected String translator;
    
    protected String prefix;
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd hh:mm:ss")
    @JsonProperty("created_at")
    protected Date createdAt;
    
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd hh:mm:ss")
    @JsonProperty("updated_at")
    protected Date updatedAt;

    /**
     * Gets the value of the id property.
     * 
     */
    public long getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     */
    public void setId(long value) {
        this.id = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the typecode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypecode() {
        return typecode;
    }

    /**
     * Sets the value of the typecode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypecode(String value) {
        this.typecode = value;
    }

    /**
     * Gets the value of the typename property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypename() {
        return typename;
    }

    /**
     * Sets the value of the typename property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypename(String value) {
        this.typename = value;
    }

    /**
     * Gets the value of the techcode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTechcode() {
        return techcode;
    }

    /**
     * Sets the value of the techcode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTechcode(String value) {
        this.techcode = value;
    }

    /**
     * Gets the value of the techname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTechname() {
        return techname;
    }

    /**
     * Sets the value of the techname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTechname(String value) {
        this.techname = value;
    }

    /**
     * Gets the value of the statuscode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatuscode() {
        return statuscode;
    }

    /**
     * Sets the value of the statuscode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatuscode(String value) {
        this.statuscode = value;
    }

    /**
     * Gets the value of the statusname property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatusname() {
        return statusname;
    }

    /**
     * Sets the value of the statusname property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatusname(String value) {
        this.statusname = value;
    }

    /**
     * Gets the value of the ipc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIpc() {
        return ipc;
    }

    /**
     * Sets the value of the ipc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIpc(String value) {
        this.ipc = value;
    }

    /**
     * Gets the value of the originator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginator() {
        return originator;
    }

    /**
     * Sets the value of the originator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginator(String value) {
        this.originator = value;
    }

    /**
     * Gets the value of the rapporteur property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRapporteur() {
        return rapporteur;
    }

    /**
     * Sets the value of the rapporteur property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRapporteur(String value) {
        this.rapporteur = value;
    }

    /**
     * Gets the value of the translator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTranslator() {
        return translator;
    }

    /**
     * Sets the value of the translator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTranslator(String value) {
        this.translator = value;
    }

    /**
     * Gets the value of the prefix property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrefix() {
        return prefix;
    }

    /**
     * Sets the value of the prefix property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrefix(String value) {
        this.prefix = value;
    }

    /**
     * Gets the value of the createdAt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getCreatedAt() {
        return createdAt;
    }

    /**
     * Sets the value of the createdAt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCreatedAt(Date value) {
        this.createdAt = value;
    }

    /**
     * Gets the value of the updatedAt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getUpdatedAt() {
        return updatedAt;
    }

    /**
     * Sets the value of the updatedAt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUpdatedAt(Date value) {
        this.updatedAt = value;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
    }

    @Override
    public boolean equals(Object that) {
        return EqualsBuilder.reflectionEquals(this, that);
    }

    @Override
    public int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

}
