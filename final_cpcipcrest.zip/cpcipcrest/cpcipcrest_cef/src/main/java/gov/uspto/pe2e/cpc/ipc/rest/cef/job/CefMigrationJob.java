package gov.uspto.pe2e.cpc.ipc.rest.cef.job;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.util.Arrays;
import java.util.Date;
import java.util.TimeZone;

import javax.annotation.Nonnull;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.saml.SAMLCredential;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;

import gov.uspto.pe2e.cpc.ipc.rest.cef.service.CefCommonService;
import gov.uspto.pe2e.cpc.ipc.rest.cef.service.CefDocumentLibraryMigrationService;
import gov.uspto.pe2e.cpc.ipc.rest.cef.service.CefMetadataMigrationService;
import gov.uspto.pe2e.cpc.ipc.rest.cef.service.CefMigrationRetryService;
import gov.uspto.pe2e.cpc.ipc.rest.cef.service.CefWorkflowMigrationService;
import gov.uspto.pe2e.cpc.ipc.rest.cef.util.CefMigrationHelper;
import gov.uspto.pe2e.cpc.ipc.rest.cef.util.CustomRequestScopeAttr;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.ApplicationConfigRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.SecurityService;
import gov.uspto.pe2e.cpc.ipc.rest.contract.common.StandardIpOfficeCode;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.CefProjectMigrationRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.saml.UsptoAuthenticationToken;
import lombok.RequiredArgsConstructor;

/**
 * This job runs the cef migration services to migrate cef projects to CE
 * 
 * @author Maximus
 * @date Oct 12, 2021
 * @version 1.0
 *
 */
@Component
@RequiredArgsConstructor(onConstructor = @__(@Inject))
public class CefMigrationJob {

	private static final Logger log = LoggerFactory.getLogger(CefMigrationJob.class);
	private static final String DB_TIME_FORMAT = "YYYY-MM-dd HH:mm:ss";
	private static final String CEF_SCHEDULER_COMPLETE_STATUS = "Completed";
	private static final String EST_ZONE = "America/New_York";
	private static final String MIGRATION_EMAIL_ID="cpccollaborationsupport@uspto.gov";
	private static final String MIGRATION_USER="cpccollaborationsupport";
	

	@Nonnull
	public CefMetadataMigrationService cefMetadataMigrationService;

	@Nonnull
	public CefWorkflowMigrationService cefWorkflowMigrationService;

	@Nonnull
	public CefDocumentLibraryMigrationService cefDocumentLibraryMigrationService;

	@Nonnull
	private SecurityService securityService;

	@Nonnull
	private CefCommonService cefCommonService;

	@Nonnull
	private ApplicationConfigRepository applicationConfigRepo;
	
	@Nonnull
	private CefMigrationRetryService cefMigrationRetryService;
	
	@Nonnull
	private CefMigrationHelper cefMigrationHelper;

	/**
	 * Start CEF Migration scheduled job using cron expression and scheduled date
	 * and time from DB
	 */
	@Scheduled(fixedDelay = 300000)
//	@Transactional
	public void kickCefMigration() {
		log.info("Inside kickCefMigration -- start");
		if(cefMigrationHelper.isCefProjectsExistsOnServer()) {
		long start = System.currentTimeMillis();
		log.debug("CEF Migration started at:: {}", new Date());

//		SAMLCredential credential= SamlTokenUtil.createTestSamlCredential(MIGRATION_EMAIL_ID, MIGRATION_USER,
//				"CEF", "MIGRATION", StandardIpOfficeCode.US.name());
		UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(
				MIGRATION_EMAIL_ID, MIGRATION_EMAIL_ID,
				Arrays.asList(new GrantedAuthority() {
					@Override
					public String getAuthority() {
						// TODO Auto-generated method stub
						return MIGRATION_EMAIL_ID;
					}
				}));
		
		SecurityContextHolder.getContext().setAuthentication(token);
		UsptoAuthenticationToken authToken = securityService
				.mapSamlTokenToContractModel(SecurityContextHolder.getContext().getAuthentication());
		authToken.setIpOfficeCode(StandardIpOfficeCode.US.name());
		authToken.setOffice(StandardIpOfficeCode.US.name());
		
		SimpleDateFormat sdf = new SimpleDateFormat(DB_TIME_FORMAT);
		sdf.setTimeZone(TimeZone.getTimeZone(ZoneId.of(EST_ZONE)));
		Timestamp currentTs = Timestamp.valueOf(sdf.format(new Date()));
		
		log.debug("Token - "+authToken.toString());
		//Update start time
		cefCommonService.beforeCefScheduler(sdf);
		try {
			RequestContextHolder.setRequestAttributes(new CustomRequestScopeAttr());

			if (cefCommonService.isStartMigration(currentTs)) {
				String schedularStatus = cefCommonService.cefMigrationSchedulerStatus();
				if (StringUtils.isNotEmpty(schedularStatus)
						&& !schedularStatus.equalsIgnoreCase(CEF_SCHEDULER_COMPLETE_STATUS)
						) {
					log.info("Cef Migration Scheduled Job -- Started");

					CefProjectMigrationRequest request = cefCommonService.getCefMigrationRequestFromConfig();
					
					log.debug("Token - "+authToken.toString());
					cefMetadataMigrationService.processCefProjects(request, authToken);

					log.debug("Token - "+authToken.toString());
					cefDocumentLibraryMigrationService.processCefProjectsDocs(request, authToken);

					log.debug("Token - "+authToken.toString());
					cefWorkflowMigrationService.processCefProjectsWorkflow(request, authToken);					

					log.info("Cef Migration Scheduled Job -- Completed");
				}
			}
		} catch (Exception e) {
			log.debug("Error occcured while running scheduled cef migration job", e);
		} finally {
			RequestContextHolder.resetRequestAttributes();
		}
		//update status and time in config table
		cefCommonService.afterCefScheduler(sdf);
		long end = System.currentTimeMillis();
		log.debug("Total CEF Migration Elapsed time {} ms", end - start);
		log.debug("CEF Migration ended at:: {}", new Date());
		}
		log.info("Inside kickCefMigration -- end");
	}
	
	@Scheduled(fixedDelay = 300000)
//	@Transactional
	public void kickCefRetryService() {
		log.info("Inside kickCefRetryService -- start");
		if(cefMigrationHelper.isCefProjectsExistsOnServer()) {
		long start = System.currentTimeMillis();
		log.debug("CEF Migration Retry started at:: {}", new Date());
		UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(
				MIGRATION_EMAIL_ID, MIGRATION_EMAIL_ID,
				Arrays.asList(new GrantedAuthority() {
					@Override
					public String getAuthority() {
						// TODO Auto-generated method stub
						return MIGRATION_EMAIL_ID;
					}
				}));
		
		SecurityContextHolder.getContext().setAuthentication(token);
		UsptoAuthenticationToken authToken = securityService
				.mapSamlTokenToContractModel(SecurityContextHolder.getContext().getAuthentication());
		authToken.setIpOfficeCode(StandardIpOfficeCode.US.name());
		authToken.setOffice(StandardIpOfficeCode.US.name());

		SimpleDateFormat sdf = new SimpleDateFormat(DB_TIME_FORMAT);
		sdf.setTimeZone(TimeZone.getTimeZone(ZoneId.of(EST_ZONE)));
		Timestamp currentTs = Timestamp.valueOf(sdf.format(new Date()));
		//update start time in config table
		cefCommonService.beforeCefRetryScheduler(sdf);
		try {
			RequestContextHolder.setRequestAttributes(new CustomRequestScopeAttr());

			if (cefCommonService.isRetryMigration(currentTs)) {
				String schedularStatus = cefCommonService.cefRetrySchedulerStatus();
				if (StringUtils.isNotEmpty(schedularStatus)
						&& !schedularStatus.equalsIgnoreCase(CEF_SCHEDULER_COMPLETE_STATUS)) {
					log.info("Cef Migration kickCefRetryService Job -- Started");

					CefProjectMigrationRequest request = cefCommonService.getCefRetryMigrationRequestFromDB();
					
					cefMigrationRetryService.retryCEFMigration(request, authToken);


					log.info("Cef Migration kickCefRetryService Job -- Completed");
				}
			}
		} catch (Exception e) {
			log.debug("Error occcured while running scheduled cef kickCefRetryService job", e);
		} finally {
			RequestContextHolder.resetRequestAttributes();
		}
		long end = System.currentTimeMillis();
		
		//Update the config table with migration start time
		cefCommonService.afterCefRetryScheduler(sdf);
		log.debug("CEF Migration Retry ended at:: {}", new Date());
		log.debug("Total CEF Migration Retry Elapsed time {} ms", end - start);
	}
	log.info("Inside kickCefRetryService -- end");
	}
}
