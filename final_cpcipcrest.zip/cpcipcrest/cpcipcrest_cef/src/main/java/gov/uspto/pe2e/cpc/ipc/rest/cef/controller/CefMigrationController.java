
package gov.uspto.pe2e.cpc.ipc.rest.cef.controller;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.annotation.Nonnull;
import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.Null;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import gov.uspto.pe2e.cpc.ipc.rest.cef.service.CefDocumentLibraryMigrationService;
import gov.uspto.pe2e.cpc.ipc.rest.cef.service.CefMetadataMigrationService;
import gov.uspto.pe2e.cpc.ipc.rest.cef.service.CefMigrationReportService;
import gov.uspto.pe2e.cpc.ipc.rest.cef.service.CefMigrationRetryService;
import gov.uspto.pe2e.cpc.ipc.rest.cef.service.CefWorkflowMigrationService;
import gov.uspto.pe2e.cpc.ipc.rest.cef.util.CefConstants;
import gov.uspto.pe2e.cpc.ipc.rest.cef.util.CefMigrationHelper;
import gov.uspto.pe2e.cpc.ipc.rest.commons.enumeration.ExportOutputType;
import gov.uspto.pe2e.cpc.ipc.rest.commons.error.ResourceCheckoutException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.model.SymbolName;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.CefProjectProcessLogRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.security.SecurityService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.RestUtils;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.CefProjectMigrationRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.ProposalFormType;
import gov.uspto.pe2e.cpc.ipc.rest.contract.saml.UsptoAuthenticationToken;
import gov.uspto.pe2e.cpc.ipc.rest.contract.v1_0.QNContactDocument;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.RequiredArgsConstructor;

/**
 * Class serves as CEF Migration Controller
 * 
 * @author Maximus
 * @date August 25, 2021
 * @version 2.3
 *
 */
@Component
@Api(value = "/cef/proposals", description = "Controller for managing cef proposals (create project, documents and workflow)")
@RestController
@RequestMapping(value = "/cef/proposals")
@RequiredArgsConstructor(onConstructor = @__(@Inject))
public class CefMigrationController {
	private static final Logger log = LoggerFactory.getLogger(CefMigrationController.class);
	private static final String FILE_ATTACHMENT_CONSTANT = "attachment; filename=";

	@Nonnull
	public CefMetadataMigrationService cefMetadataMigrationService;

	@Nonnull
	public CefWorkflowMigrationService cefWorkflowMigrationService;

	@Nonnull
	public CefDocumentLibraryMigrationService cefDocumentLibraryMigrationService;

	@Nonnull
	private SecurityService securityService;

	@Nonnull
	private CefProjectProcessLogRepository cefProjectProcessLogRepository;

	@Nonnull
	private CefMigrationReportService cefMigrationReportService;

	@Nonnull
	private CefMigrationRetryService cefMigrationRetryService;

	@Nonnull
	private CefMigrationHelper cefMigrationHelper;

	/**
	 * Create a CEF project Based on Request details.
	 * 
	 * @param request
	 * @return ResponseEntity<Void>
	 * @throws ResourceCheckoutException
	 * @throws IOException
	 * @since August 25, 2021
	 */
	@ApiResponses({ @ApiResponse(code = 201, message = "Created cef proposal"),
			@ApiResponse(code = 401, message = "Not Authenticated"),
			@ApiResponse(code = 403, message = "Does not have permission to create proposal"),
			@ApiResponse(code = 500, message = "Internal Error") })
	@ApiOperation("CEF Metadata migration process request")
	@RequestMapping(method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Void> processCefProjects(@RequestBody CefProjectMigrationRequest request) {
		log.info("Inside processCefProjects");
		HttpHeaders headers = RestUtils.buildErrorHttpHeaders();
		UsptoAuthenticationToken authToken = securityService
				.mapSamlTokenToContractModel(SecurityContextHolder.getContext().getAuthentication());

		HttpStatus status = HttpStatus.NOT_FOUND;
		if (cefMigrationHelper.isCefProjectsExistsOnServer()) {
			cefMetadataMigrationService.processCefProjects(request, authToken);
			status = HttpStatus.CREATED;
		}
		return new ResponseEntity<>(headers, status);
	}

	/**
	 * Process workflow data for CEF projects.
	 * 
	 * @param request
	 * @return ResponseEntity<Void>
	 * @since September 09, 2021
	 */
	@ApiResponses({ @ApiResponse(code = 202, message = "Workflow started successfully"),
			@ApiResponse(code = 400, message = "Workflow not started"),
			@ApiResponse(code = 401, message = "Not Authenticated"),
			@ApiResponse(code = 403, message = "Does not have permission to start the workflow"),
			@ApiResponse(code = 500, message = "Internal Error") })
	@ApiOperation("Starts the workflow for successfully migrated CEF projects")
	@RequestMapping(value = "/workflow/start", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Void> processCefProjectsWorkflow(@RequestBody CefProjectMigrationRequest request) {
		log.info("Inside processCefProjectsWorkflow");
		HttpHeaders headers = RestUtils.buildErrorHttpHeaders();
		UsptoAuthenticationToken authToken = securityService
				.mapSamlTokenToContractModel(SecurityContextHolder.getContext().getAuthentication());
		HttpStatus status = HttpStatus.NOT_FOUND;
		if (cefMigrationHelper.isCefProjectsExistsOnServer()) {
			cefWorkflowMigrationService.processCefProjectsWorkflow(request, authToken);
			status = HttpStatus.ACCEPTED;
		}
		return new ResponseEntity<>(headers, status);
	}

	/**
	 * Migrate documents for CEF projects.
	 * 
	 * @param request
	 * @return ResponseEntity<Void>
	 * @since September 09, 2021
	 */
	@ApiResponses({ @ApiResponse(code = 201, message = "File uploaded successfully"),
			@ApiResponse(code = 400, message = "Failed to upload documents"),
			@ApiResponse(code = 401, message = "Not Authenticated"),
			@ApiResponse(code = 403, message = "Does not have permission to upload files"),
			@ApiResponse(code = 500, message = "Internal Error") })
	@ApiOperation("Upload documents to successfully migrated CEF projects")
	@RequestMapping(value = "/documents/upload", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Void> processCefProposalDocs(@RequestBody CefProjectMigrationRequest request) {
		log.info("Inside processCefProposalDocs");
		HttpHeaders headers = RestUtils.buildErrorHttpHeaders();
		UsptoAuthenticationToken authToken = securityService
				.mapSamlTokenToContractModel(SecurityContextHolder.getContext().getAuthentication());
		HttpStatus status = HttpStatus.NOT_FOUND;
		if (cefMigrationHelper.isCefProjectsExistsOnServer()) {
			cefDocumentLibraryMigrationService.processCefProjectsDocs(request, authToken);
			status = HttpStatus.CREATED;
		}
		return new ResponseEntity<>(headers, status);
	}

	@ApiOperation("Generate CEF migration status report")
	@RequestMapping(value = "/generateStatusReport", method = RequestMethod.GET)
	public void getCefMigrationReport(HttpServletResponse response) throws IOException {

		byte[] data = cefMigrationReportService.generateCefMigrationStatusReport();
		response.setContentLengthLong(data.length);
		response.setContentType(ExportOutputType.CSV.getContentType());
		response.setHeader(HttpHeaders.CONTENT_DISPOSITION,
				FILE_ATTACHMENT_CONSTANT + CefConstants.CEF_MIGRATION_REPORT_NAME);
		OutputStream os = null;
		try {
			os = response.getOutputStream();
			os.write(data);
		} finally {
			IOUtils.closeQuietly(os);
		}
	}



	/**
	 * Retry a CEF migration process.
	 * 
	 * @param request?
	 * @return ResponseEntity<Void>
	 * @throws ResourceCheckoutException
	 * @since Oct 11, 2021
	 */
	@ApiResponses({ @ApiResponse(code = 201, message = "Created cef proposal"),
			@ApiResponse(code = 401, message = "Not Authenticated"),
			@ApiResponse(code = 403, message = "Does not have permission to create proposal"),
			@ApiResponse(code = 500, message = "Internal Error") })
	@ApiOperation("Retry Creates and persists proposal entity from a cef creation request")
	@RequestMapping(value = "/retry", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<Void> retryCEFMigration(@RequestBody CefProjectMigrationRequest request) {
		log.info("Inside retryCEFMigration");
		HttpHeaders headers = RestUtils.buildErrorHttpHeaders();
		UsptoAuthenticationToken authToken = securityService
				.mapSamlTokenToContractModel(SecurityContextHolder.getContext().getAuthentication());
		HttpStatus status = HttpStatus.NOT_FOUND;
		if (cefMigrationHelper.isCefProjectsExistsOnServer()) {
			cefMigrationRetryService.retryCEFMigration(request, authToken);
			status = HttpStatus.OK;
		}
		return new ResponseEntity<>(headers, status);
	}
}
