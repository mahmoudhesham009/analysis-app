package gov.uspto.pe2e.cpc.ipc.rest.cef.controller;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.dbunit.database.IDatabaseConnection;
import org.docx4j.openpackaging.exceptions.Docx4JException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.saml.SAMLCredential;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import gov.uspto.pe2e.cpc.ipc.rest.cef.controller.CefMigrationController;
import gov.uspto.pe2e.cpc.ipc.rest.cef.service.CefDocumentLibraryMigrationService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.error.ResourceCheckoutException;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.CefModuleProcessLog;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.entity.CefProjectProcessLog;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.CefModuleProcessLogRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.persistence.repository.CefProjectProcessLogRepository;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.adapter.LocalTestCloudResourcePersistenceService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.adapter.UnifiedCloudResourcePersistenceService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.service.document.adapter.v1_0.DocumentAdapter;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.BasicTestingGrantedAuthority;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.DatasetTestingService;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.SamlTestingUtil;
import gov.uspto.pe2e.cpc.ipc.rest.commons.testingsupport.WebMocker;
import gov.uspto.pe2e.cpc.ipc.rest.commons.util.SchemePublicationVersionContextHolder;
import gov.uspto.pe2e.cpc.ipc.rest.contract.base.SchemePublicationVersion;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.CefMigrationStatus;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.CefModuleName;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.CefProjectCreationRequest;
import gov.uspto.pe2e.cpc.ipc.rest.contract.proposal.v1_0.CefProjectMigrationRequest;
import net.jcip.annotations.NotThreadSafe;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:META-INF/spring/applicationContext.xml",
        "classpath:META-INF/spring/applicationContext-test.xml" })
@NotThreadSafe
@Category(NotThreadSafe.class)
public class CefMigrationControllerTest {
    private static final Logger log = LoggerFactory.getLogger(CefMigrationControllerTest.class);
   
    @Inject
    private CefMigrationController cefMigrationController;
    
    @Inject
    private CefDocumentLibraryMigrationService docServicce;
   
    @Inject
    private DatasetTestingService datasetTestingService;
    
    @Inject
    private CefProjectProcessLogRepository cefProjectProcessLogRepository;
    
    @Inject
    private CefModuleProcessLogRepository cefModuleProcessLogRepository;
    
    @Inject 
    private UnifiedCloudResourcePersistenceService unifiedCloudResourcePersistenceService;
    
    @Inject 
    private LocalTestCloudResourcePersistenceService localTestCloudResourcePersistenceService;
    
    

    @Test
    @Transactional
    public void testCEFProjectMetadataCreation() throws ResourceCheckoutException {
                     
        ObjectMapper mapper = new ObjectMapper();
        try {
          String json = mapper.writeValueAsString("");
          log.debug("ResultingJSONstring = " + json);
        } catch (JsonProcessingException e) {
           e.printStackTrace();
        }
        CefProjectMigrationRequest request = new CefProjectMigrationRequest();
        request.setMigrateAllProjects(true);
        List<String> cefProjectCode = Arrays.asList("RP01012", "RP01015", "RP01016");
        request.getCefProjectCode().addAll(cefProjectCode);
        
        ResponseEntity<Void> respEntity = cefMigrationController.processCefProjects(request);
        Assert.assertEquals(HttpStatus.CREATED, respEntity.getStatusCode()); 
   
    }

    @Test
    public void testProcessCefProjectsWorkflowForNotMigratedProject() throws IOException
    {
		CefProjectMigrationRequest request= new CefProjectMigrationRequest();
		request.getCefProjectCode().add("RP01013");

    	ResponseEntity<Void> respEntity=cefMigrationController.processCefProjectsWorkflow(request);
    	CefModuleProcessLog moduleLogs=cefModuleProcessLogRepository.findAllLogsByCefProjectCodeAndModule("RP01013",CefModuleName.WORKFLOW);
    	assertNotNull(respEntity);
    	assertEquals(moduleLogs.getStatus(),CefMigrationStatus.FAILED);
    }
    @Test
    public void testProcessCefProjectsWorkflowForSuccessfullyMigratedProject() throws IOException
    {
		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("venkata.kommareddy@uspto.gov", "vkommareddy",
				"Venkata", "Kommareddy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
				"venkata.kommareddy@uspto.gov", token, Arrays.asList(new BasicTestingGrantedAuthority("test")));
		SecurityContextHolder.getContext().setAuthentication(springUser);
		
		CefProjectMigrationRequest request= new CefProjectMigrationRequest();
		request.getCefProjectCode().add("RP01012");

    	ResponseEntity<Void> respEntity=cefMigrationController.processCefProjectsWorkflow(request);
    	CefModuleProcessLog moduleLogs=cefModuleProcessLogRepository.findAllLogsByCefProjectCodeAndModule("RP01012",CefModuleName.WORKFLOW);
    	assertNotNull(respEntity);
    	assertEquals(HttpStatus.ACCEPTED, respEntity.getStatusCode());
    	assertEquals(moduleLogs.getStatus(),CefMigrationStatus.FAILED);
    }
    @Test
    public void testProcessCefProjectsWorkflowForWorkflowNotRequired() throws IOException
    {
		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("venkata.kommareddy@uspto.gov", "vkommareddy",
				"Venkata", "Kommareddy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
				"venkata.kommareddy@uspto.gov", token, Arrays.asList(new BasicTestingGrantedAuthority("test")));
		SecurityContextHolder.getContext().setAuthentication(springUser);
		
		CefProjectMigrationRequest request= new CefProjectMigrationRequest();
		request.getCefProjectCode().add("RP01015");

    	ResponseEntity<Void> respEntity=cefMigrationController.processCefProjectsWorkflow(request);
    	CefModuleProcessLog moduleLogs=cefModuleProcessLogRepository.findAllLogsByCefProjectCodeAndModule("RP01015",CefModuleName.WORKFLOW);
    	assertNotNull(respEntity);
    	assertEquals(moduleLogs.getStatus(),CefMigrationStatus.SUCCESS);
    }
    //@Test
    //Skip check is removed from the workflow and doc library. Since we will not be passing the skipped projects in the requests
    public void testProcessCefProjectsWorkflowSkipProjectByStatus() throws IOException
    {
		SAMLCredential token = SamlTestingUtil.createTestSamlCredential("venkata.kommareddy@uspto.gov", "vkommareddy",
				"Venkata", "Kommareddy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
				"venkata.kommareddy@uspto.gov", token, Arrays.asList(new BasicTestingGrantedAuthority("test")));
		SecurityContextHolder.getContext().setAuthentication(springUser);
		
		CefProjectMigrationRequest request= new CefProjectMigrationRequest();
		request.getCefProjectCode().add("RP01017");

    	ResponseEntity<Void> respEntity=cefMigrationController.processCefProjectsWorkflow(request);
    	CefModuleProcessLog moduleLogs=cefModuleProcessLogRepository.findAllLogsByCefProjectCodeAndModule("RP01017",CefModuleName.WORKFLOW);
    	assertNotNull(respEntity);
    	assertEquals(HttpStatus.BAD_REQUEST, respEntity.getStatusCode());
    	assertNull(moduleLogs);
    }
    @Test
    public void processCefProposalDocsWhenExceptionOccurs() throws IOException
    {
    	SAMLCredential token = SamlTestingUtil.createTestSamlCredential("venkata.kommareddy@uspto.gov", "vkommareddy",
				"Venkata", "Kommareddy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
				"venkata.kommareddy@uspto.gov", token, Arrays.asList(new BasicTestingGrantedAuthority("test")));
		SecurityContextHolder.getContext().setAuthentication(springUser);
		
		unifiedCloudResourcePersistenceService.setPersistenceServices(Arrays.asList(localTestCloudResourcePersistenceService));
		
		CefProjectMigrationRequest request= new CefProjectMigrationRequest();
		request.getCefProjectCode().add("RP01012");
		
		ResponseEntity<Void> respEntity=cefMigrationController.processCefProposalDocs(request);
    	
		CefModuleProcessLog moduleLogs=cefModuleProcessLogRepository.findAllLogsByCefProjectCodeAndModule("RP01012",CefModuleName.DOCLIB);
		CefProjectProcessLog projectLog=cefProjectProcessLogRepository.findAllByCefProjectCode("RP01012");
		assertNotNull(respEntity);
    	assertTrue(moduleLogs.getException().contains("Expected resource id in GUID string format but returned"));
    	assertEquals(moduleLogs.getStatus(),CefMigrationStatus.FAILED);
    	assertEquals(CefMigrationStatus.INPROGRESS, projectLog.getStatus());
    }
    @Test
    public void processCefProposalDocsMetaDataNotProcessed() throws IOException
    {
    	SAMLCredential token = SamlTestingUtil.createTestSamlCredential("venkata.kommareddy@uspto.gov", "vkommareddy",
				"Venkata", "Kommareddy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
				"venkata.kommareddy@uspto.gov", token, Arrays.asList(new BasicTestingGrantedAuthority("test")));
		SecurityContextHolder.getContext().setAuthentication(springUser);
		
		unifiedCloudResourcePersistenceService.setPersistenceServices(Arrays.asList(localTestCloudResourcePersistenceService));
		
		CefProjectMigrationRequest request= new CefProjectMigrationRequest();
		request.getCefProjectCode().add("RP01013");
		
		ResponseEntity<Void> respEntity=cefMigrationController.processCefProposalDocs(request);
    	
		CefModuleProcessLog moduleLogs=cefModuleProcessLogRepository.findAllLogsByCefProjectCodeAndModule("RP01013",CefModuleName.DOCLIB);
    	CefProjectProcessLog projectLog=cefProjectProcessLogRepository.findAllByCefProjectCode("RP01013");
		assertNotNull(respEntity);
    	assertEquals(moduleLogs.getStatus(),CefMigrationStatus.FAILED);
    	assertEquals(CefMigrationStatus.INPROGRESS, projectLog.getStatus());
    }
    @Test
    public void processCefProposalDocsAnnexesNotAvailable() throws IOException
    {
    	SAMLCredential token = SamlTestingUtil.createTestSamlCredential("venkata.kommareddy@uspto.gov", "vkommareddy",
				"Venkata", "Kommareddy", "US");
		UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
				"venkata.kommareddy@uspto.gov", token, Arrays.asList(new BasicTestingGrantedAuthority("test")));
		SecurityContextHolder.getContext().setAuthentication(springUser);
		
		unifiedCloudResourcePersistenceService.setPersistenceServices(Arrays.asList(localTestCloudResourcePersistenceService));
		
		CefProjectMigrationRequest request= new CefProjectMigrationRequest();
		request.getCefProjectCode().add("RP01014");
		
		ResponseEntity<Void> respEntity=cefMigrationController.processCefProposalDocs(request);
    	
		CefModuleProcessLog moduleLogs=cefModuleProcessLogRepository.findAllLogsByCefProjectCodeAndModule("RP01014",CefModuleName.DOCLIB);
    	assertNotNull(respEntity);
    	assertEquals(HttpStatus.CREATED, respEntity.getStatusCode());
    	assertEquals(moduleLogs.getStatus(),CefMigrationStatus.SUCCESS);
    }
    
    @Test
    public void testRetryMigrationForIndividual() throws IOException
    {
        SAMLCredential token = SamlTestingUtil.createTestSamlCredential("venkata.kommareddy@uspto.gov", "vkommareddy",
                "Venkata", "Kommareddy", "US");
        UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
                "venkata.kommareddy@uspto.gov", token, Arrays.asList(new BasicTestingGrantedAuthority("test")));
        SecurityContextHolder.getContext().setAuthentication(springUser);
        
        unifiedCloudResourcePersistenceService.setPersistenceServices(Arrays.asList(localTestCloudResourcePersistenceService));
        
        CefProjectMigrationRequest request= new CefProjectMigrationRequest();
        request.getCefProjectCode().add("RP01023");
        
        ResponseEntity<Void> respEntity=cefMigrationController.retryCEFMigration(request);
        
        assertNotNull(respEntity);
        assertEquals(HttpStatus.OK, respEntity.getStatusCode());
    }
    
    @Test
    public void testRetryMigrationForIndividualWithOutMetadata() throws IOException
    {
        SAMLCredential token = SamlTestingUtil.createTestSamlCredential("venkata.kommareddy@uspto.gov", "vkommareddy",
                "Venkata", "Kommareddy", "US");
        UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
                "venkata.kommareddy@uspto.gov", token, Arrays.asList(new BasicTestingGrantedAuthority("test")));
        SecurityContextHolder.getContext().setAuthentication(springUser);
        
        unifiedCloudResourcePersistenceService.setPersistenceServices(Arrays.asList(localTestCloudResourcePersistenceService));
        
        CefProjectMigrationRequest request= new CefProjectMigrationRequest();
        request.getCefProjectCode().add("RP01021");
        
        ResponseEntity<Void> respEntity=cefMigrationController.retryCEFMigration(request);
        
        assertNotNull(respEntity);
        assertEquals(HttpStatus.OK, respEntity.getStatusCode());
    }
    
    @Test
    public void testRetryMigrationForAll() throws IOException
    {
        SAMLCredential token = SamlTestingUtil.createTestSamlCredential("venkata.kommareddy@uspto.gov", "vkommareddy",
                "Venkata", "Kommareddy", "US");
        UsernamePasswordAuthenticationToken springUser = new UsernamePasswordAuthenticationToken(
                "venkata.kommareddy@uspto.gov", token, Arrays.asList(new BasicTestingGrantedAuthority("test")));
        SecurityContextHolder.getContext().setAuthentication(springUser);
        
        unifiedCloudResourcePersistenceService.setPersistenceServices(Arrays.asList(localTestCloudResourcePersistenceService));
        
        CefProjectMigrationRequest request= new CefProjectMigrationRequest();
        request.getCefProjectCode().add("RP01014");
        request.setMigrateAllProjects(true);
        
        ResponseEntity<Void> respEntity=cefMigrationController.retryCEFMigration(request);
        
        assertNotNull(respEntity);
        assertEquals(HttpStatus.OK, respEntity.getStatusCode());
    }
    
    @Before
    public void setUp() throws Exception {
        IDatabaseConnection conn = datasetTestingService.getConnection();
        datasetTestingService.emptyTables(conn);
        datasetTestingService.loadAllDatasets(conn);

        SchemePublicationVersion version = new SchemePublicationVersion();
        version.setClassificationSchemeId(1L);
        version.setCpcXsdVersion("1.6");
        version.setDefinitionXsdVersion("0.9");
        version.setDocumentAdapterClass(DocumentAdapter.class.getCanonicalName());
        version.setPublicationDate(DateUtils.parseDate("2015-11-01", DateFormatUtils.ISO_DATE_FORMAT.getPattern()));
        SchemePublicationVersionContextHolder.setContext(version);

        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken("user1@uspto.gov", "myoung3@uspto.gov", Arrays
                .asList(new BasicTestingGrantedAuthority("test@uspto.gov")));

        SecurityContextHolder.getContext().setAuthentication(token);

        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(WebMocker.mockHttpRequest("localhost",
                "/cpcipcrestweb", "/symbols")));
    }
    
	
}
