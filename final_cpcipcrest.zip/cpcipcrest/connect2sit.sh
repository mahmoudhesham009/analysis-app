#dev
ssh -m hmac-sha2-512 -i \tools\ssh\aws_key.pem ec2-user@10.201.7.124

#sit
ssh -i \tools\ssh\aws_key.pem ec2-user@10.201.7.106

# pvt
ssh -m hmac-sha2-512 -i \tools\ssh\aws_key.pem ec2-user@10.201.18.238

scp -i \tools\ssh\aws_key.pem ec2-user@10.201.18.238:PE2E-CPC-IPC-REST-CF-BUNDLE-2.6.2.5-bin.tar
ssh -i \tools\ssh\aws_key.pem ec2-user@10.201.18.238 "./deploy_manual.sh PE2E-CPC-IPC-REST-CF-BUNDLE-2.6.2.5-bin.tar"