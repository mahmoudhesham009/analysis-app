package com.pto.cloneProcess;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CloneProcessApplication {

	public static void main(String[] args) {
		SpringApplication.run(CloneProcessApplication.class, args);
	}

}
