package com.pto.cloneProcess.model.originalProd.repository;

import com.pto.cloneProcess.model.originalProd.entity.ActHiTaskinstProd;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import javax.persistence.Tuple;
import java.util.List;
import java.util.Optional;

public interface ActHiTaskinstRepositoryProd extends JpaRepository<ActHiTaskinstProd, String> {

	Optional<ActHiTaskinstProd> findById(String id);

	@Query(value = "select pro.name_,pro.business_key_,pro.PROC_DEF_ID_,var.NAME_,var.VAR_TYPE_,var.TEXT_ from ACT_HI_PROCINST pro " +
			" left join ACT_HI_VARINST var on var.PROC_INST_ID_=pro.PROC_INST_ID_ where pro.PROC_INST_ID_= :proId"
			,nativeQuery = true)
	List<Tuple> getProcessData(String proId);

	@Query(value = "select id_, TASK_DEF_KEY_ from ACT_HI_TASKINST where PROC_INST_ID_= :proId and END_TIME_ is not null order by START_TIME_ asc"
			,nativeQuery = true)
	List<Tuple> getTasks(String proId);

	@Query(value = "select FIELDS_VALUE_DEFINITION from SUBMITTED_FORM where TASK_ID= :taskId"
			,nativeQuery = true)
	String getVariables(String taskId);
}
