package com.pto.cloneProcess.model.pvt.repository;

import java.util.List;
import java.util.Optional;

import com.pto.cloneProcess.model.pvt.entity.ActHiTaskinst;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import javax.persistence.Tuple;

public interface ActHiTaskinstRepository extends JpaRepository<ActHiTaskinst, String> {

	Optional<ActHiTaskinst> findById(String id);

	@Query(value = "select pro.name_,pro.business_key_,pro.PROC_DEF_ID_,var.NAME_,var.VAR_TYPE_,var.TEXT_ from ACT_HI_PROCINST pro " +
			" left join ACT_HI_VARINST var on var.PROC_INST_ID_=pro.PROC_INST_ID_ where pro.PROC_INST_ID_= :proId"
			,nativeQuery = true)
	List<Tuple> getProcessData(String proId);

}
