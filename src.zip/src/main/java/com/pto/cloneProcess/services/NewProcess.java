package com.pto.cloneProcess.services;

import java.io.IOException;
import java.util.List;
import java.util.Map;

public interface NewProcess {
	
	public List<Map<String, Object>> copyProcess(Map<String,Object> reqBody) throws SecurityException, IOException;

}
